"""Generate, solve, and check the predefined cantilever jobs inside the container."""

import argparse
import csv
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time


CASE = Path("/case")
SPANS = (1000, 1500, 2000, 2500)
MESHES = {"initial": (20, 2, 1), "refined": (10, 4, 2)}
WIDTH = 40
THICKNESS = 8
MODULUS = 61000
POISSON = 0.30
DENSITY = 2.675e-9
GRAVITY = 9806.65
LINE_LOAD = DENSITY * GRAVITY * WIDTH * THICKNESS
INERTIA = WIDTH * THICKNESS**3 / 12

# CalculiX C3D20 corner and edge-midpoint order, in half-element indices.
BRICK = (
    (0, 0, 0), (2, 0, 0), (2, 2, 0), (0, 2, 0),
    (0, 0, 2), (2, 0, 2), (2, 2, 2), (0, 2, 2),
    (1, 0, 0), (2, 1, 0), (1, 2, 0), (0, 1, 0),
    (1, 0, 2), (2, 1, 2), (1, 2, 2), (0, 1, 2),
    (0, 0, 1), (2, 0, 1), (2, 2, 1), (0, 2, 1),
)


def make_deck(path, span, mesh):
    pitch, ny, nz = MESHES[mesh]
    nx, remainder = divmod(span, pitch)
    assert remainder == 0
    nodes = {}
    elements = []
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                element = []
                for di, dj, dk in BRICK:
                    key = (2 * i + di, 2 * j + dj, 2 * k + dk)
                    element.append(nodes.setdefault(key, len(nodes) + 1))
                elements.append(element)
    root = [number for (x, _, _), number in nodes.items() if x == 0]
    tip = [nodes[(2 * nx, y, nz)] for y in (ny, 0, 2 * ny)]

    with path.open("w", encoding="ascii", newline="\n") as stream:
        stream.write(f"*HEADING\nWeek 2 cantilever, span {span} mm, {mesh} mesh\n*NODE\n")
        for (i, j, k), number in nodes.items():
            x = i * pitch / 2
            y = WIDTH * (j / ny - 1) / 2
            z = THICKNESS * (k / nz - 1) / 2
            stream.write(f"{number}, {x:g}, {y:g}, {z:g}\n")
        stream.write("*ELEMENT, TYPE=C3D20, ELSET=STRIP\n")
        for number, element in enumerate(elements, 1):
            first = ", ".join(map(str, [number, *element[:15]]))
            second = ", ".join(map(str, element[15:]))
            stream.write(f"{first},\n{second}\n")
        stream.write("*NSET, NSET=ROOT\n")
        for start in range(0, len(root), 12):
            stream.write(", ".join(map(str, root[start:start + 12])) + "\n")
        stream.write("*NSET, NSET=TIP\n" + ", ".join(map(str, tip)) + "\n")
        stream.write(
            "*MATERIAL, NAME=ALUMINIUM\n"
            f"*ELASTIC\n{MODULUS}, {POISSON}\n"
            f"*DENSITY\n{DENSITY}\n"
            "*SOLID SECTION, ELSET=STRIP, MATERIAL=ALUMINIUM\n"
            "*BOUNDARY\nROOT, 1, 3, 0\n"
            "*STEP, NLGEOM\n*STATIC\n0.20, 1., 0.00001, 0.20\n"
            f"*DLOAD\nSTRIP, GRAV, {GRAVITY}, 0., 0., -1.\n"
            "*NODE PRINT, NSET=TIP\nU\n"
            "*NODE PRINT, NSET=ROOT\nRF\n"
            "*END STEP\n"
        )
    return len(nodes), len(elements), root, tip


def read_nodal_output(path):
    header = re.compile(r"^\s*(displacements|forces)\s+\([^)]+\)\s+for set "
                        r"(\w+)\s+and time\s+([^\s]+)", re.IGNORECASE)
    blocks = {}
    current = None
    for line in path.read_text().splitlines():
        match = header.match(line)
        if match:
            quantity, group, load_time = match.groups()
            values = {}
            blocks[(quantity.lower(), group.upper())] = (float(load_time), values)
            current = values
        elif current is not None:
            fields = line.split()
            if len(fields) == 4 and fields[0].isdigit():
                current[int(fields[0])] = tuple(map(float, fields[1:]))
    return blocks


def elastica_tip(span, steps=1000):
    """Solve theta'' = -beta*(1-u)*cos(theta), u=s/L, theta positive down."""
    beta = LINE_LOAD * span**3 / (MODULUS * INERTIA)
    h = 1 / steps

    def derivative(u, state):
        angle, curvature, _ = state
        return curvature, -beta * (1 - u) * math.cos(angle), math.sin(angle)

    def integrate(root_curvature):
        state = (0.0, root_curvature, 0.0)
        for step in range(steps):
            u = step * h
            a = derivative(u, state)
            b = derivative(u + h / 2, tuple(v + h * w / 2 for v, w in zip(state, a)))
            c = derivative(u + h / 2, tuple(v + h * w / 2 for v, w in zip(state, b)))
            d = derivative(u + h, tuple(v + h * w for v, w in zip(state, c)))
            state = tuple(v + h * (w1 + 2 * w2 + 2 * w3 + w4) / 6
                          for v, w1, w2, w3, w4 in zip(state, a, b, c, d))
        return state[1], state[2]

    low, high = 0.0, beta / 2
    assert integrate(low)[0] < 0 < integrate(high)[0]
    for _ in range(40):
        middle = (low + high) / 2
        if integrate(middle)[0] > 0:
            high = middle
        else:
            low = middle
    curvature, tip = integrate((low + high) / 2)
    assert abs(curvature) < 1e-10
    return tip * span


def run_job(solver, run_dir, span, mesh, linear, elastica):
    job = f"span_{span}_{mesh}"
    job_dir = run_dir / job
    job_dir.mkdir()
    n_nodes, n_elements, root, tip = make_deck(job_dir / "strip.inp", span, mesh)
    print(f"Running {job} ({n_elements} elements, {n_nodes} nodes)", flush=True)
    with (job_dir / "solver.log").open("wb") as log:
        started = time.perf_counter()
        result = subprocess.run([solver, "-i", "strip"], cwd=job_dir,
                                stdout=log, stderr=subprocess.STDOUT, check=False)
        seconds = time.perf_counter() - started
    log_text = (job_dir / "solver.log").read_text(errors="replace")
    if result.returncode or "Job finished" not in log_text or re.search(r"\*ERROR\b", log_text):
        raise RuntimeError(f"Solver failed on {job}; see {job_dir / 'solver.log'}")
    status = (job_dir / "strip.sta").read_text().splitlines()
    last = [line.split() for line in status if len(line.split()) == 7
            and line.split()[0].isdigit()][-1]
    if last[0] != "1" or not last[2].isdigit() or not math.isclose(float(last[5]), 1.0):
        raise RuntimeError(f"Job {job} did not reach the final converged load increment: {last}")
    nodal = read_nodal_output(job_dir / "strip.dat")
    disp_time, displacements = nodal["displacements", "TIP"]
    force_time, forces = nodal["forces", "ROOT"]
    if not (math.isclose(disp_time, 1.0) and math.isclose(force_time, 1.0)):
        raise RuntimeError(f"Missing full-load nodal output for {job}")
    if set(root) != forces.keys() or set(tip) != displacements.keys():
        raise RuntimeError(f"Incomplete nodal output for {job}")
    center = displacements[tip[0]]
    downward = -center[2]
    weight = LINE_LOAD * span
    reaction = sum(v[2] for v in forces.values())
    reaction_error = abs(reaction - weight) / weight
    symmetry_error = abs(displacements[tip[1]][2] - displacements[tip[2]][2])
    elastica_error = abs(downward - elastica) / elastica
    quality = {
        "span_mm": span,
        "mesh": mesh,
        "nodes": n_nodes,
        "elements": n_elements,
        "final_load_fraction": last[5],
        "final_increment": last[1],
        "tip_down_mm": f"{downward:.6f}",
        "tip_U1_mm": f"{center[0]:.8g}",
        "tip_U2_mm": f"{center[1]:.8g}",
        "linear_beam_mm": f"{linear:.6f}",
        "elastica_mm": f"{elastica:.6f}",
        "elastica_error_pct": f"{100 * elastica_error:.6f}",
        "weight_N": f"{weight:.8f}",
        "root_RF3_N": f"{reaction:.8f}",
        "reaction_error_pct": f"{100 * reaction_error:.6f}",
        "side_U3_difference_mm": f"{symmetry_error:.8g}",
        "quality_pass": (math.isfinite(downward) and downward > 0 and
                         reaction_error <= 0.005 and symmetry_error <= 0.005 and
                         elastica_error <= 0.02),
    }
    timing = {"span_mm": span, "mesh": mesh, "solver_wall_s": f"{seconds:.3f}"}
    print(f"  {downward:.6f} mm, {seconds:.3f} s, checks pass={quality['quality_pass']}")
    return downward, quality, timing


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", action="store_true")
    args = parser.parse_args()
    if args.original:
        if not (CASE / "proposal.md").is_file() or (CASE / "seal.json").exists():
            raise RuntimeError("Original run requires a proposal and an unsealed case")
        output = CASE
    else:
        output = Path(tempfile.mkdtemp(prefix="reproduction-", dir=CASE))
    run_dir = output / "jobs"
    run_dir.mkdir()

    solver = shutil.which("ccx")
    if solver is None:
        raise RuntimeError("ccx is unavailable in the benchmark image")
    version = subprocess.run([solver, "-v"], stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True, check=False).stdout.strip()
    if not re.search(r"\b2\.20\b", version):
        raise RuntimeError(f"Expected CalculiX 2.20; version output was: {version}")
    (output / "environment.json").write_text(json.dumps({
        "solver": solver,
        "version_output": version,
        "image_id": os.environ["BENCHMARK_IMAGE_ID"],
        "cpu_limit": 4,
        "OMP_NUM_THREADS": os.environ["OMP_NUM_THREADS"],
        "CCX_NPROC_EQUATION_SOLVER": os.environ["CCX_NPROC_EQUATION_SOLVER"],
        "network": "none",
    }, indent=2) + "\n")
    predictions, checks, timings, convergence = [], [], [], []
    for span in SPANS:
        linear = LINE_LOAD * span**4 / (8 * MODULUS * INERTIA)
        elastica = elastica_tip(span)
        deflections = {}
        for mesh in MESHES:
            deflections[mesh], quality, timing = run_job(solver, run_dir, span, mesh, linear, elastica)
            checks.append(quality)
            timings.append(timing)
        initial, refined = deflections["initial"], deflections["refined"]
        change = abs(initial - refined) / abs(refined)
        predictions.append({"span_mm": span, "initial_mm": f"{initial:.6f}",
                            "refined_mm": f"{refined:.6f}"})
        convergence.append({"span_mm": span, "mesh_change_mm": f"{abs(initial - refined):.6f}",
                            "mesh_change_pct": f"{100 * change:.6f}", "mesh_pass": change <= 0.005})
    for name, rows in (("predictions", predictions), ("quality", checks),
                       ("timing", timings), ("convergence", convergence)):
        write_csv(output / f"{name}.csv", rows)
    print(f"Predictions and evidence saved to {output}")


if __name__ == "__main__":
    main()
