# Week 2 self-weight cantilever prediction

Operator identifier: GPT-6.2 sol. This plan was recorded before deck generation and solver execution. The benchmark brief is the sole source of specimen and test inputs.

## Physical model

- Use a separate three-dimensional solid model for each exposed span of 1,000, 1,500, 2,000 and 2,500 mm. The initially straight prism runs along +X, has width 40 mm along Y and thickness 8 mm along Z, and is centered about Y = Z = 0. Use N, mm, s and tonne units.
- Model 6060 aluminium as homogeneous, isotropic and linearly elastic with E = 61,000 N/mm², Poisson ratio 0.30 and density 2.675 × 10⁻⁹ tonne/mm³. Ramp a uniform gravitational acceleration of 9,806.65 mm/s² in global −Z, with zero other loads.
- Represent the steel clamp by fixing all three translations across the entire X = 0 face at the exposed-span origin. The strip is the only modeled solid. The brief supplies no bearing geometry, preload, clamp compliance, or attachment masses or stiffnesses, so the prediction uses an ideal fixed root and the bare strip.
- Solve static equilibrium with geometrical nonlinearity enabled to account for changes in the horizontal gravity moment arm. Use load fraction 0 to 1 with automatic increments, an initial and maximum increment of 0.20, and a minimum of 0.00001. Use the displacement magnitude −U3 at the center of the free end face for scoring. Also request the two mid-thickness side points on that face for a symmetry check.

## Mesh and stop criterion

Use structured, full-integration, 20-node quadratic brick elements (CalculiX C3D20). The initial mesh uses 20 mm axial pitch, two elements across the width and one through the thickness. The predefined refinement halves the pitch to 10 mm and uses four elements across the width and two through the thickness. Each span is an exact multiple of both pitches. Both meshes include the free-face center as a node.

Run only these two levels for the benchmark. Mark a span as mesh-converged when the absolute change from initial to refined is at most 0.5% of the refined magnitude and both runs reach full-load equilibrium. If the criterion fails, keep the predefined results and flag the span in the handoff.

## Verification and evidence

- Require normal solver completion and confirm that the final converged increment reaches full gravity. Record elapsed wall time for each solver invocation, job output and solver logs.
- Compare the root vertical reaction with the analytical strip weight (0.5% tolerance). Check for downward tip displacement and free-face symmetry in U3 at the two side points (0.005 mm tolerance).
- Compare both meshes with linear Euler–Bernoulli deflection qL⁴/(8EI), where q = ρgA and I = 40 × 8³/12 mm⁴. Also solve the inextensible gravity-loaded elastica by numerical shooting as an independent large-rotation check, with a 2% comparison tolerance. These checks do not adjust the model.
- Execute CalculiX 2.20 in the supplied CPU-only image with four available CPUs, disabled networking and only this case directory bound to /case. Preserve the actual decks and record their SHA-256 digests with the proposal and predictions.
