param([switch]$Original)

$ErrorActionPreference = 'Stop'
$image = 'aero/fea-bounded:1.1-foundation-r3'
$imageId = & docker image inspect --format '{{.Id}}' $image
if ($LASTEXITCODE -ne 0 -or -not $imageId) {
    throw "The benchmark image must be available locally: $image"
}

$runCommand = 'exec python3 -u /case/run.py'
if ($Original) {
    $runCommand += ' --original'
}

& docker run --rm --pull never --entrypoint /bin/sh --network none --cpus 4 `
    --mount "type=bind,source=$PSScriptRoot,target=/case" --workdir /case `
    --env OMP_NUM_THREADS=4 --env CCX_NPROC_EQUATION_SOLVER=4 `
    --env "BENCHMARK_IMAGE_ID=$imageId" $imageId -c $runCommand
if ($LASTEXITCODE -ne 0) {
    throw "Benchmark container exited with code $LASTEXITCODE."
}
