"""Verify sealed CalculiX predictions before scoring against the paper."""
import csv
import hashlib
import json
import math
import re
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent
MODELS = ("sol", "astra")
SPANS = (1000, 1500, 2000, 2500)
STAGES = ("initial", "refined")


def verified_predictions(model):
    folder = ROOT / model
    files = json.loads((folder / "seal.json").read_text(encoding="utf-8-sig"))["files"]
    assert {"proposal.md", "predictions.csv"} <= files.keys(), model
    assert sum(name.endswith(".inp") for name in files) >= 8, model
    for name, expected in files.items():
        path = (folder / name).resolve()
        assert path.is_relative_to(folder) and re.fullmatch("[a-fA-F0-9]{64}", expected), name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected.lower(), name
    with (folder / "predictions.csv").open(encoding="utf-8-sig", newline="") as file:
        rows = list(csv.DictReader(file))
    predictions = {
        int(float(row["span_mm"])): {stage: float(row[stage + "_mm"]) for stage in STAGES}
        for row in rows
    }
    assert len(rows) == len(SPANS) and sorted(predictions) == list(SPANS), model
    assert all(math.isfinite(v) and v > 0 for row in predictions.values() for v in row.values())
    return predictions


def score():
    predictions = {model: verified_predictions(model) for model in MODELS}
    with (ROOT / "reference.csv").open(encoding="utf-8-sig", newline="") as file:
        reference = {int(row["span_mm"]): float(row["measured_mm"]) for row in csv.DictReader(file)}
    assert sorted(reference) == list(SPANS)
    rows = []
    summary = {}
    for model, values in predictions.items():
        summary[model] = {}
        for stage in STAGES:
            group = []
            for span in SPANS:
                measured = reference[span]
                prediction = values[span][stage]
                delta = prediction - measured
                group.append(dict(model=model, stage=stage, span_mm=span,
                                  measured_mm=measured, predicted_mm=prediction,
                                  delta_mm=delta, delta_pct=100 * delta / measured))
            rows.extend(group)
            summary[model][stage] = {
                "mae_mm": mean(abs(row["delta_mm"]) for row in group),
                "mape_pct": mean(abs(row["delta_pct"]) for row in group),
                "mean_signed_pct": mean(row["delta_pct"] for row in group),
            }
        summary[model]["max_refinement_pct"] = max(
            100 * abs(values[span]["refined"] - values[span]["initial"]) / values[span]["refined"]
            for span in SPANS
        )
    with (ROOT / "scores.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    score()
