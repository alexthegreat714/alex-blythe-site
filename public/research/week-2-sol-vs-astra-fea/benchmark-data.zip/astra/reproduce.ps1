$ErrorActionPreference = 'Stop'
$casePath = $PSScriptRoot
$tag = 'aero/fea-bounded:1.1-foundation-r3'
$imageId = docker image inspect $tag --format '{{.Id}}'
if ($LASTEXITCODE -ne 0 -or $imageId -ne 'sha256:b73d70afc297054bf644db852e8d8ed0bbd2423fecbcd5669194dd7460d9a763') {
    throw 'The local solver image differs from the benchmark image.'
}
$dest = 'replay-' + [guid]::NewGuid().ToString('N')
docker run --rm --pull=never --network none --cpus 4 --entrypoint /bin/sh --mount "type=bind,source=$casePath,target=/case" -w /case -e PYTHONDONTWRITEBYTECODE=1 $imageId -c "python3 benchmark.py $dest && python3 support_check.py $dest"
if ($LASTEXITCODE -ne 0) { throw 'Reproduction failed.' }
$original = Join-Path $casePath 'runs'
$replay = Join-Path $casePath $dest
$compare = @('predictions.csv', 'mesh_checks.csv', 'support_checks.csv', 'quality.csv')
foreach ($mesh in @('initial','refined')) {
    foreach ($span in @(1000,1500,2000,2500)) {
        $compare += "${span}_${mesh}/strip.inp"
    }
}
foreach ($rel in $compare) {
    if ((Get-FileHash (Join-Path $original $rel)).Hash -ne (Get-FileHash (Join-Path $replay $rel)).Hash) {
        throw "Reproduction mismatch in $rel"
    }
}
Write-Output "Verified decks, predictions and checks in $replay"
