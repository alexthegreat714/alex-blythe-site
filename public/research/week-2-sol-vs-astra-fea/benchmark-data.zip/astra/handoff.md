# Week 2 structural benchmark | GPT-6.2 astra

The primary scoring column is `refined_mm` in `predictions.csv`. Values are downward free-end center displacement magnitudes, measured from the initially straight strip. The model uses only the strip's own weight and a fully fixed root face. Unspecified target and shaker masses, attachment stiffnesses and clamp compliance are omitted.

| Exposed span (mm) | Initial (mm) | Refined (mm) | Mesh change (mm) | Allowed change (mm) | Mesh agreement | Independent elastica (mm) |
|---:|---:|---:|---:|---:|:---|---:|
| 1000 | 9.935197 | 10.01737 | 0.082173 | 0.050087 | Unresolved | 10.0784 |
| 1500 | 50.49455 | 50.77124 | 0.276690 | 0.253856 | Unresolved | 50.9788 |
| 2000 | 159.2975 | 159.9468 | 0.649300 | 0.799734 | Pass | 160.4360 |
| 2500 | 384.0216 | 386.1187 | 2.097100 | 1.930594 | Unresolved | 386.1715 |

All eight geometrically nonlinear C3D20R jobs converged in four increments to full load. Both meshes gave downward displacement increasing with span. The independent planar elastica uses a uniformly distributed dead load per undeformed length, zero root slope and zero tip moment. At 2500 mm the linear beam estimate is 393.719 mm. The elastica gives 386.172 mm. Across spans the refined FE results are within 0.61% of the elastica. Mesh agreement is evaluated using the original proposal criterion at each span.

## Support balance

The printed root RF sum alone falls short of the total weight by 0.069954 N on the initial mesh and 0.034977 N on the refined mesh, independent of span. The raw comparison in `runs/quality.csv` flags these differences. Recovering the full support reaction requires adding the downward gravity magnitude carried directly at the constrained degrees of freedom. The sum of the fixed-face quadratic shape functions averaged over each cross section of the first element layer is (1-u)(1-2u), where u goes from 0 to 1 along that layer. Integrating gives a fixed-node weight of w × dx / 6, where w = 0.0083944924 N/mm. Including that term closes all eight balances within 0.000036% of specimen weight. `runs/support_checks.csv` preserves the printed and reconstructed forces. This postprocessing uses the original meshes and gravity load.

## Reproduction and evidence

From PowerShell in this directory, run:

```powershell
.\reproduce.ps1
```

The script checks the local image ID, uses /bin/sh, disables networking, limits Docker to four CPUs and mounts only this directory. It writes into a fresh replay subdirectory and verifies all eight decks, predictions and quality CSVs against the original run. A complete replay passed the byte comparisons. The original solver is CalculiX 2.20. Original per-job wall times are in `timing.csv`. Each `runs/<span>_<mesh>/` folder contains the deck, console log, full-load node print and convergence records. `proposal.md` records the choices made before deck generation. `seal.json` maps original artifact paths to SHA-256 digests.
