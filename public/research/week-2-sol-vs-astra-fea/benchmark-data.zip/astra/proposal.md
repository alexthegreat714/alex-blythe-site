# Week 2 cantilever prediction | GPT-6.2 astra

## Physical model

Use 3D isotropic, linear elastic aluminium with finite-displacement static kinematics (CalculiX NLGEOM). A rectangular solid permits cross-section deformation at the built-in root. Use N, mm, s and tonne, with E = 61000 N/mm², Poisson ratio 0.30, density 2.675e-9 tonne/mm³ and acceleration 9806.65 mm/s² along global -Z. X runs from the clamp exit to the free tip, Y spans 40 mm and Z spans 8 mm about the initially straight centerline.

Fix all three translations on the X = 0 face. This represents an ideal fixed clamp with the stated exposed length. Ignore the uncharacterized masses and stiffnesses of the targets, shaker and fixtures. Apply only volume gravity, with no initial stress or imperfections. Score the magnitude of the final Z displacement of the free-end center node.

## Mesh and solver plan

Use structured 20-node reduced-integration quadratic brick elements (C3D20R). Initial element dimensions along X, Y, Z are 50 × 20 × 8 mm. Halve each dimension on the predefined refined mesh to 25 × 10 × 4 mm. Run both meshes for all four spans with identical loading, supports and material. Use automatic static increments, initial and maximum size 0.25, minimum 1e-6, and total step time 1. Use solver default nonlinear residual tolerances. No mass scaling. Use one solver thread for repeatable execution within the four-CPU container limit.

## Stop and evidence rules

Accept mesh agreement per span when the absolute difference is at most the greater of 0.02 mm and 0.5% of the refined displacement. Stop after the prescribed pair and flag any failure as unresolved. Publish both values, with the refined mesh as the primary prediction. No calibration. Require a completed full-load solution, downward displacement, and total vertical support reaction within 0.1% of the specimen weight. Check monotonicity across spans. Compare with the Euler–Bernoulli small-deflection formula and with a planar, inextensible cantilever elastica under uniform gravity. The beam checks are independent references, not inputs to the FE solutions. Record actual solver wall times, logs and input hashes.
