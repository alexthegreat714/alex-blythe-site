"""Reconstruct the support force including gravity applied at fixed DOFs."""
import csv
from pathlib import Path
import sys

from benchmark import MESHES, W, csv_file

dest = Path(sys.argv[1])
rows = []
with (dest / "quality.csv").open() as f:
    for row in csv.DictReader(f):
        # The sum of the root-plane shape functions is (1-u)*(1-2*u)
        # along the first brick (0 <= u <= 1). Its integral is 1/6.
        dx = MESHES[row["mesh"]][0]
        fixed_node_weight = W * dx / 6
        raw = float(row["root_rz_N"])
        support = raw + fixed_node_weight
        error = 100 * abs(support / float(row["weight_N"]) - 1)
        rows.append(dict(span_mm=row["span_mm"], mesh=row["mesh"], printed_rf_N=raw,
                         weight_on_fixed_nodes_N=fixed_node_weight,
                         support_N=support, weight_N=row["weight_N"],
                         residual_pct=error, passed=error <= 0.1))
csv_file(dest / "support_checks.csv", rows[0], rows)
print("Support balance with gravity on fixed nodes:", all(r["passed"] for r in rows))
