"""Generate the frozen continuation meshes, run CalculiX and audit its outputs."""
import argparse
import csv
import os
from pathlib import Path
import re
import subprocess
import time

PREVIOUS = {1000: 10.01737, 1500: 50.77124, 2500: 386.1187}
ELASTICA = {1000: 10.078377457742564, 1500: 50.9787732741221, 2500: 386.1715110006318}
DX, DY, DZ = 12.5, 5, 2
W = 2.675e-9 * 9806.65 * 40 * 8
EI = 61000 * 40 * 8**3 / 12
OFFSETS = [(0,0,0),(2,0,0),(2,2,0),(0,2,0),
           (0,0,2),(2,0,2),(2,2,2),(0,2,2),
           (1,0,0),(2,1,0),(1,2,0),(0,1,0),
           (1,0,2),(2,1,2),(1,2,2),(0,1,2),
           (0,0,1),(2,0,1),(2,2,1),(0,2,1)]


def make_deck(span, path):
    nx, ny, nz = int(span / DX), 40 // DY, 8 // DZ
    points = {}
    elements = []
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                conn = []
                for a, b, c in OFFSETS:
                    key = (2*i+a, 2*j+b, 2*k+c)
                    conn.append(points.setdefault(key, len(points)+1))
                elements.append(conn)
    root = []
    lines = ["*HEADING", f"Self-weight cantilever {span} mm continuation", "*NODE"]
    for (i, j, k), n in points.items():
        lines.append(f"{n},{i*DX/2:g},{j*DY/2-20:g},{k*DZ/2-4:g}")
        if i == 0:
            root.append(n)
    tip = points[(2*nx, ny, nz)]
    lines.append("*ELEMENT,TYPE=C3D20R,ELSET=STRIP")
    for n, conn in enumerate(elements, 1):
        lines.append(",".join(map(str, [n] + conn[:15])) + ",")
        lines.append(",".join(map(str, conn[15:])))
    lines.append("*NSET,NSET=ROOT")
    for i in range(0, len(root), 12):
        lines.append(",".join(map(str, root[i:i+12])))
    lines += ["*NSET,NSET=TIP", str(tip), "*MATERIAL,NAME=AL6060", "*ELASTIC",
              "61000,0.30", "*DENSITY", "2.675e-9",
              "*SOLID SECTION,ELSET=STRIP,MATERIAL=AL6060", "*BOUNDARY",
              "ROOT,1,3", "*STEP,NLGEOM,INC=200", "*STATIC",
              "0.25,1,0.000001,0.25", "*DLOAD", "STRIP,GRAV,9806.65,0,0,-1",
              "*NODE PRINT,NSET=TIP,FREQUENCY=99999", "U",
              "*NODE PRINT,NSET=ROOT,TOTALS=ONLY,FREQUENCY=99999", "RF", "*END STEP"]
    path.write_text("\n".join(lines)+"\n")
    return len(points), len(elements), tip


def full_load_vector(dat, label, ncols):
    pattern = r"^\s*" + label + r"[^\n]*?time\s+(\S+)[^\n]*\n\s*\n?([^\n]+)"
    matches = re.findall(pattern, dat, re.MULTILINE | re.IGNORECASE)
    stamp, line = matches[-1]
    values = [float(x) for x in line.split()]
    if abs(float(stamp)-1) > 1e-8 or len(values) != ncols:
        raise ValueError(f"Invalid full-load output for {label}")
    return values


def write_csv(dest, rows):
    with dest.open("x", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0], lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def run(dest):
    cases = dest / "runs"
    cases.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, OMP_NUM_THREADS="1", CCX_NPROC_STIFFNESS="1",
               CCX_NPROC_RESULTS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    predictions, timings, quality, checks = [], [], [], []
    for span, previous in PREVIOUS.items():
        case = cases / str(span)
        case.mkdir()
        nodes, elements, tip = make_deck(span, case/"strip.inp")
        print(f"Solving {span} mm, {elements} bricks", flush=True)
        with (case/"solver.log").open("w") as logfile:
            start = time.perf_counter()
            result = subprocess.run(["ccx", "-i", "strip"], cwd=case, env=env,
                                    stdout=logfile, stderr=subprocess.STDOUT)
            elapsed = time.perf_counter() - start
        log = (case/"solver.log").read_text()
        if result.returncode or "Job finished" not in log or "*ERROR" in log:
            raise RuntimeError(f"Solver failed for span {span}")
        sta = (case/"strip.sta").read_text().splitlines()[-1].split()
        dat = (case/"strip.dat").read_text()
        node_id, _, _, uz = full_load_vector(dat, "displacements", 4)
        _, _, rz = full_load_vector(dat, "total force", 3)
        if node_id != tip or abs(float(sta[4])-1) > 1e-8:
            raise RuntimeError(f"Tip or step mismatch for {span}")
        new = abs(uz)
        diff, limit = abs(new-previous), max(0.02, 0.005*new)
        weight = W*span
        fixed_weight = W*DX/6
        support = rz + fixed_weight
        err_pct = 100*abs(support/weight-1)
        predictions.append(dict(span_mm=span, previous_refined_mm=previous, refined_mm=new))
        timings.append(dict(span_mm=span, nodes=nodes, elements=elements,
                            converged_increments=int(sta[1]), solver_wall_s=f"{elapsed:.6f}"))
        quality.append(dict(span_mm=span, step_time=float(sta[4]), tip_uz_mm=uz,
                            downward=uz<0, printed_root_rf_N=rz, fixed_node_weight_N=fixed_weight,
                            support_N=support, specimen_weight_N=weight, support_error_pct=err_pct,
                            support_pass=err_pct<=0.1, linear_beam_mm=W*span**4/(8*EI),
                            elastica_mm=ELASTICA[span], elastica_difference_pct=100*(new/ELASTICA[span]-1)))
        checks.append(dict(span_mm=span, difference_mm=diff, relative_change_pct=100*diff/new,
                           tolerance_mm=limit, passed=diff<=limit))
        print(f"Finished {span} mm in {elapsed:.2f} s, Uz = {uz} mm", flush=True)
    for name, rows in [("predictions", predictions), ("timing", timings),
                       ("quality", quality), ("mesh_checks", checks)]:
        write_csv(dest / (name + ".csv"), rows)
    values = [p["refined_mm"] for p in predictions]
    if not all(b>a for a,b in zip(values,values[1:])):
        raise ValueError("Deflections failed the monotonicity check")
    if not all(r["downward"] and r["support_pass"] for r in quality):
        raise ValueError("Physical quality check failed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    run(parser.parse_args().output)
