$ErrorActionPreference = 'Stop'
$tag = 'aero/fea-bounded:1.1-foundation-r3'
$expected = 'sha256:b73d70afc297054bf644db852e8d8ed0bbd2423fecbcd5669194dd7460d9a763'
$image = docker image inspect $tag --format '{{.Id}}'
if ($LASTEXITCODE -ne 0 -or $image -ne $expected) { throw 'Unexpected solver image' }

$replay = 'replay-' + [guid]::NewGuid().ToString('N')
docker run --rm --pull=never --network none --cpus 4 --entrypoint /bin/sh --mount "type=bind,source=$PSScriptRoot,target=/case" -w /case $image -c "python3 run.py /case/$replay"
if ($LASTEXITCODE -ne 0) { throw 'Solver or physical quality check failed' }
$seal = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'seal.json') | ConvertFrom-Json
$compare = @('predictions.csv','quality.csv','mesh_checks.csv')
foreach ($span in @(1000,1500,2500)) { $compare += "runs/$span/strip.inp" }
foreach ($rel in $compare) {
    $hash = (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot "$replay/$rel") -Algorithm SHA256).Hash
    if ($hash -ne $seal.files.$rel) { throw "Replay mismatch in $rel" }
}
Write-Output "Matched sealed decks, predictions and checks in $replay"
