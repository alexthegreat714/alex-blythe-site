# GPT-6.2 astra | Week 2 blinded continuation

Use the three downward deflection magnitudes in the `refined_mm` column of `predictions.csv`. Together with 159.9468 mm for the previously accepted 2000 mm span, these give the four-span handoff.

| Span (mm) | Previous refined (mm) | Continuation (mm) | Absolute change (mm) | Allowed change (mm) | Mesh check | Solver wall time (s) |
|---:|---:|---:|---:|---:|:---|---:|
| 1000 | 10.01737 | 10.03144 | 0.01407 | 0.0501572 | Pass | 24.125 |
| 1500 | 50.77124 | 50.81869 | 0.04745 | 0.25409345 | Pass | 47.680 |
| 2500 | 386.1187 | 386.3358 | 0.21710 | 1.931679 | Pass | 111.490 |

The planned 12.5 × 5 × 2 mm C3D20R mesh halves each prior element dimension. Each solve reached full gravity load in four increments. All tip motions were downward and increased with span. The largest vertical support-balance error was 0.000012% after including the gravity assigned directly to fixed nodes. The largest absolute difference from the theoretical elastica was 0.466%. The estimates assume an ideal clamp and strip self-weight alone.

Each `runs/<span>/` directory contains the actual deck, solver log, node output and convergence records. The continuation used CalculiX 2.20 with the original image digest and only this directory mounted. Run `.\reproduce.ps1` from PowerShell to produce a fresh replay and compare its decks and numeric results to the continuation seal. `timing.csv` records the three actual solver wall times. `mesh_checks.csv` and `quality.csv` contain the unrounded check calculations. The prior comparison values were transcribed from the first handoff.
