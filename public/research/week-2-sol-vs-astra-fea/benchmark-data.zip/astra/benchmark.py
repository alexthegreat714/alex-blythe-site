"""Build and run the two prespecified meshes. Python standard library only."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import time

SPANS = (1000, 1500, 2000, 2500)
MESHES = {"initial": (50, 20, 8), "refined": (25, 10, 4)}
W = 2.675e-9 * 9806.65 * 40 * 8  # N/mm
EI = 61000 * 40 * 8**3 / 12  # N mm^2
# CalculiX C3D20 corner ordering, then lower, upper, and vertical edge mids.
OFFSETS = [(0,0,0),(2,0,0),(2,2,0),(0,2,0),
           (0,0,2),(2,0,2),(2,2,2),(0,2,2),
           (1,0,0),(2,1,0),(1,2,0),(0,1,0),
           (1,0,2),(2,1,2),(1,2,2),(0,1,2),
           (0,0,1),(2,0,1),(2,2,1),(0,2,1)]


def deck(span, mesh):
    dx, dy, dz = MESHES[mesh]
    nx, ny, nz = span // dx, 40 // dy, 8 // dz
    points = {}
    elements = []
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                conn = []
                for a, b, c in OFFSETS:
                    key = (2*i+a, 2*j+b, 2*k+c)
                    conn.append(points.setdefault(key, len(points)+1))
                elements.append(conn)
    lines = ["*HEADING", f"Self-weight cantilever {span} mm, {mesh}", "*NODE"]
    root = []
    for (i, j, k), n in points.items():
        lines.append(f"{n},{i*dx/2:g},{j*dy/2-20:g},{k*dz/2-4:g}")
        if i == 0:
            root.append(n)
    tip = points[(2*nx, ny, nz)]
    lines.append("*ELEMENT,TYPE=C3D20R,ELSET=STRIP")
    for n, conn in enumerate(elements, 1):
        # At most 16 values per line.
        lines.append(",".join(map(str, [n] + conn[:15])) + ",")
        lines.append(",".join(map(str, conn[15:])))
    lines.append("*NSET,NSET=ROOT")
    for i in range(0, len(root), 12):
        lines.append(",".join(map(str, root[i:i+12])))
    lines += ["*NSET,NSET=TIP", str(tip), "*MATERIAL,NAME=AL6060", "*ELASTIC",
              "61000,0.30", "*DENSITY", "2.675e-9",
              "*SOLID SECTION,ELSET=STRIP,MATERIAL=AL6060", "*BOUNDARY",
              "ROOT,1,3", "*STEP,NLGEOM,INC=200", "*STATIC",
              "0.25,1,0.000001,0.25", "*DLOAD", "STRIP,GRAV,9806.65,0,0,-1",
              "*NODE PRINT,NSET=TIP,FREQUENCY=99999", "U",
              "*NODE PRINT,NSET=ROOT,TOTALS=ONLY,FREQUENCY=99999", "RF", "*END STEP"]
    return "\n".join(lines)+"\n", len(points), len(elements)


def elastica(span):
    # Dimensionless arc coordinate u = s/L. Angle positive downward.
    # Integrate backward from the tip with zero tip moment, bisect on tip angle.
    lam = W * span**3 / EI
    def integrate(angle):
        state = (angle, 0.0, 0.0)
        def rhs(u, v):
            return (v[1], -lam*(1-u)*math.cos(v[0]), math.sin(v[0]))
        def advance(v, d, h):
            return tuple(x + h*y for x, y in zip(v, d))
        h = -1/128
        for i in range(128):
            u = 1+i*h
            a = rhs(u, state)
            b = rhs(u+h/2, advance(state, a, h/2))
            c = rhs(u+h/2, advance(state, b, h/2))
            d = rhs(u+h, advance(state, c, h))
            state = tuple(x+h*(p+2*q+2*r+t)/6 for x,p,q,r,t in zip(state,a,b,c,d))
        return state
    low, high = 0., math.pi/2
    assert integrate(low)[0] < 0 < integrate(high)[0]
    for _ in range(50):
        mid = (low+high)/2
        if integrate(mid)[0] > 0:
            high = mid
        else:
            low = mid
    return -span*integrate((low+high)/2)[2]


def csv_file(path, fields, rows):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def dat_vector(dat, heading, length):
    matches = re.findall(r"^\s*"+heading+r"[^\n]*?time\s+(\S+)[^\n]*\n\s*\n?([^\n]+)",
                         dat, flags=re.MULTILINE | re.IGNORECASE)
    stamp, row = matches[-1]
    assert abs(float(stamp)-1) < 1e-8, (heading, stamp)
    vals = [float(x) for x in row.split()]
    assert len(vals) == length, (heading, vals)
    return vals


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output")
    dest = Path(parser.parse_args().output)
    dest.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, OMP_NUM_THREADS="1", CCX_NPROC_STIFFNESS="1",
               CCX_NPROC_RESULTS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    timings, quality, pred = [], [], []
    for span in SPANS:
        values = {}
        exact = elastica(span)
        for mesh in MESHES:
            case = dest / f"{span}_{mesh}"
            case.mkdir()
            inp, nodes, elements = deck(span, mesh)
            (case/"strip.inp").write_text(inp)
            with (case/"solver.log").open("w") as logfile:
                start = time.perf_counter()
                run = subprocess.run(["ccx", "-i", "strip"], cwd=case, stdout=logfile,
                                     stderr=subprocess.STDOUT, env=env)
                elapsed = time.perf_counter()-start
            log = (case/"solver.log").read_text()
            if run.returncode or "Job finished" not in log or "*ERROR" in log:
                raise RuntimeError(f"Solver failure in {case}")
            dat = (case/"strip.dat").read_text()
            uz = dat_vector(dat, "displacements", 4)[-1]
            rz = dat_vector(dat, "total force", 3)[-1]
            sta = (case/"strip.sta").read_text().splitlines()[-1].split()
            assert abs(float(sta[4])-1.0) < 1e-8, sta
            values[mesh] = abs(uz)
            timings.append(dict(span_mm=span, mesh=mesh, nodes=nodes, elements=elements,
                                converged_increments=sta[1], solver_wall_s=f"{elapsed:.6f}"))
            err = abs(rz-W*span)/(W*span)
            quality.append(dict(span_mm=span, mesh=mesh, tip_uz_mm=uz, root_rz_N=rz,
                                weight_N=W*span, reaction_error_pct=100*err,
                                downward=uz<0, reaction_pass=err<=0.001,
                                linear_beam_mm=W*span**4/(8*EI), elastica_mm=exact))
            print(span, mesh, uz, rz, f"{elapsed:.3f} s", flush=True)
        pred.append(dict(span_mm=span, initial_mm=values["initial"], refined_mm=values["refined"]))
    csv_file(dest/"timing.csv", timings[0], timings)
    csv_file(dest/"quality.csv", quality[0], quality)
    csv_file(dest/"predictions.csv", pred[0], pred)
    mesh_checks = []
    for row in pred:
        delta = abs(row["initial_mm"]-row["refined_mm"])
        limit = max(0.02, 0.005*row["refined_mm"])
        mesh_checks.append(dict(span_mm=row["span_mm"], difference_mm=delta,
                                tolerance_mm=limit, passed=delta<=limit))
    csv_file(dest/"mesh_checks.csv", mesh_checks[0], mesh_checks)
    for name in MESHES:
        vals = [r[name+"_mm"] for r in pred]
        assert all(b>a for a,b in zip(vals,vals[1:]))
    print("All reaction checks pass:", all(r["reaction_pass"] for r in quality))
    print("All mesh checks pass:", all(r["passed"] for r in mesh_checks))


if __name__ == "__main__":
    main();
