"""Reproduce Astra's follow-up scores and verify its third-mesh file seal."""
import csv
import hashlib
import json
import math
from pathlib import Path
from statistics import mean

from score import ROOT, verified_predictions

extra = ROOT / "astra/continuation"
files = json.loads((extra/"seal.json").read_text(encoding="utf-8-sig"))["files"]
assert {"predictions.csv", "proposal.md"} <= set(files)
assert sum(name.endswith(".inp") for name in files) >= 3
for name, expected in files.items():
    path = (extra/name).resolve()
    assert path.is_relative_to(extra)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected.lower(), name

with (extra/"predictions.csv").open(encoding="utf-8-sig",newline="") as f:
    records = list(csv.DictReader(f))
    fields = records[0].keys()
column = next((key for key in (
    "continued_mm", "continuation_mm", "new_mm", "further_refined_mm", "third_mesh_mm", "refined_mm", "tip_down_mm", "prediction_mm"
) if key in fields),None)
if column is None:
    raise ValueError(f"Unknown continuation prediction column: {list(fields)}")
third = {int(r["span_mm"]):float(r[column]) for r in records}
assert sorted(third) == [1000,1500,2500]
assert all(math.isfinite(v) and v>0 for v in third.values())
prior = verified_predictions("astra")
with (ROOT/"reference.csv").open(encoding="utf-8-sig",newline="") as f:
    measured = {int(r["span_mm"]):float(r["measured_mm"]) for r in csv.DictReader(f)}
rows=[]
for span,obs in measured.items():
    old=prior[span]["refined"]
    new=third.get(span,old)
    gap=abs(old-new)
    rows.append(dict(span_mm=span,previous_mm=old,latest_mm=new,test_mm=obs,
                     delta_mm=new-obs,delta_pct=100*(new-obs)/obs,
                     mesh_change_pct=100*gap/new,mesh_pass=gap<=max(.02,.005*new),
                     rerun=span in third))
with (ROOT/"continuation-scores.csv").open("w",encoding="utf-8",newline="") as f:
    writer=csv.DictWriter(f,fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps({"spans":rows,"mape_pct":mean(abs(x["delta_pct"]) for x in rows)},indent=2))
