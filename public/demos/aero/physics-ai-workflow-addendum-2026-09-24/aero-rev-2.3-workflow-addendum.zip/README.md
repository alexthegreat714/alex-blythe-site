# Aero Rev 2.3 workflow addendum - 2026-09-24

Cumulative public 2.3 source plus benchmark, review-only screening and bounded
optional-experiment control. Extract into a NEW directory; do not replace an active
installation. Read Aero/docs/PHYSICS_AI_WORKFLOW_ADDENDUM.md first.

This is not a completed multi-model milestone or a deployed private app.
Transolver reference execution is BLOCKED_HUMAN_ACTION; DoMINO is research-only.
No weights, licensed geometry, private corpus or machine credentials are included.
No required engineering gate is relaxed. No solver run or training is launched.

Use an isolated Python 3.12 environment, install requirements-test.txt, then run:
python -m pytest Aero/tests -q
python -m Aero.physics_ai list

Synthetic protocol tests do not validate physics or demonstrate real CFD savings.
