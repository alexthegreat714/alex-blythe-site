"""Durable hypothesis/experiment control delegating to existing solver adapters."""
import copy
from datetime import datetime, timezone
import functools
import json
from pathlib import Path
import re
import time
import uuid
from Aero.fea.bounded.controller import WorkerLease
from Aero.openfoam_pipeline import _atomic_json
from .contracts import validate_contract,build_baseline,digest,assess_changes,replace,source_case_identity,differences
from .gate import evaluate

def now():return datetime.now(timezone.utc).isoformat()

def serialized(fn):
    @functools.wraps(fn)
    def wrapped(self,*args,**kwargs):
        if not self.lease.acquire(False):raise RuntimeError('Campaign control busy or interrupted; stale lease requires human review')
        try:return fn(self,*args,**kwargs)
        finally:self.lease.release()
    return wrapped

class CampaignController:
    def __init__(self,root,adapters=None):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.lease=WorkerLease(self.root);self.adapters=adapters or {}

    def path(self,cid):
        if not re.fullmatch('[a-f0-9]{32}',cid):raise ValueError('Invalid campaign ID')
        p=(self.root/cid).resolve();p.relative_to(self.root)
        return p

    def get(self,cid):
        doc=json.loads((self.path(cid)/'state.json').read_text())
        if digest(doc['payload'])!=doc['sha256']:raise ValueError('Campaign state integrity failed')
        row=doc['payload']; previous=None
        for event in row['events']:
            expected=event['sha256'];body={k:v for k,v in event.items() if k!='sha256'}
            if body['previous_sha256']!=previous or digest(body)!=expected:raise ValueError('Event chain failed')
            previous=expected
        if row['state']!='DRAFT':
            for name,key in [('contract.json','contract_sha256'),('baseline.json','baseline_sha256')]:
                if digest(json.loads((self.path(cid)/name).read_text()))!=row[key]:raise ValueError('Frozen artifact changed')
        for witness in row.get('physics_ai_witnesses',[]):
            from Aero.physics_ai.evidence import verify_result
            verify_result(witness['record'],witness['evidence_root'],witness['registry'],row['contract'])
        return row

    def list(self):
        return [{'campaign_id':p.parent.name,'state':self.get(p.parent.name)['state']} for p in sorted(self.root.glob('*/state.json'))]

    def save(self,row,event,**details):
        body={'at':now(),'kind':event,'details':details,'previous_sha256':row['events'][-1]['sha256'] if row['events'] else None}
        row['events'].append(dict(body,sha256=digest(body)))
        _atomic_json(self.path(row['campaign_id'])/'state.json',{'payload':row,'sha256':digest(row)})

    @serialized
    def create(self,contract):
        contract=validate_contract(contract); cid=uuid.uuid4().hex;self.path(cid).mkdir()
        row={'campaign_id':cid,'state':'DRAFT','contract':contract,'contract_sha256':digest(contract),
            'created_at':now(),'current':{'model':copy.deepcopy(contract['model'])},'events':[],'runs':[],
            'diagnoses':[],'proposals':[],'reviews':{},'next_proposal':None}
        self.save(row,'CONTRACT_DRAFT_CREATED');return row

    @serialized
    def freeze(self,cid,fingerprint):
        # Exposed only behind existing separate human-approval credential policy.
        row=self.get(cid)
        if row['state']!='DRAFT' or fingerprint!=row['contract_sha256']:raise ValueError('Exact draft fingerprint required')
        contract=row['contract'];parent=contract.get('parent_sha256')
        if contract['version']>1:
            matches=[self.get(p.parent.name) for p in self.root.glob('*/state.json') if p.parent.name!=cid]
            prior=next((x for x in matches if x['contract_sha256']==parent and x['state']!='DRAFT' and x['contract']['contract_id']==contract['contract_id'] and x['contract']['version']==contract['version']-1),None)
            if prior is None:raise ValueError('Verified prior contract revision required')
            row['revision_review']={'parent_campaign_id':prior['campaign_id'],'changes':differences(prior['contract'],contract),
                'reason':contract['revision_reason'],'authority':'human_ui'}
        elif parent:raise ValueError('Version one cannot assert a parent')
        baseline=build_baseline(contract)
        _atomic_json(self.path(cid)/'contract.json',contract);_atomic_json(self.path(cid)/'baseline.json',baseline)
        row.update(baseline_sha256=digest(baseline),state='READY',authorized_at=now(),started_epoch=time.time())
        row['operator_approval']={'fingerprint':fingerprint,'approved_at':now(),'authority':'human_ui',
            'scope':'bounded campaign; only declared numerical mutations; no physical changes'}
        self.save(row,'CONTRACT_AND_BASELINE_FROZEN');return row

    @serialized
    def diagnose(self,cid,diagnosis):
        row=self.get(cid)
        if row['state']!='AWAITING_DIAGNOSIS':raise ValueError('Diagnosis requires a completed gate assessment')
        latest=row['runs'][-1]['gate'];known={r['id'] for r in latest['checks']}
        if set(diagnosis)!={'observation','hypotheses'} or not isinstance(diagnosis['observation'],str) or not diagnosis['observation'].strip():raise ValueError('Observation required')
        hs=diagnosis['hypotheses']
        if not isinstance(hs,list) or len(hs)<2 or len(hs)>8:raise ValueError('Two to eight competing hypotheses required')
        seen=set()
        for h in hs:
            required={'id','parent_id','statement','supporting_evidence','contradicting_evidence','missing_evidence','confidence','discriminating_test'}
            if set(h)!=required or h['id'] in seen:raise ValueError('Invalid hypothesis schema')
            if h['parent_id'] is not None and h['parent_id'] not in seen:raise ValueError('Parent must precede child; no cycles')
            seen.add(h['id'])
            if h['confidence'] not in ('low','medium','high'):raise ValueError('Confidence is a qualitative inference')
            if not h['statement'] or not h['discriminating_test'] or not isinstance(h['missing_evidence'],list):raise ValueError('Hypothesis and falsifiable test required')
            for key in ('supporting_evidence','contradicting_evidence'):
                if not isinstance(h[key],list) or not set(h[key]).issubset(known):raise ValueError('Unknown evidence reference')
        item=dict(copy.deepcopy(diagnosis),id=uuid.uuid4().hex,gate_sha256=digest(latest),provenance='INFERRED',created_at=now())
        row['diagnoses'].append(item);row['state']='AWAITING_PROPOSAL';self.save(row,'HYPOTHESIS_TREE_RECORDED',diagnosis_id=item['id']);return row

    @serialized
    def propose(self,cid,proposal):
        row=self.get(cid)
        if row['state'] not in ('AWAITING_PROPOSAL','READY_NEXT'):raise ValueError('A current diagnosis is required before mutation')
        required={'hypothesis_id','changes','justification','expected_if_correct','expected_if_incorrect','compare_quantities','collect_evidence','estimated_seconds','information_value','information_rationale'}
        if set(proposal)!=required:raise ValueError('Invalid mutation proposal schema')
        diagnosis=row['diagnoses'][-1]
        if proposal['hypothesis_id'] not in {h['id'] for h in diagnosis['hypotheses']}:raise ValueError('Unknown hypothesis')
        for key in ('justification','expected_if_correct','expected_if_incorrect','information_rationale'):
            if not isinstance(proposal[key],str) or not proposal[key].strip():raise ValueError('Falsifying outcome and engineering justification required')
        for key in ('compare_quantities','collect_evidence'):
            if not isinstance(proposal[key],list) or not proposal[key] or not all(isinstance(x,str) and x.strip() for x in proposal[key]):raise ValueError('Comparison/evidence plan requires named quantities')
        from .contracts import number
        cost=number(proposal['estimated_seconds']);information=number(proposal['information_value'])
        if cost<=0 or not 0<information<=1:raise ValueError('Bounded positive cost and information estimate required')
        proposed=copy.deepcopy(row['current'])
        if not isinstance(proposal['changes'],list) or len(proposal['changes'])!=1:raise ValueError('One discriminating numerical dimension per experiment')
        change=proposal['changes'][0]
        if set(change)!={'path','value'}:raise ValueError('Exact field/value mutation required')
        replace(proposed,change['path'],change['value'])
        authority=assess_changes(row['contract'],row['current'],proposed)
        item=dict(copy.deepcopy(proposal),id=uuid.uuid4().hex,diagnosis_id=diagnosis['id'],
            source_gate_sha256=digest(row['runs'][-1]['gate']),source_model_sha256=digest(row['current']['model']),
            proposed=proposed,authority=authority,provenance='PROPOSED',score=information/cost)
        row['proposals'].append(item)
        if authority['allowed']:
            eligible=[p for p in row['proposals'] if p['diagnosis_id']==diagnosis['id'] and p['authority']['allowed']]
            best=max(eligible,key=lambda p:p['score']);row['next_proposal']=best['id'];row['state']='READY_NEXT'
        self.save(row,'MUTATION_PROPOSED' if authority['allowed'] else 'MUTATION_BLOCKED',proposal_id=item['id'],authority=authority)
        if any('DRIFT' in s for s in authority['reasons']):self.save(row,'ASSUMPTION_DRIFT',proposal_id=item['id'],changes=authority['cumulative_changes'])
        return row

    @serialized
    def review(self,cid,check_id,status,rationale,fingerprint):
        row=self.get(cid)
        if not row['runs'] or row['runs'][-1].get('gate') is None:raise ValueError('Evaluated evidence required')
        evidence=row['runs'][-1]['evidence']
        if fingerprint!=digest(evidence) or status not in ('PASS','FAIL','INCONCLUSIVE') or not rationale.strip():raise ValueError('Exact evidence fingerprint and reason required')
        check=next((c for c in row['contract']['checks'] if c['id']==check_id),None)
        if not check or check['kind']!='review':raise ValueError('Human review cannot override deterministic gates')
        row['reviews'][check_id]={'status':status,'rationale':rationale,'evidence_sha256':fingerprint,
            'contract_sha256':row['contract_sha256'],'authority':'human_ui','reviewed_at':now()}
        run=row['runs'][-1];baseline=json.loads((self.path(cid)/'baseline.json').read_text())
        run.setdefault('gate_history',[]).append(run['gate'])
        run['gate']=evaluate(row['contract'],baseline,evidence,run['evidence_root'],row['current']['model'],review_receipts=row['reviews'])
        row['state']='ACCEPTED' if run['gate']['overall_disposition']=='PASS' else 'AWAITING_DIAGNOSIS'
        self.save(row,'INDEPENDENT_REVIEW_RECORDED',check_id=check_id);return row

    @serialized
    def tick(self,cid):
        row=self.get(cid);contract=row['contract'];adapter=self.adapters.get(contract['backend'])
        if row['state'] in ('DISPATCHING','EXTRACTION_UNCERTAIN'):return row # never duplicate after crash
        if row['state'] not in ('READY','READY_NEXT','RUNNING','AWAITING_BACKEND_APPROVAL'):return row
        if not adapter:raise RuntimeError('Existing solver adapter unavailable')
        if row['state'] in ('RUNNING','AWAITING_BACKEND_APPROVAL'):
            run=row['runs'][-1];status=adapter.status(run['reference'])
            if status.get('needs_human'):
                row['state']='AWAITING_BACKEND_APPROVAL';self.save(row,'EXISTING_BACKEND_APPROVAL_REQUIRED');return row
            if row['state']=='AWAITING_BACKEND_APPROVAL':row['state']='RUNNING';self.save(row,'BACKEND_APPROVAL_VERIFIED')
            if not status['terminal']:return row
            row['state']='EXTRACTION_UNCERTAIN';self.save(row,'EXTRACTION_STARTED')
            evidence,root=adapter.extract(run['reference'],contract,row['current']['model'])
            run.update(evidence=evidence,evidence_root=str(root))
            _atomic_json(self.path(cid)/(run['id']+'_evidence.json'),evidence)
            baseline=json.loads((self.path(cid)/'baseline.json').read_text())
            run['gate']=evaluate(contract,baseline,evidence,root,row['current']['model'],review_receipts=row['reviews'])
            _atomic_json(self.path(cid)/(run['id']+'_gate.json'),run['gate'])
            row['state']='ACCEPTED' if run['gate']['overall_disposition']=='PASS' else 'AWAITING_DIAGNOSIS'
            self.save(row,'ENGINEERING_VALIDITY_GATE',gate=run['gate']);return row
        remaining=contract['budget']['max_wall_seconds']-(time.time()-row['started_epoch'])
        if len(row['runs'])>=contract['budget']['max_runs'] or remaining<=0:
            row['state']='BUDGET_STOP';self.save(row,'CAMPAIGN_BUDGET_STOP');return row
        if row['state']=='READY_NEXT':
            p=next(p for p in row['proposals'] if p['id']==row['next_proposal'])
            if p['source_model_sha256']!=digest(row['current']['model']) or p['source_gate_sha256']!=digest(row['runs'][-1]['gate']):raise ValueError('Stale proposal')
            authority=assess_changes(contract,row['current'],p['proposed'])
            if not authority['allowed']:raise ValueError('Mutation no longer authorized')
            if p['estimated_seconds']>remaining:
                row['state']='BUDGET_STOP';self.save(row,'INSUFFICIENT_EXPERIMENT_BUDGET');return row
            row['current']=copy.deepcopy(p['proposed']);self.save(row,'CONTRACT_ALIGNMENT_RECHECKED',authority=authority)
        # Independently recheck actual model against original contract, including cumulative drift.
        original={'model':contract['model']}
        if row['current']!=original and not assess_changes(contract,original,row['current'])['allowed']:raise ValueError('ASSUMPTION_DRIFT blocks dispatch')
        baseline=json.loads((self.path(cid)/'baseline.json').read_text())
        if source_case_identity(row['current']['model'])!=baseline['source_case_identity']:
            row['state']='SOURCE_DRIFT_BLOCKED';self.save(row,'ASSUMPTION_DRIFT',reason='Native input tree changed after freeze');return row
        timeout=row['current']['model'].get('numerics',{}).get('timeout_sec',360)
        if timeout>remaining:row['state']='BUDGET_STOP';self.save(row,'INSUFFICIENT_RUN_BUDGET');return row
        row['state']='DISPATCHING';self.save(row,'DISPATCH_INTENT',model_sha256=digest(row['current']['model']))
        # Persist intent before side effect. An ambiguous crash requires human reconciliation, never automatic retry.
        reference=adapter.start(copy.deepcopy(row['current']['model']),campaign_id=cid,contract_sha256=row['contract_sha256'])
        row['runs'].append({'id':uuid.uuid4().hex,'reference':reference,'started_at':now(),'model_sha256':digest(row['current']['model'])})
        row['state']='RUNNING';self.save(row,'EXISTING_WORKER_DISPATCHED',reference=reference);return row

    def run_bounded(self,cid,stop_event,poll_seconds=5):
        """Scheduler-callable loop, not a new solver queue. Stops on missing evidence/approval."""
        while not stop_event.is_set():
            row=self.tick(cid)
            if row['state'] not in ('READY','READY_NEXT','RUNNING'):return row
            stop_event.wait(max(1,min(poll_seconds,30)))
        return self.get(cid)

    @serialized
    def attach_physics_ai(self,cid,record,evidence_root,registry):
        """Optional witness custody only; does not authorize mutation or advance a campaign."""
        from Aero.physics_ai.evidence import verify_result
        row=self.get(cid)
        if row['state']=='DRAFT':raise ValueError('Frozen engineering contract required')
        summary=verify_result(record,evidence_root,registry,row['contract'])
        witnesses=row.setdefault('physics_ai_witnesses',[])
        if any(w['summary']['result_sha256']==summary['result_sha256'] for w in witnesses):
            raise ValueError('Witness already retained')
        witnesses.append({'summary':summary,'record':copy.deepcopy(record),
            'evidence_root':str(Path(evidence_root).resolve()),'registry':copy.deepcopy(registry),
            'provenance':'PHYSICS_AI_RESULT','interpretation':'SUPPORTING_ONLY'})
        self.save(row,'PHYSICS_AI_WITNESS_RETAINED',summary=summary)
        return row

    @serialized
    def record_loop_failure(self,cid,error_type):
        row=self.get(cid)
        row['last_control_error']={'type':error_type,'at':now(),'automatic_retry':False}
        self.save(row,'CONTROL_LOOP_STOPPED_ON_ERROR',error_type=error_type)
