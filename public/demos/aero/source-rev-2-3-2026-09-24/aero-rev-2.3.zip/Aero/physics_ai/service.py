"""Optional adapter boundary. Registered pretrained adapters deliberately fail closed."""
from .registry import load_registry,get_model,check_applicability,capability

class PhysicsAI:
    def __init__(self,cache_root,registry=None,reference_worker=None):
        self.cache_root=cache_root
        self.registry=registry or load_registry()
        self.reference_worker=reference_worker

    def list_models(self):
        return [{'model_id':m['model_id'],**capability(m,self.cache_root)} for m in self.registry['models']]

    def preflight(self,model_id,case,outputs):
        model=get_model(model_id,self.registry)
        status=capability(model,self.cache_root)
        if self.reference_worker and model['adapter']=='physicsnemo_domino':
            from .domino import inspect_bundle
            status=inspect_bundle(self.reference_worker,model)
        return {'capability':status,
                'applicability':check_applicability(model,case,outputs)}

    def predict(self,model_id,case,requested_outputs,*,acknowledge_research=False):
        report=self.preflight(model_id,case,requested_outputs)
        if self.reference_worker and get_model(model_id,self.registry)['adapter']=='physicsnemo_domino':
            from .domino import execute_reference
            return {**report,**execute_reference(self.reference_worker,get_model(model_id,self.registry),
                    case,requested_outputs,acknowledge_research=acknowledge_research)}
        return {'status':report['capability']['status'],'executed':False,**report,
                'reason':'No configured supported reference worker; conventional workflow remains available',
                'conventional_workflow_available':True,'qualification_override':False}
