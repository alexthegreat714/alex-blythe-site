"""Retain an executed reference witness using the existing evidence contract.

This receipt is explicitly not an approved campaign acceptance contract. Attaching
evidence to a real campaign still requires that campaign's contract and controller.
"""
import json
from pathlib import Path
from .evidence import build_result, retain_result, verify_result
from .integration import annotate_gate
from .registry import file_hash


def retain_reference(result, config, registry, evidence_root):
    if result.get('status') != 'REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED':
        raise ValueError('Completed reference execution required')
    root = Path(evidence_root).resolve()
    bundle = Path(config['bundle']).resolve()
    out = Path(result['artifact_directory']).resolve()
    def relative(path):
        return path.resolve().relative_to(root).as_posix()
    execution = json.loads((out / 'EXECUTION_RESULT.json').read_text())
    receipt = json.loads((out / 'COMPLETION.json').read_text())
    if execution['state'] != 'INFERENCE_COMPLETED':
        raise ValueError('Worker did not complete')
    if file_hash(out / 'prediction.npz') != receipt['prediction_sha256'] or receipt['prediction_sha256'] != result['prediction_sha256']:
        raise ValueError('Prediction custody changed')
    contract = json.loads((bundle / 'REFERENCE_EXECUTION_CONTRACT.json').read_text())
    if file_hash(bundle / 'REFERENCE_EXECUTION_CONTRACT.json') != config['contract_sha256']:
        raise ValueError('Contract changed')
    input_files = ['reference/drivaer_1.stl', 'checkpoints/config.yaml', 'checkpoints/scaling_factors.pkl',
                   'upstream/conf/config.yaml', 'upstream/main.py', 'upstream/design_datapipe.py',
                   'REFERENCE_EXECUTION_CONTRACT.json', 'DOWNLOAD_PLAN.json']
    # Recheck the identities actually verified before execution, not only current files.
    for name in input_files:
        if name in receipt['inputs'] and file_hash(bundle / name) != receipt['inputs'][name]:
            raise ValueError('Executed input changed: ' + name)
    if file_hash(bundle / 'DOWNLOAD_PLAN.json') != config['download_plan_sha256']:
        raise ValueError('Download plan changed')
    record = build_result(registry=registry, model_id='domino-drivaerml-surface-1.0',
        contract=contract, case=receipt['case'], requested_outputs=['surface_pressure', 'wall_shear_stress'],
        outputs={'scalar_observables': {}}, root=root,
        input_paths=[relative(bundle / p) for p in input_files] + [relative(out / 'COMPLETION.json')],
        field_paths=[relative(out / 'prediction.npz')],
        checkpoint_path=relative(bundle / 'checkpoints/DoMINO.0.501.mdlus'),
        configuration={'seed': 0, 'precision': 'float32', 'deterministic': False,
                       'workflow': 'pinned_upstream_reference_only'},
        runtime={'hardware': execution['hardware'], 'software_versions': execution['software_versions'],
                 'wall_seconds': execution['wall_seconds'], 'worker_receipt': relative(out / 'COMPLETION.json')},
        code_versions={'preprocessing': file_hash(bundle / 'upstream/design_datapipe.py'),
                       'inference': file_hash(bundle / 'upstream/main.py'),
                       'postprocessing': receipt['worker_sha256']})
    retained = retain_result(root, record)
    verification = verify_result(record, root, registry, contract)
    prior = {'overall_disposition': 'INCONCLUSIVE',
             'context': 'Reference witness boundary only; no approved engineering campaign acceptance contract'}
    gate = annotate_gate(prior, [record], root, registry, contract)
    report = {'witness': relative(retained), 'verification': verification,
              'dispatch_model_entry': receipt.get('model_entry_at_dispatch', 'NOT_RETAINED_IN_INITIAL_ADAPTER_ATTEMPT'),
              'retention_registry_version': registry['version'],
              'contract_kind': 'REFERENCE_EXECUTION_NOT_CAMPAIGN_ACCEPTANCE',
              'active_campaign_attached': False, 'gate': gate}
    with (out / 'WITNESS_INGESTION.json').open('x') as stream:
        json.dump(report, stream, indent=2)
    return report
