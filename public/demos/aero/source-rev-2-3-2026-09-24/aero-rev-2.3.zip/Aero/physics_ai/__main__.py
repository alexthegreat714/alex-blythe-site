"""Optional Physics-AI CLI. Explicit reference replay only; no automatic downloads."""
import argparse
import json
from pathlib import Path
from .service import PhysicsAI

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['list','reference'])
    parser.add_argument('--cache',type=Path,default=Path(__file__).resolve().parents[1]/'.runtime/physics-ai/checkpoints')
    parser.add_argument('--worker-config',type=Path)
    parser.add_argument('--acknowledge-research',action='store_true')
    parser.add_argument('--evidence-root',type=Path,help='Optional existing root containing bundle and output directories')
    args=parser.parse_args()
    if args.command=='list':
        result={'revision':'2.3','models':PhysicsAI(args.cache).list_models(),
                'pretrained_inference':'OPTIONAL_PINNED_DOMINO_REFERENCE_ONLY','automatic_download':False}
    else:
        if not args.worker_config:parser.error('reference requires --worker-config')
        from .domino import MODEL_ID,GEOMETRY
        config=json.loads(args.worker_config.read_text())
        service=PhysicsAI(args.cache,reference_worker=config)
        result=service.predict(MODEL_ID,
            {'case_id':'DrivAerML-run-1','geometry_sha256':GEOMETRY,
             'geometry_family':'automotive_external_drivaer','mesh_type':'surface_point_cloud',
             'dimensionality':3,'regime':'time_averaged_external_aerodynamics',
             'conventional_solver':'OpenFOAM'},
            ['surface_pressure','wall_shear_stress'],acknowledge_research=args.acknowledge_research)
        if args.evidence_root and result['status']=='REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED':
            from .reference_evidence import retain_reference
            result['witness_ingestion']=retain_reference(result,config,service.registry,args.evidence_root)
    print(json.dumps(result,indent=2))
    if args.command=='reference' and result['status']!='REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED':
        raise SystemExit(1)

if __name__=='__main__':main()
