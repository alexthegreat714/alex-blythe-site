# Aero Rev 2.3 Transolver addendum - 2026-09-24

Cumulative workflow-addendum source plus the NVIDIA Transolver reference adapter.
Read Aero/docs/PHYSICS_AI_TRANSOLVER_REFERENCE.md first. Earlier documents inside
the cumulative archive describe their historical milestones; this README and the
new guide describe the current addendum. The NVIDIA adapter executed, but exact
checkpoint training/preprocessing and engineering accuracy remain NOT_ESTABLISHED.
The separate THUML Transolver++ model remains pending. Models are RESEARCH_ONLY.

Extract into a NEW directory, use an isolated Python 3.12 environment, install
requirements-test.txt, and run: python -m pytest Aero/tests -q
Discovery: python -m Aero.physics_ai list

No model weights, reference geometry, private corpus, credentials, raw runs or
employer data are included. Inference needs separately licensed/provisioned inputs
and an explicit research acknowledgement. Tests neither download models nor run
CFD. This is a source-module release, not a complete Aero service installation.
No private deployment, qualification change or neural-model validation is implied.
