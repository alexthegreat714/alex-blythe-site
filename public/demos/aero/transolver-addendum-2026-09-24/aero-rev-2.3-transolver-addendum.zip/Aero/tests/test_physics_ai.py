"""Software boundary tests only: synthetic registry/checkpoint, NO pretrained inference."""
import copy
import hashlib
import json
from pathlib import Path
import pytest
from Aero.engineering_validity.contracts import digest
from Aero.physics_ai.registry import load_registry,get_model,check_applicability,capability,evidence_independence,AXES
from Aero.physics_ai.evidence import build_result,retain_result,verify_result,conservation_check
from Aero.physics_ai.comparison import compare_observables
from Aero.physics_ai.integration import annotate_gate
from Aero.physics_ai.service import PhysicsAI
from Aero.tests.test_engineering_validity import contract,investigated

def fixture(tmp_path):
    # Explicit test double: these bytes are NOT a neural checkpoint.
    (tmp_path/'checkpoint.test').write_bytes(b'synthetic protocol test, no model')
    (tmp_path/'input.json').write_text('{"synthetic_case":true}')
    model=copy.deepcopy(load_registry()['models'][0])
    model.update(model_id='test-only',authority='SURROGATE_ONLY',training_solver='OpenFOAM',
        supported_outputs=['delta_p'],model_version='synthetic-1',adapter='TEST_DOUBLE')
    model['checkpoint']['sha256']=hashlib.sha256((tmp_path/'checkpoint.test').read_bytes()).hexdigest()
    model['training_envelope']={a:['synthetic'] for a in AXES}
    case={a:'synthetic' for a in AXES};case['conventional_solver']='OpenFOAM'
    registry={'schema':'aero.physics_model_registry.v1','version':'test','models':[model]}
    return registry,case

def result(tmp_path,registry=None,case=None,**changes):
    if registry is None:registry,case=fixture(tmp_path)
    args=dict(registry=registry,model_id='test-only',contract=contract(),case=case,
        requested_outputs=['delta_p'],outputs={'scalar_observables':{'delta_p':{'value':31.,'units':'Pa'}}},
        root=tmp_path,input_paths=['input.json'],field_paths=[],checkpoint_path='checkpoint.test',
        configuration={'seed':0,'precision':'float32','deterministic':True},
        runtime={'hardware':'synthetic','software_versions':{'test':'1'},'wall_seconds':0},
        code_versions={k:'a'*64 for k in ('preprocessing','postprocessing','inference')},test_double=True)
    args.update(changes)
    return build_result(**args),registry

def test_case1_in_distribution_test_double_custody_not_real_inference(tmp_path):
    r,registry=result(tmp_path);p=retain_result(tmp_path,r)
    summary=verify_result(json.loads(p.read_text()),tmp_path,registry,contract())
    assert summary['applicability']=='IN_DISTRIBUTION'
    assert summary['authority']=='RESEARCH_ONLY' and not summary['can_satisfy_qualification_gate']
    assert not summary['eligible_for_supporting_interpretation']

def test_case2_automotive_model_rejects_heat_exchanger():
    model=get_model('domino-drivaerml-surface-1.0')
    a=check_applicability(model,{'geometry_family':'internal_heat_exchanger'},['surface_pressure'])
    assert a['status']=='OUT_OF_DISTRIBUTION' and a['authority']=='RESEARCH_ONLY'

def test_case3_checkpoint_missing_structured(tmp_path):
    service=PhysicsAI(tmp_path)
    r=service.predict('domino-drivaerml-surface-1.0',{},['surface_pressure'])
    assert r['status']=='CHECKPOINT_MISSING' and not r['executed']
    assert r['conventional_workflow_available']

def sources(values):
    return [{'source_id':name,'source_type':kind,'observables':{'dp':{'value':v,'units':'Pa'}}}
        for name,kind,v in zip(['analytics','surrogate','solver'],
            ['FIRST_PRINCIPLES_RESULT','PHYSICS_AI_RESULT','CONVENTIONAL_SOLVER_RESULT'],values)]

@pytest.mark.parametrize('values',[(29,31,72),(29,68,71)])
def test_cases4_and5_disagreement_investigates_not_votes(values):
    r=compare_observables(sources(values),absolute_tolerance=5,relative_tolerance=0)
    assert r['disposition']=='INVESTIGATION_REQUIRED' and r['consensus_value'] is None
    assert r['mandatory_solver_gates_unchanged'] and len(r['hypothesis_prompts'])==4

def test_case6_all_agree_never_waives_missing_gate(tmp_path):
    r,registry=result(tmp_path)
    comparison=compare_observables(sources((29,29,29)),absolute_tolerance=0,relative_tolerance=0)
    assert comparison['disposition']=='AGREEMENT_IS_NOT_VALIDATION'
    gate={'overall_disposition':'INCONCLUSIVE','engineering_validity':{'numerical_status':'NOT_ESTABLISHED'},
        'recommended_action':'COLLECT_MORE_EVIDENCE'}
    annotated=annotate_gate(gate,[r],tmp_path,registry,contract())
    for k,v in gate.items():assert annotated[k]==v
    assert 'physics_ai_supporting_witnesses' not in gate

def test_case7_neural_conservation_failure_retained(tmp_path):
    r,registry=result(tmp_path,conservation=[{'signed_terms':[1,-.5],'scale':1,'limit':.01}])
    assert r['payload']['validity']=='FAIL'
    p=retain_result(tmp_path,r)
    assert verify_result(json.loads(p.read_text()),tmp_path,registry,contract())['validity']=='FAIL'
    with pytest.raises(FileExistsError):retain_result(tmp_path,r)

def test_case8_same_solver_is_not_independent(tmp_path):
    registry,case=fixture(tmp_path)
    assert evidence_independence(registry['models'][0],'OpenFOAM')['level']=='LOW'

def test_case9_unknown_metadata_fails_closed():
    model=get_model('transolver-plus-reference-pending')
    assert check_applicability(model,{},['anything'])['status']=='NOT_ESTABLISHED'
    assert evidence_independence(model)['level']=='UNKNOWN'

def test_case10_optional_ml_dependency_never_imported(tmp_path,monkeypatch):
    import builtins
    original=builtins.__import__
    def guarded(name,*args,**kwargs):
        if name.split('.')[0] in ('torch','physicsnemo','transformers'):raise AssertionError('ML dependency imported')
        return original(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',guarded)
    assert PhysicsAI(tmp_path).list_models()
    from Aero.engineering_validity.contracts import build_baseline
    assert build_baseline(contract())['predictions']

def test_case11_reproduction_key_tracks_configuration_not_timestamp(tmp_path):
    r,registry=result(tmp_path)
    again,_=result(tmp_path,registry=registry,case=r['payload']['case'])
    assert again['payload']['reproduction_key']==r['payload']['reproduction_key']
    changed,_=result(tmp_path,registry=registry,case=r['payload']['case'],configuration={'seed':1,'precision':'float32','deterministic':True})
    assert changed['payload']['reproduction_key']!=r['payload']['reproduction_key']

def test_case12_campaign_witness_does_not_queue_or_accept(tmp_path):
    ctl,cid,adapter=investigated(tmp_path)
    evidence_root=tmp_path/'surrogate';evidence_root.mkdir()
    r,registry=result(evidence_root)
    before=ctl.get(cid)
    after=ctl.attach_physics_ai(cid,r,evidence_root,registry)
    assert after['state']==before['state']=='AWAITING_PROPOSAL'
    assert after['proposals']==before['proposals'] and after['diagnoses']==before['diagnoses']
    assert len(adapter.starts)==1
    assert after['events'][-1]['kind']=='PHYSICS_AI_WITNESS_RETAINED'
    with pytest.raises(ValueError,match='already retained'):ctl.attach_physics_ai(cid,r,evidence_root,registry)
    (evidence_root/'input.json').write_text('changed input')
    with pytest.raises(ValueError,match='artifact changed'):ctl.get(cid)

def test_result_and_source_tampering_rejected(tmp_path):
    r,registry=result(tmp_path)
    altered=copy.deepcopy(r);altered['payload']['authority']='VALIDATED_SURROGATE'
    altered['sha256']=digest(altered['payload'])
    with pytest.raises(ValueError,match='authority escalation'):verify_result(altered,tmp_path,registry,contract())
    (tmp_path/'checkpoint.test').write_text('changed')
    with pytest.raises(ValueError):verify_result(r,tmp_path,registry,contract())

def test_cache_hash_mismatch_and_no_execution_even_when_available(tmp_path):
    registry,case=fixture(tmp_path);m=registry['models'][0];key=m['checkpoint']['sha256']
    (tmp_path/key).write_bytes(b'wrong')
    assert capability(m,tmp_path)['status']=='CHECKPOINT_HASH_MISMATCH'
    (tmp_path/key).write_bytes((tmp_path/'checkpoint.test').read_bytes())
    r=PhysicsAI(tmp_path,registry).predict('test-only',case,['delta_p'])
    assert r['capability']['model_available'] and r['status']=='ADAPTER_STUB_ONLY' and not r['executed']

def test_range_units_required_and_nonfinite_rejected(tmp_path):
    registry,case=fixture(tmp_path);m=registry['models'][0]
    m['training_envelope']['temperature_K']={'minimum':280,'maximum':310,'units':'K'}
    case['temperature_K']={'value':25,'units':'C'}
    assert check_applicability(m,case,['delta_p'])['status']=='NOT_ESTABLISHED'
    case['temperature_K']={'value':400,'units':'K'}
    assert check_applicability(m,case,['delta_p'])['status']=='OUT_OF_DISTRIBUTION'
    with pytest.raises(ValueError):conservation_check([float('nan')],1,.1)

def test_cross_contract_and_path_escape_rejected(tmp_path):
    r,registry=result(tmp_path);c=contract();c['version']=2
    with pytest.raises(ValueError):verify_result(r,tmp_path,registry,c)
    with pytest.raises(ValueError):result(tmp_path,registry=registry,case=r['payload']['case'],input_paths=['../outside'])

def test_recomputed_hash_cannot_promote_neural_validity(tmp_path):
    r,registry=result(tmp_path)
    r['payload']['validity']='PASS';r['sha256']=digest(r['payload'])
    with pytest.raises(ValueError,match='validity promotion'):verify_result(r,tmp_path,registry,contract())

def test_forged_balance_status_recomputed(tmp_path):
    r,registry=result(tmp_path,conservation=[{'signed_terms':[1,-.5],'scale':1,'limit':.01}])
    r['payload']['deterministic_checks'][0]['status']='PASS';r['sha256']=digest(r['payload'])
    with pytest.raises(ValueError,match='not reproduced'):verify_result(r,tmp_path,registry,contract())
