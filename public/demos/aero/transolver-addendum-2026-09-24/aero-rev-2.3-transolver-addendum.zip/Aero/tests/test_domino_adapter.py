"""Isolated adapter boundary tests. Real reference execution has a separate receipt."""
import json
from pathlib import Path
import subprocess
import pytest
from Aero.physics_ai import domino
from Aero.physics_ai.registry import get_model
from Aero.physics_ai.service import PhysicsAI


def setup(tmp_path):
    return ({'bundle': str(tmp_path / 'bundle'), 'output_root': str(tmp_path / 'out'),
             'runtime_volume': 'aero-test', 'docker': 'docker',
             'download_plan_sha256': '0' * 64, 'contract_sha256': '1' * 64},
            get_model(domino.MODEL_ID),
            {'case_id': 'DrivAerML-run-1', 'geometry_sha256': domino.GEOMETRY})


def test_research_ack_required(tmp_path):
    config, model, case = setup(tmp_path)
    r = domino.execute_reference(config, model, case, ['surface_pressure'])
    assert r['status'] == 'RESEARCH_ACKNOWLEDGEMENT_REQUIRED'
    assert not r['executed'] and not r['qualification_override']


def test_nonreference_case_never_dispatches(tmp_path):
    config, model, case = setup(tmp_path)
    case['case_id'] = 'HX-03'
    r = domino.execute_reference(config, model, case, ['surface_pressure'], acknowledge_research=True)
    assert r['status'] == 'REFERENCE_CASE_ONLY' and not r['executed']


def test_missing_bundle_structured(tmp_path):
    config, model, case = setup(tmp_path)
    r = domino.execute_reference(config, model, case, ['surface_pressure'], acknowledge_research=True)
    assert r['status'] == 'REFERENCE_BUNDLE_UNAVAILABLE' and r['conventional_workflow_available']


def test_unsupported_output(tmp_path):
    config, model, case = setup(tmp_path)
    assert domino.execute_reference(config, model, case, ['temperature'], acknowledge_research=True)['status'] == 'UNSUPPORTED_OUTPUT'


def test_missing_docker_no_crash(tmp_path, monkeypatch):
    config, model, case = setup(tmp_path)
    monkeypatch.setattr(domino, 'inspect_bundle', lambda *a: {'status': 'REFERENCE_BUNDLE_READY', 'verified_inputs': {}})
    def absent(*a, **kw):
        raise FileNotFoundError('Docker absent')
    monkeypatch.setattr(domino.subprocess, 'run', absent)
    r = domino.execute_reference(config, model, case, ['surface_pressure'], acknowledge_research=True)
    assert r['status'] == 'DEPENDENCY_UNAVAILABLE' and not r['executed']


@pytest.mark.parametrize('mode', ['success', 'failure', 'timeout'])
def test_dispatch_isolated_and_failures_retained(tmp_path, monkeypatch, mode):
    config, model, case = setup(tmp_path)
    monkeypatch.setattr(domino, 'inspect_bundle', lambda *a: {'status': 'REFERENCE_BUNDLE_READY', 'verified_inputs': {}})
    calls = []
    def fake(args, **kwargs):
        calls.append(args)
        if args[1:3] == ['image', 'inspect']:
            return subprocess.CompletedProcess(args, 0, '[{"Id":"synthetic-image"}]', '')
        if args[1] == 'run':
            assert args[args.index('--network') + 1] == 'none'
            assert '--read-only' in args and '--pull' in args and 'never' in args
            assert args[args.index('--memory') + 1] == args[args.index('--memory-swap') + 1]
            assert kwargs['timeout'] == 1860
            out = next((tmp_path / 'out').iterdir())
            if mode == 'timeout':
                raise subprocess.TimeoutExpired(args, 1860)
            if mode == 'success':
                (out / 'EXECUTION_RESULT.json').write_text('{"state":"INFERENCE_COMPLETED"}')
                (out / 'prediction.npz').write_bytes(b'explicit test double')
            return subprocess.CompletedProcess(args, 0 if mode == 'success' else 137)
        return subprocess.CompletedProcess(args, 0, '{"OOMKilled":false}', '')
    monkeypatch.setattr(domino.subprocess, 'run', fake)
    r = domino.execute_reference(config, model, case, ['surface_pressure'], acknowledge_research=True)
    expected = {'success': 'REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED', 'failure': 'WORKER_FAILED', 'timeout': 'WORKER_TIMEOUT'}
    assert r['status'] == expected[mode] and r['executed'] and not r['qualification_override']
    assert (Path(r['artifact_directory']) / 'COMPLETION.json').is_file()
    if mode == 'timeout':
        assert any(c[1] == 'stop' for c in calls)


def test_service_requires_explicit_worker(tmp_path):
    service = PhysicsAI(tmp_path)
    r = service.predict(domino.MODEL_ID, {}, ['surface_pressure'])
    assert not r['executed'] and r['status'] == 'CHECKPOINT_MISSING'


def test_bundle_pin_rejection(tmp_path):
    config, model, case = setup(tmp_path)
    bundle = Path(config['bundle']); bundle.mkdir()
    (bundle / 'DOWNLOAD_PLAN.json').write_text('{"files":[]}')
    config['download_plan_sha256'] = '0' * 64
    result = domino.inspect_bundle(config, model)
    assert result['status'] == 'REFERENCE_BUNDLE_UNAVAILABLE'
    assert 'identity mismatch' in result['reason']


def test_incomplete_reference_cannot_become_witness(tmp_path):
    from Aero.physics_ai.reference_evidence import retain_reference
    with pytest.raises(ValueError, match='Completed reference'):
        retain_reference({'status': 'WORKER_FAILED'}, {}, {}, tmp_path)


def test_future_dataset_preserves_failure_and_does_not_authorize_training():
    import jsonschema
    schema = json.loads(Path(domino.__file__).with_name('dataset.schema.json').read_text())
    item = {'schema': 'aero.qualified_physics_dataset_record.v1', 'case_id': 'failed-fixture',
            'contract_sha256': 'a' * 64, 'artifacts': [{'role': 'rejected_run', 'path': 'retained.json', 'sha256': 'b' * 64}],
            'numerical_status': 'FAIL', 'engineering_disposition': 'INCONCLUSIVE',
            'failure_modes': ['missing_field'], 'training_authorized': False}
    jsonschema.validate(item, schema)
    item['training_authorized'] = True
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(item, schema)
