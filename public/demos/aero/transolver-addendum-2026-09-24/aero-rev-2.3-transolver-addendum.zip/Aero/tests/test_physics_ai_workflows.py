"""Synthetic protocol tests only; no claimed neural accuracy or actual CFD savings."""
import copy
import hashlib
import json
from pathlib import Path
import threading
import pytest
from Aero.engineering_validity.contracts import digest, validate_contract
from Aero.engineering_validity.controller import CampaignController
from Aero.physics_ai.benchmark import field_metrics, freeze_benchmark, evaluate_benchmark
from Aero.physics_ai.screening import rank_candidates
from Aero.physics_ai.comparison import compare_observables
from Aero.tests.test_physics_ai import fixture, result
from Aero.tests.test_engineering_validity import contract, diagnosis, proposal, StubAdapter


def field(values):
    return {'ids': ['cell1', 'cell2'], 'components': ['p'], 'units': 'Pa',
            'values': [[v] for v in values], 'weights': [1., 2.]}


def test_metrics_and_integrals():
    m = field_metrics(field([1., 2.]), field([2., 4.]))['components']['p']
    assert m['mean_absolute_error'] == 1.5
    assert m['rms_error'] == pytest.approx(2.5**.5)
    assert m['relative_l2_error'] == 1
    assert m['correlation'] == pytest.approx(1)
    assert m['reference_integral'] == 5 and m['prediction_integral'] == 10


@pytest.mark.parametrize('key,value', [('ids',['cell2','cell1']),('units','kPa'),('components',['T']),('weights',[2.,1.])])
def test_unqualified_mapping_rejected(key,value):
    other=field([1.,2.]);other[key]=value
    with pytest.raises(ValueError):field_metrics(field([1.,2.]),other)


def test_zero_reference_and_constant_correlation_not_fabricated():
    m=field_metrics(field([0.,0.]),field([0.,0.]))['components']['p']
    assert m['relative_l2_error'] is None and m['correlation'] is None


@pytest.mark.parametrize('values', [[float('nan'),1.],[float('inf'),2.],[True,2.]])
def test_nonfinite_or_boolean_rejected(values):
    with pytest.raises(ValueError):field_metrics(field([1.,2.]),field(values))


def benchmark(tmp_path):
    reference=tmp_path/'reference.json';reference.write_text(json.dumps(field([1.,2.])))
    spec={'benchmark_id':'synthetic-surface','dataset':'SYNTHETIC_TEST_NOT_PDEBENCH',
          'dataset_revision':'test1','reference_path':'reference.json',
          'reference_sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),
          'reference_origin':'synthetic','geometry_identity':'frozen-two-cells','weight_units':'m2','evaluation_design':'PROSPECTIVE',
          'limits':[{'component':'p','metric':'relative_l2_error','maximum':.01}],
          'balance_limits':{'mass':.01}}
    path=freeze_benchmark(tmp_path,spec)
    pred={'benchmark_contract_sha256':json.loads(path.read_text())['sha256'],
          'geometry_identity':spec['geometry_identity'],'model_identity':{'id':'synthetic','checkpoint_sha256':'a'*64},
          'field':field([1.,2.]),'balances':{'mass':{'signed_terms':[1.,-.5],'scale':1.}}}
    (tmp_path/'prediction.json').write_text(json.dumps(pred))
    return path,pred


def test_low_field_error_does_not_hide_bad_conservation(tmp_path):
    path,pred=benchmark(tmp_path)
    outcome=evaluate_benchmark(tmp_path,path.name,'prediction.json')
    assert outcome['checks'][0]['status']=='PASS' and outcome['balances']['mass']['status']=='FAIL'
    assert outcome['status']=='FAIL' and not outcome['qualification_override']


def test_missing_balance_unestablished_and_result_retained(tmp_path):
    path,pred=benchmark(tmp_path);pred['balances']={}
    (tmp_path/'prediction.json').write_text(json.dumps(pred))
    outcome=evaluate_benchmark(tmp_path,path.name,'prediction.json')
    assert outcome['status']=='NOT_ESTABLISHED'
    assert list(tmp_path.glob('benchmark-result-*.json'))


def test_changed_reference_rejected(tmp_path):
    path,pred=benchmark(tmp_path)
    (tmp_path/'reference.json').write_text(json.dumps(field([2.,3.])))
    with pytest.raises(ValueError,match='reference changed'):evaluate_benchmark(tmp_path,path.name,'prediction.json')


def test_wrong_benchmark_contract_rejected(tmp_path):
    path,pred=benchmark(tmp_path);pred['benchmark_contract_sha256']='b'*64
    (tmp_path/'prediction.json').write_text(json.dumps(pred))
    with pytest.raises(ValueError):evaluate_benchmark(tmp_path,path.name,'prediction.json')


def test_no_comparable_sources_not_agreement():
    assert compare_observables([],absolute_tolerance=0,relative_tolerance=0)['disposition']=='NOT_ESTABLISHED'


def witness(tmp_path,c,case_extra=None,test_double=False):
    registry,case=fixture(tmp_path);case.update(case_extra or {})
    # Protocol-only surrogate authority; these are synthetic bytes, not model validation.
    r,_=result(tmp_path,registry=registry,case=case,contract=c,test_double=test_double)
    return r,registry


def test_screening_retains_all_candidates_and_never_accepts(tmp_path):
    r,registry=witness(tmp_path,contract(),{'candidate_id':'candidate1'})
    report=rank_candidates([{'candidate_id':'candidate1','record':r}],registry=registry,
        contract=contract(),evidence_root=tmp_path,specification={'quantity':'delta_p','units':'Pa','direction':'minimize'})
    assert report['ranked_candidate_ids']==['candidate1']
    assert not report['automatic_rejection'] and report['required_conventional_qualification_unchanged']


def test_research_test_double_cannot_rank_engineering_candidates(tmp_path):
    r,registry=witness(tmp_path,contract(),{'candidate_id':'candidate1'},test_double=True)
    report=rank_candidates([{'candidate_id':'candidate1','record':r}],registry=registry,
        contract=contract(),evidence_root=tmp_path,specification={'quantity':'delta_p','units':'Pa','direction':'minimize'})
    assert report['ranked_candidate_ids']==[] and len(report['all_candidates'])==1


def campaign(tmp_path):
    c=contract();c['physics_ai_policy']={'allowed_models':['test-only'],'optional_experiments':[{
        'id':'optional-inlet-refinement','hypothesis_id':'H1','quantity':'delta_p','units':'Pa',
        'expected_lower':50.,'expected_upper':100.,'minimum_margin':10.,
        'mutation_path':'/model/mesh/refinement_passes','required':False}]}
    adapter=StubAdapter(tmp_path/'run');ctl=CampaignController(tmp_path/'control',{'openfoam':adapter})
    row=ctl.create(c);cid=row['campaign_id'];ctl.freeze(cid,row['contract_sha256'])
    ctl.tick(cid);ctl.tick(cid);ctl.diagnose(cid,diagnosis())
    return ctl,cid,adapter,c


def test_overnight_defers_only_frozen_optional_experiment(tmp_path):
    ctl,cid,adapter,c=campaign(tmp_path)
    evidence=tmp_path/'witness';evidence.mkdir()
    r,registry=witness(evidence,c,{'engineering_model_sha256':digest(c['model'])})
    ctl.attach_physics_ai(cid,r,evidence,registry)
    p=proposal();p['optional_experiment_id']='optional-inlet-refinement'
    ctl.propose(cid,p);before=copy.deepcopy(ctl.get(cid)['runs'][-1]['gate'])
    row=ctl.consider_physics_ai(cid,r['sha256'],'optional-inlet-refinement')
    assert row['physics_ai_experiment_reviews'][-1]['decision']=='DEFER_OPTIONAL_EXPERIMENT'
    assert row['diagnoses'][-1]['supporting_witness_reviews'][-1]['engineering_hypothesis_eliminated'] is False
    ctl.run_bounded(cid,threading.Event(),poll_seconds=1)
    assert len(adapter.starts)==1 and ctl.get(cid)['runs'][-1]['gate']==before
    # A required/unlabeled conventional proposal is not waived by surrogate evidence.
    ctl.propose(cid,proposal());ctl.tick(cid)
    assert len(adapter.starts)==2


def test_unknown_alignment_cannot_defer(tmp_path):
    ctl,cid,adapter,c=campaign(tmp_path);e=tmp_path/'w';e.mkdir()
    r,registry=witness(e,c)
    ctl.attach_physics_ai(cid,r,e,registry)
    row=ctl.consider_physics_ai(cid,r['sha256'],'optional-inlet-refinement')
    assert row['physics_ai_experiment_reviews'][-1]['decision']=='NO_SCHEDULING_CHANGE'


def test_required_gate_cannot_be_optional_experiment(tmp_path):
    ctl,cid,adapter,c=campaign(tmp_path)
    c['physics_ai_policy']['optional_experiments'][0]['id']='mass'
    with pytest.raises(ValueError,match='distinct'):validate_contract(c)


def test_optional_physical_mutation_rejected(tmp_path):
    ctl,cid,adapter,c=campaign(tmp_path)
    c['physics_ai_policy']['optional_experiments'][0]['mutation_path']='/model/boundaries/inlet/pressure'
    with pytest.raises(ValueError,match='numerical mutation'):validate_contract(c)


def test_undeclared_experiment_rejected(tmp_path):
    ctl,cid,adapter,c=campaign(tmp_path);p=proposal();p['optional_experiment_id']='not-predeclared'
    with pytest.raises(ValueError,match='frozen experiment'):ctl.propose(cid,p)


def test_research_witness_cannot_defer(tmp_path):
    ctl,cid,adapter,c=campaign(tmp_path);e=tmp_path/'w';e.mkdir()
    r,registry=witness(e,c,{'engineering_model_sha256':digest(c['model'])},test_double=True)
    ctl.attach_physics_ai(cid,r,e,registry)
    row=ctl.consider_physics_ai(cid,r['sha256'],'optional-inlet-refinement')
    assert row['physics_ai_experiment_reviews'][-1]['decision']=='NO_SCHEDULING_CHANGE'


def test_tampered_witness_summary_rejected_even_with_state_rehash(tmp_path):
    ctl,cid,adapter,c=campaign(tmp_path);e=tmp_path/'w';e.mkdir()
    r,registry=witness(e,c,{'engineering_model_sha256':digest(c['model'])},test_double=True)
    ctl.attach_physics_ai(cid,r,e,registry)
    row=ctl.get(cid)
    row['physics_ai_witnesses'][0]['summary']['eligible_for_supporting_interpretation']=True
    (ctl.path(cid)/'state.json').write_text(json.dumps({'payload':row,'sha256':digest(row)}))
    with pytest.raises(ValueError,match='summary integrity'):ctl.get(cid)


def test_retrospective_comparison_cannot_fit_acceptance_limits(tmp_path):
    path,pred=benchmark(tmp_path)
    spec=json.loads(path.read_text())['payload']['specification']
    spec['evaluation_design']='RETROSPECTIVE_DESCRIPTIVE'
    with pytest.raises(ValueError,match='Retrospective'):freeze_benchmark(tmp_path,spec)


def test_benchmark_cli_evaluates_retained_inputs(tmp_path,monkeypatch,capsys):
    from Aero.physics_ai.__main__ import main
    path,pred=benchmark(tmp_path)
    monkeypatch.setattr('sys.argv',['physics_ai','benchmark-evaluate','--evidence-root',str(tmp_path),
        '--contract-path',path.name,'--prediction-path','prediction.json'])
    main()
    output=json.loads(capsys.readouterr().out)
    assert output['status']=='FAIL' and output['qualification_override'] is False


def test_checkpoint_identity_required_for_benchmark(tmp_path):
    path,pred=benchmark(tmp_path);pred['model_identity']={'id':'untraceable'}
    (tmp_path/'prediction.json').write_text(json.dumps(pred))
    with pytest.raises(ValueError,match='checkpoint hash'):evaluate_benchmark(tmp_path,path.name,'prediction.json')
