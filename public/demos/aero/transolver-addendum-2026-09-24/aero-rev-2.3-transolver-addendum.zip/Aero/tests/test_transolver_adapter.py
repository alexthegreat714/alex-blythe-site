"""Boundary tests use explicit doubles; real inference has its own custody package."""
import copy
import json
from pathlib import Path
import subprocess
import pytest
from Aero.physics_ai import transolver
from Aero.physics_ai.registry import get_model,check_applicability,evidence_independence,file_hash
from Aero.physics_ai.service import PhysicsAI


def setup(tmp_path):
    root=tmp_path/'bundle';root.mkdir()
    c={'image':'python@sha256:'+'1'*64,'venv_volume':'aero-domino-runtime-20260924',
       'wall_seconds_limit':600,'memory_limit':'3g'}
    (root/'REFERENCE_EXECUTION_CONTRACT.json').write_text(json.dumps(c))
    return ({'bundle':str(root),'reference_bundle':str(tmp_path/'reference'),'contract_sha256':'0'*64},
            get_model(transolver.MODEL_ID),
            {'case_id':'drivaerml-run-1-reference','geometry_family':'automotive_external_drivaer'})


def ready(*args):return {'status':'REFERENCE_WORKER_READY','executed':False,'qualification_override':False,'conventional_workflow_available':True}


def test_missing_bundle_preserves_conventional_workflow(tmp_path):
    model=get_model(transolver.MODEL_ID)
    r=transolver.inspect_bundle({'bundle':str(tmp_path),'reference_bundle':str(tmp_path),'contract_sha256':'a'*64},model)
    assert r['status']=='REFERENCE_PREFLIGHT_BLOCKED' and r['conventional_workflow_available']


def test_checkpoint_missing_does_not_import_torch(tmp_path,monkeypatch):
    import builtins
    imp=builtins.__import__
    def guard(name,*a,**kw):
        if name.split('.')[0] in ('torch','physicsnemo'):raise AssertionError('Unexpected model import')
        return imp(name,*a,**kw)
    monkeypatch.setattr(builtins,'__import__',guard)
    r=PhysicsAI(tmp_path).predict(transolver.MODEL_ID,{},['surface_pressure'])
    assert r['status']=='CHECKPOINT_MISSING' and not r['executed']


def test_new_model_is_not_old_transolver_identity():
    new=get_model(transolver.MODEL_ID);old=get_model('transolver-plus-reference-pending')
    assert new['checkpoint']['sha256']!=old['checkpoint']['sha256']
    assert old['adapter_status']=='ADAPTER_STUB_ONLY'
    assert new['authority']=='RESEARCH_ONLY'


def test_heat_exchanger_ood_and_correlated_lineage():
    m=get_model(transolver.MODEL_ID)
    assert check_applicability(m,{'geometry_family':'internal_heat_exchanger'},['surface_pressure'])['status']=='OUT_OF_DISTRIBUTION'
    assert evidence_independence(m,'OpenFOAM')['level']=='LOW'
    assert check_applicability(m,{'geometry_family':'automotive_external_drivaer'},['surface_pressure'])['status']=='NOT_ESTABLISHED'


def test_hash_failure_prevents_dispatch(tmp_path,monkeypatch):
    cfg,m,case=setup(tmp_path)
    def forbidden(*a,**kw):raise AssertionError('Docker called after identity failure')
    monkeypatch.setattr(transolver.subprocess,'run',forbidden)
    r=transolver.execute_reference(cfg,m,case,['surface_pressure','wall_shear_stress'],acknowledge_research=True)
    assert r['status']=='REFERENCE_PREFLIGHT_BLOCKED' and not r['executed']


@pytest.mark.parametrize('change',['ack','case','output'])
def test_scope_blocks_before_docker(tmp_path,monkeypatch,change):
    cfg,m,case=setup(tmp_path);monkeypatch.setattr(transolver,'inspect_bundle',ready)
    outputs=['surface_pressure','wall_shear_stress']
    if change=='case':case['case_id']='HX-03'
    if change=='output':outputs=['temperature']
    r=transolver.execute_reference(cfg,m,case,outputs,acknowledge_research=change!='ack')
    assert not r['executed']
    assert r['status'] in ('RESEARCH_ACKNOWLEDGEMENT_REQUIRED','UNSUPPORTED_REFERENCE_CASE')


def test_docker_absent_is_structured(tmp_path,monkeypatch):
    cfg,m,case=setup(tmp_path);monkeypatch.setattr(transolver,'inspect_bundle',ready)
    def absent(*a,**kw):raise FileNotFoundError('Docker unavailable')
    monkeypatch.setattr(transolver.subprocess,'run',absent)
    r=transolver.execute_reference(cfg,m,case,['surface_pressure','wall_shear_stress'],acknowledge_research=True)
    assert r['status']=='DEPENDENCY_UNAVAILABLE' and not r['executed']


@pytest.mark.parametrize('mode',['success','failure','timeout','missing_output'])
def test_bounded_dispatch_retains_success_and_failure(tmp_path,monkeypatch,mode):
    cfg,m,case=setup(tmp_path);cpath=Path(cfg['bundle'])/'REFERENCE_EXECUTION_CONTRACT.json'
    c=json.loads(cpath.read_text());c['worker_sha256']='2'*64;cpath.write_text(json.dumps(c))
    monkeypatch.setattr(transolver,'inspect_bundle',ready)
    calls=[]
    def fake(args,**kw):
        calls.append(args)
        if args[1:3]==['image','inspect']:return subprocess.CompletedProcess(args,0,'[]','')
        if args[1]=='run':
            assert args[args.index('--network')+1]=='none' and '--read-only' in args
            assert args[args.index('--pull')+1]=='never'
            assert args[args.index('--memory')+1]==args[args.index('--memory-swap')+1]=='3g'
            assert kw['timeout']==630
            if mode=='timeout':raise subprocess.TimeoutExpired(args,630)
            if mode=='failure':return subprocess.CompletedProcess(args,137)
            if args[-1]=='infer' and mode!='missing_output':
                out=next((Path(cfg['bundle'])/'executions').iterdir())
                (out/'prediction.npz').write_bytes(b'EXPLICIT TEST DOUBLE NOT NEURAL INFERENCE')
                (out/'EXECUTION_RESULT.json').write_text(json.dumps({'state':'INFERENCE_COMPLETED','prediction_sha256':file_hash(out/'prediction.npz')}))
            return subprocess.CompletedProcess(args,0)
        return subprocess.CompletedProcess(args,0,'{"OOMKilled":false}','')
    monkeypatch.setattr(transolver.subprocess,'run',fake)
    r=transolver.execute_reference(cfg,m,case,['surface_pressure','wall_shear_stress'],acknowledge_research=True)
    assert r['executed'] and not r['qualification_override']
    expected={'success':'REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED','missing_output':'REFERENCE_OUTPUT_VERIFICATION_FAILED',
              'failure':'REFERENCE_EXECUTION_FAILED','timeout':'REFERENCE_EXECUTION_FAILED'}
    assert r['status']==expected[mode]
    assert (Path(r['artifact_directory'])/'COMPLETION.json').exists()
    if mode=='timeout':assert any(x[1]=='stop' and x[-1].startswith('transolver-') for x in calls)


def test_incomplete_execution_cannot_become_witness(tmp_path):
    from Aero.physics_ai.reference_evidence import retain_transolver_reference
    with pytest.raises(ValueError,match='Completed reference'):
        retain_transolver_reference({'status':'REFERENCE_EXECUTION_FAILED'},{},{},tmp_path)


def test_ingestion_checks_source_again(tmp_path,monkeypatch):
    from Aero.physics_ai.reference_evidence import retain_transolver_reference
    from Aero.physics_ai.registry import load_registry
    monkeypatch.setattr(transolver,'inspect_bundle',lambda *a:{'status':'REFERENCE_PREFLIGHT_BLOCKED'})
    with pytest.raises(ValueError,match='source integrity'):
        retain_transolver_reference({'status':'REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED'},{},load_registry(),tmp_path)
