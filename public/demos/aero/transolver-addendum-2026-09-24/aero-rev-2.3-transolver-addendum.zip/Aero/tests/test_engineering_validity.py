"""Controlled synthetic counterexamples; no solver execution or HX calibration."""
import copy
import hashlib
import json
import threading
from pathlib import Path
import pytest
from flask import Flask,jsonify,request
from Aero.engineering_validity.contracts import DOMAINS,ENGINEERING_FIELDS,validate_contract,build_baseline,digest,assess_changes,replace
from Aero.engineering_validity.gate import evaluate
from Aero.engineering_validity.controller import CampaignController
from Aero.engineering_validity.http import install

def contract():
    checks=[
      dict(id='residual',domain='numerical_status',kind='limit',limit=1e-3,units='1'),
      dict(id='mesh',domain='numerical_status',kind='limit',limit=.01,units='1'),
      dict(id='field',domain='numerical_status',kind='field_delta',limit=.01,scale=1,units='m/s'),
      dict(id='mass',domain='physics_status',kind='balance',limit=.01,term_names=['inlet','outlet'],units='kg/s'),
      dict(id='dp',domain='physics_status',kind='envelope',baseline_id='dp',units='Pa'),
      dict(id='regime',domain='model_form_status',kind='range',lower=0,upper=.3,units='1'),
      dict(id='uncertainty',domain='uncertainty_status',kind='limit',limit=.1,units='1')]
    for c in checks:c.update(required=True,requirement='synthetic-test-'+c['id'],source={'file':'data.json','pointer':'/'+c['id']})
    return {'schema':'aero.engineering_contract.v1','contract_id':'synthetic-duct','version':1,
      'engineering':{k:'Explicit synthetic test specification: '+k for k in ENGINEERING_FIELDS},
      'backend':'openfoam','model':{'numerics':{'timeout_sec':1,'delta_t':1.,'end_time':1},
        'mesh':{'refinement_passes':0},'boundaries':{'inlet':{'pressure':100.}},'automation':{'auto_adjust':False}},
      'checks':checks,'domains':{d:{'applicable':d!='experimental_correlation_status','rationale':'Synthetic fixture without experimental data' if d=='experimental_correlation_status' else 'Required synthetic counterexample evidence'} for d in DOMAINS},
      'acceptance_criteria':[c['id'] for c in checks],
      'mutation_policy':{'/model/mesh/refinement_passes':{'authority':'AGENT_ADJUSTABLE','reason':'Test one local resolution hypothesis','minimum':0,'maximum':4,'max_delta_from_frozen':2},
        '/model/numerics/delta_t':{'authority':'AGENT_ADJUSTABLE','reason':'Frozen controlled timestep diagnostic','minimum':.1,'maximum':2}},
      'baseline_requests':[{'id':'dp','tool':'channel_pressure_loss','inputs':{'width_m':.02,'height_m':.02,'length_m':1.,'density_kg_m3':1000.,'mass_flow_kg_s':.02,'dynamic_viscosity_pa_s':.001},'output':'pressure_drop_pa','units':'Pa','plausible_fraction':.2,'applicability':'Circular hydraulic diameter surrogate, screening not exact duct validation','confidence':'low'}],
      'budget':{'max_runs':3,'max_wall_seconds':1000}}

def raw():
    return {'residual':1e-6,'mesh':.005,'field':{'before_ids':[1,2],'after_ids':[1,2],'before':[[1.,0,0],[1.,0,0]],'after':[[1.,0,0],[1.,0,0]]},
      'mass':{'signed_terms':[1.,-1.],'term_names':['inlet','outlet'],'throughput_scale':1.},'dp':4.,'regime':.1,'uncertainty':.03}

def evidence(root,c,values=None):
    root.mkdir(parents=True,exist_ok=True); values=raw() if values is None else values
    path=root/'data.json';path.write_text(json.dumps(values));h=hashlib.sha256(path.read_bytes()).hexdigest()
    records={check['id']:{'value':values[check['id']],'units':check['units'],'run_id':'test-run','provenance':'OBSERVED',
        'sources':[{'path':'data.json','sha256':h,'pointer':'/'+check['id']}]} for check in c['checks'] if check['id'] in values}
    return {'run_id':'test-run','model_sha256':digest(c['model']),'records':records,'execution_completed':True,'manifest_verification':{'ok':True},'existing_required_blockers':[]}

def assess(tmp_path,values=None,c=None):
    c=c or contract();validate_contract(c);b=build_baseline(c);e=evidence(tmp_path,c,values)
    return evaluate(c,b,e,tmp_path,c['model'])

def test_case1_converged_but_mass_violation(tmp_path):
    v=raw();v['mass']['signed_terms']=[1.,-.6]
    result=assess(tmp_path,v)
    assert result['engineering_validity']['numerical_status']=='PASS'
    assert result['engineering_validity']['physics_status']=='FAIL'
    assert result['overall_disposition']=='FAIL'

def test_case2_conserved_outside_analytical_envelope(tmp_path):
    v=raw();v['dp']=16.
    result=assess(tmp_path,v)
    assert result['engineering_validity']['numerical_status']=='PASS'
    assert result['engineering_validity']['physics_status']=='PASS_WITH_ANOMALY'
    assert result['recommended_action']=='RUN_DISCRIMINATING_TEST'

def test_case3_plausible_missing_mesh(tmp_path):
    v=raw();del v['mesh'];r=assess(tmp_path,v)
    assert r['engineering_validity']['physics_status']=='PASS'
    assert r['engineering_validity']['numerical_status']=='NOT_ESTABLISHED'
    assert r['overall_disposition']=='INCONCLUSIVE'

def diagnosis():
    return {'observation':'Pressure drop is outside the frozen approximate envelope.', 'hypotheses':[
      {'id':'H1','parent_id':None,'statement':'Local inlet resolution affects the pressure loss','supporting_evidence':['dp'],'contradicting_evidence':['mass'],
       'missing_evidence':['refined inlet comparison'],'confidence':'medium','discriminating_test':'Change only local refinement; compare inlet loss'},
      {'id':'H2','parent_id':None,'statement':'The analytical approximation omits real entrance losses','supporting_evidence':['mass'],'contradicting_evidence':[],
       'missing_evidence':['independent entrance-loss reference'],'confidence':'low','discriminating_test':'Review independent entrance loss theory without tuning CFD'}]}

def proposal(path='/model/mesh/refinement_passes',value=1):
    return {'hypothesis_id':'H1','changes':[{'path':path,'value':value}],'justification':'Change only one local resolution dimension to discriminate H1 from H2',
       'expected_if_correct':'Inlet loss changes materially with resolution','expected_if_incorrect':'Inlet loss remains stable under refinement',
       'compare_quantities':['inlet pressure loss'],'collect_evidence':['endpoint pressure and mass flow'],'estimated_seconds':10,
       'information_value':.8,'information_rationale':'Directly discriminates localized discretization error'}

class StubAdapter:
    def __init__(self,root):self.root=root;self.starts=[]
    def start(self,model,**kw):self.starts.append(model);return {'run_id':'test-run','model_sha256':digest(model)}
    def status(self,ref):return {'terminal':True}
    def extract(self,ref,c,model):
        v=raw();v['dp']=16.;e=evidence(self.root,c,v);e['model_sha256']=digest(model);return e,self.root

def investigated(tmp_path):
    adapter=StubAdapter(tmp_path/'run');ctl=CampaignController(tmp_path/'control',{'openfoam':adapter})
    row=ctl.create(contract());cid=row['campaign_id'];ctl.freeze(cid,row['contract_sha256'])
    ctl.tick(cid);row=ctl.tick(cid);assert row['state']=='AWAITING_DIAGNOSIS'
    ctl.diagnose(cid,diagnosis());return ctl,cid,adapter

def test_case4_autonomous_boundary_change_blocked(tmp_path):
    ctl,cid,adapter=investigated(tmp_path)
    row=ctl.propose(cid,proposal('/model/boundaries/inlet/pressure',101.))
    authority=row['proposals'][-1]['authority']
    assert not authority['allowed'] and authority['classification']=='C'
    ctl.tick(cid);assert len(adapter.starts)==1
    assert any(e['kind']=='ASSUMPTION_DRIFT' for e in row['events'])

def test_case5_one_refinement_allowed_after_diagnosis(tmp_path):
    ctl,cid,adapter=investigated(tmp_path);row=ctl.propose(cid,proposal())
    assert row['state']=='READY_NEXT' and row['proposals'][-1]['authority']['classification']=='A'
    ctl.tick(cid);assert len(adapter.starts)==2 and adapter.starts[-1]['mesh']['refinement_passes']==1

def test_case6_cumulative_minor_changes_detected():
    c=contract();current={'model':copy.deepcopy(c['model'])};current['model']['mesh']['refinement_passes']=2
    proposed=copy.deepcopy(current);proposed['model']['mesh']['refinement_passes']=3
    result=assess_changes(c,current,proposed)
    assert not result['allowed'] and any('CUMULATIVE_DRIFT' in r for r in result['reasons'])

def test_case7_surviving_surprise_not_forced_to_analytical_target(tmp_path):
    v=raw();v['dp']=16.;result=assess(tmp_path,v)
    assert result['overall_disposition']=='PASS_WITH_ANOMALY'
    assert 'real physics remains possible' in next(r['reason'] for r in result['checks'] if r['id']=='dp')
    c=contract();baseline=build_baseline(c);assert baseline['predictions']['dp']['nominal']==pytest.approx(4.)
    # Independent corroboration/refinement can add evidence, never edit the frozen envelope.
    v['mesh']=.00001;second=assess(tmp_path,v)
    assert second['overall_disposition']=='PASS_WITH_ANOMALY'
    assert build_baseline(c)==baseline

def test_case8_missing_endpoint_fields_not_inferred(tmp_path):
    v=raw();del v['field'];result=assess(tmp_path,v)
    assert next(r for r in result['checks'] if r['id']=='field')['status']=='NOT_ESTABLISHED'
    assert result['overall_disposition']=='INCONCLUSIVE'

def test_evidence_value_must_match_source(tmp_path):
    c=contract();e=evidence(tmp_path,c);e['records']['dp']['value']=1.
    r=evaluate(c,build_baseline(c),e,tmp_path,c['model'])
    assert next(x for x in r['checks'] if x['id']=='dp')['status']=='NOT_ESTABLISHED'

def test_inferred_evidence_cannot_become_observed(tmp_path):
    c=contract();e=evidence(tmp_path,c);e['records']['mass']['provenance']='INFERRED'
    assert evaluate(c,build_baseline(c),e,tmp_path,c['model'])['overall_disposition']=='INCONCLUSIVE'

def test_required_existing_gate_never_waived(tmp_path):
    c=contract();e=evidence(tmp_path,c);e['existing_required_blockers']=[{'name':'old_gate','passed':False}]
    assert evaluate(c,build_baseline(c),e,tmp_path,c['model'])['overall_disposition']=='FAIL'

def test_contract_and_state_tampering_blocked(tmp_path):
    ctl=CampaignController(tmp_path);row=ctl.create(contract());cid=row['campaign_id'];ctl.freeze(cid,row['contract_sha256'])
    p=ctl.path(cid)/'contract.json';p.write_text('{}')
    with pytest.raises(ValueError,match='Frozen artifact changed'):ctl.get(cid)

def test_no_mutation_without_diagnosis(tmp_path):
    ctl=CampaignController(tmp_path);row=ctl.create(contract())
    with pytest.raises(ValueError):ctl.propose(row['campaign_id'],proposal())

def test_no_self_declared_physical_autonomy():
    c=contract();c['mutation_policy']['/model/boundaries/inlet/pressure']={'authority':'AGENT_ADJUSTABLE','reason':'Pretend numerical change'}
    with pytest.raises(ValueError):validate_contract(c)

def test_dispatch_crash_is_not_retried(tmp_path):
    class Broken(StubAdapter):
        def start(self,*a,**kw):self.starts.append(1);raise RuntimeError('Crash after worker launch')
    adapter=Broken(tmp_path/'run');ctl=CampaignController(tmp_path/'control',{'openfoam':adapter})
    row=ctl.create(contract());cid=row['campaign_id'];ctl.freeze(cid,row['contract_sha256'])
    with pytest.raises(RuntimeError):ctl.tick(cid)
    assert ctl.tick(cid)['state']=='DISPATCHING' and len(adapter.starts)==1

def test_persistent_restart_and_bounded_loop_stop(tmp_path):
    ctl,cid,adapter=investigated(tmp_path)
    restored=CampaignController(tmp_path/'control',{'openfoam':adapter})
    assert restored.get(cid)['diagnoses'][0]['hypotheses'][0]['id']=='H1'
    assert restored.run_bounded(cid,threading.Event())['state']=='AWAITING_PROPOSAL'
    assert len(adapter.starts)==1

def test_human_api_separate_from_agent_token(tmp_path,monkeypatch):
    monkeypatch.setenv('AERO_GUIDANCE_APPROVAL_TOKEN','h'*32)
    app=Flask(__name__);ctl=CampaignController(tmp_path)
    def auth():return (None,200) if request.headers.get('X-Aero-Token')=='agent' else (jsonify(error='unauthorized'),401)
    install(app,'lab',auth,lambda:ctl);client=app.test_client()
    assert client.get('/engineering-validity/status').status_code==401
    h={'X-Aero-Token':'agent'}
    row=client.post('/engineering-validity/campaigns',json={'contract':contract()},headers=h).json
    endpoint='/engineering-validity/campaigns/'+row['campaign_id']+'/freeze';body={'fingerprint':row['contract_sha256']}
    assert client.post(endpoint,json=body,headers=h).status_code==403
    assert client.post(endpoint,json=body,headers=dict(h,**{'X-Aero-Guidance-Approval':'h'*32})).status_code==200

@pytest.mark.parametrize('profile',['blue','public'])
def test_control_routes_private_only(profile):
    app=Flask(__name__);install(app,profile,lambda:(None,200),lambda:None)
    assert app.test_client().get('/engineering-validity/status').status_code==404

def test_managed_pipeline_direct_start_blocked_before_preflight(tmp_path,monkeypatch):
    from Aero.openfoam_pipeline import OpenFOAMPipeline
    pipeline=OpenFOAMPipeline(tmp_path)
    monkeypatch.setattr(pipeline,'get_spec',lambda _: {'spec':{'engineering_control':{'campaign_id':'x'}}})
    monkeypatch.setattr(pipeline,'preflight',lambda *a,**kw:pytest.fail('No preflight side effect allowed'))
    assert pipeline.start_run('x')['error']=='engineering_campaign_admission_required'

def test_nonfinite_and_wrong_unit_evidence(tmp_path):
    c=contract();e=evidence(tmp_path,c);e['records']['mass']['units']='W'
    r=evaluate(c,build_baseline(c),e,tmp_path,c['model'])
    assert r['engineering_validity']['physics_status']=='NOT_ESTABLISHED'

def test_missing_manifest_no_acceptance(tmp_path):
    c=contract();e=evidence(tmp_path,c);e['manifest_verification']={'ok':False}
    assert evaluate(c,build_baseline(c),e,tmp_path,c['model'])['overall_disposition']=='INCONCLUSIVE'

def test_forged_human_receipt_is_not_evidence(tmp_path):
    c=contract();check=c['checks'][-1];check.update(kind='review')
    v=raw();v['uncertainty']={'_verified_human_review':True,'status':'PASS','rationale':'solver grades itself'}
    assert assess(tmp_path,v,c)['engineering_validity']['uncertainty_status']=='NOT_ESTABLISHED'

def test_forged_mesh_eligibility_cannot_pass(tmp_path):
    c=contract();c['checks'][1]['kind']='mesh';v=raw()
    v['mesh']={'levels':[{'cells':i,'value':1.,'_verified_equivalent_per_grid':True} for i in (100,200,400)]}
    assert assess(tmp_path,v,c)['engineering_validity']['numerical_status']=='NOT_ESTABLISHED'

def test_signed_energy_storage_is_mandatory(tmp_path):
    c=contract();c['checks'][3].update(units='W',term_names=['hot','cold','solid_storage'])
    v=raw();v['mass']={'term_names':['hot','cold','solid_storage'],'signed_terms':[-100.,90.,10.],'throughput_scale':100.}
    assert assess(tmp_path,v,c)['engineering_validity']['physics_status']=='PASS'
    v['mass']['signed_terms'][-1]=0.
    assert assess(tmp_path,v,c)['engineering_validity']['physics_status']=='FAIL'
    v['mass']['term_names'].pop();v['mass']['signed_terms'].pop()
    assert assess(tmp_path,v,c)['engineering_validity']['physics_status']=='NOT_ESTABLISHED'

def test_stationarity_uses_frozen_full_window(tmp_path):
    c=contract();c['checks'][2].update(kind='history',samples=4,limit=.01,scale=1.)
    v=raw();v['field']={'times':[0,1,2,3],'values':[1,1,1,1.1]}
    assert assess(tmp_path,v,c)['engineering_validity']['numerical_status']=='FAIL'
    v['field']={'times':[2,3],'values':[1,1]}
    assert assess(tmp_path,v,c)['engineering_validity']['numerical_status']=='NOT_ESTABLISHED'

def test_multiobservable_test_correlation_and_alignment(tmp_path):
    c=contract();c['domains']['experimental_correlation_status']['applicable']=True
    c['checks'].append(dict(id='correlation',domain='experimental_correlation_status',kind='correlation',required=True,units='K',requirement='matched experiment',limit=2))
    v=raw();v['correlation']={'model_configuration_hash':'same','test_configuration_hash':'same','model_locations':[1,2],'sensor_locations':[1,2],
      'model_times':[1,2],'measurement_times':[1,2],'predicted':[300,310],'measured':[301,311],'combined_uncertainty':[1,1]}
    assert assess(tmp_path,v,c)['engineering_validity']['experimental_correlation_status']=='PASS'
    v['correlation']['test_configuration_hash']='different'
    assert assess(tmp_path,v,c)['engineering_validity']['experimental_correlation_status']=='NOT_ESTABLISHED'

def test_primary_domains_cannot_be_waived():
    c=contract();c['domains']['physics_status']['applicable']=False
    with pytest.raises(ValueError):validate_contract(c)

def test_alignment_failure_not_masked_by_missing_manifest(tmp_path):
    c=contract();e=evidence(tmp_path,c);e['model_sha256']='wrong';e['manifest_verification']={'ok':False}
    assert evaluate(c,build_baseline(c),e,tmp_path,c['model'])['engineering_validity']['evidence_status']=='FAIL'

def test_budget_stops_before_dispatch(tmp_path):
    c=contract();c['budget']['max_wall_seconds']=.01
    ctl=CampaignController(tmp_path,{'openfoam':StubAdapter(tmp_path/'data')});r=ctl.create(c);ctl.freeze(r['campaign_id'],r['contract_sha256'])
    assert ctl.tick(r['campaign_id'])['state']=='BUDGET_STOP'

def test_schema_error_api_is_422(tmp_path):
    app=Flask(__name__);install(app,'lab',lambda:(None,200),lambda:CampaignController(tmp_path))
    assert app.test_client().post('/engineering-validity/campaigns',json={'contract':{}}).status_code==422

def test_source_escape_and_changed_bytes_fail_closed(tmp_path):
    c=contract();e=evidence(tmp_path/'root',c);e['records']['dp']['sources'][0]['path']='../elsewhere.json'
    assert evaluate(c,build_baseline(c),e,tmp_path/'root',c['model'])['overall_disposition']=='INCONCLUSIVE'
    e=evidence(tmp_path/'root',c);(tmp_path/'root/data.json').write_text('{}')
    assert evaluate(c,build_baseline(c),e,tmp_path/'root',c['model'])['overall_disposition']=='INCONCLUSIVE'

def test_openfoam_adapter_uses_existing_admission_and_verified_sources(tmp_path):
    from Aero.engineering_validity.adapters import OpenFOAMAdapter,ENGINEERING_DISPATCH_PERMIT
    c=contract();evidence(tmp_path,c)
    (tmp_path/'evidence_manifest.json').write_text(json.dumps({'files':[{'relative_path':'data.json'}]}))
    class Pipeline:
        def create_spec(self,s):return {'ok':True,'spec':dict(s,spec_id='synthetic')}
        def start_run(self,spec_id,**kwargs):
            assert kwargs['_engineering_permit'] is ENGINEERING_DISPATCH_PERMIT
            return {'ok':True,'run_id':'test-run'}
        def _run_dir(self,r):return tmp_path
        def verify_evidence_manifest(self,r):return {'ok':True,'file_count':1}
        def get_run(self,r):return {'status':'completed','gate_evaluation':{'gates':[{'name':'legacy','required':True,'passed':False}]}}
    a=OpenFOAMAdapter(Pipeline());ref=a.start(c['model'],campaign_id='x',contract_sha256=digest(c));assert a.status(ref)['terminal']
    e,root=a.extract(ref,c,c['model']);assert e['records']['mass']['value']==raw()['mass']
    assert evaluate(c,build_baseline(c),e,root,c['model'])['overall_disposition']=='FAIL'

def test_openfoam_defaults_cannot_silently_change_frozen_model():
    from Aero.engineering_validity.adapters import OpenFOAMAdapter
    class Pipeline:
        def create_spec(self,s):return {'ok':True,'spec':dict(s,physics={'unexpected':'new assumption'})}
        def start_run(self,*a,**kw):pytest.fail('Must not execute changed model')
    with pytest.raises(RuntimeError,match='defaults'):OpenFOAMAdapter(Pipeline()).start(contract()['model'],campaign_id='x',contract_sha256='x')

def test_calculix_preserves_exact_existing_human_approval(tmp_path):
    from Aero.engineering_validity.adapters import CalculixAdapter
    class Backend:
        starts=0
        def build(self,m):return {'case_id':'c','case':{'fingerprint':'f'}}
        def status(self,c):return {'state':'PROPOSED' if not self.starts else 'RUNNING'}
        def path(self,c):return tmp_path
        def preflight(self,c):return {'status':'PASS'}
        def run(self,c,approval):assert approval=='f';self.starts+=1
    b=Backend();a=CalculixAdapter(b);ref=a.start({},campaign_id='x',contract_sha256='x')
    assert a.status(ref)['needs_human'] and b.starts==0
    (tmp_path/'approval.json').write_text(json.dumps({'fingerprint':'wrong','authority':'human_ui'}));assert a.status(ref)['needs_human']
    (tmp_path/'approval.json').write_text(json.dumps({'fingerprint':'f','authority':'human_ui'}));assert not a.status(ref)['terminal'] and b.starts==1

def test_unknown_mesh_geometry_is_class_c():
    from Aero.engineering_validity.contracts import mutation_class
    assert mutation_class('/model/mesh/hardware_diameter')=='C'

def test_native_source_mutation_blocks_launch(tmp_path):
    source=tmp_path/'source';source.mkdir();(source/'boundary').write_text('original physical boundary')
    c=contract();c['model']['case_source']=str(source)
    a=StubAdapter(tmp_path/'run');ctl=CampaignController(tmp_path/'control',{'openfoam':a})
    row=ctl.create(c);ctl.freeze(row['campaign_id'],row['contract_sha256'])
    (source/'boundary').write_text('silently changed physical boundary')
    assert ctl.tick(row['campaign_id'])['state']=='SOURCE_DRIFT_BLOCKED' and not a.starts

def test_formal_physical_revision_retains_reason_and_exact_difference(tmp_path):
    ctl=CampaignController(tmp_path);original=ctl.create(contract());ctl.freeze(original['campaign_id'],original['contract_sha256'])
    revised=contract();revised.update(version=2,parent_sha256=original['contract_sha256'],revision_reason='New reviewed physical inlet load, not a numerical tuning change')
    revised['model']['boundaries']['inlet']['pressure']=120.
    draft=ctl.create(revised);frozen=ctl.freeze(draft['campaign_id'],draft['contract_sha256'])
    assert any(x['path']=='/model/boundaries/inlet/pressure' and x['before']==100 and x['after']==120 for x in frozen['revision_review']['changes'])
    assert ctl.get(original['campaign_id'])['contract']['model']['boundaries']['inlet']['pressure']==100
