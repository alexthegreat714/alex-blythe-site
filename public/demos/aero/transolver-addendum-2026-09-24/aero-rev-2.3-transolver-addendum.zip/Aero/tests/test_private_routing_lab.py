import json
import sqlite3
from pathlib import Path
import pytest
from flask import Flask, jsonify, request
from Aero.private.routing_lab.service import RoutingLab, OPTIONS, ROOT, install

def valid(_):
    return {'choice':'clarify','distribution':{key:float(key=='clarify') for key in OPTIONS},'level':'L0','seconds':0.1}

def payload():
    return {'request':'What thickness?','confirm_generic_only':True}

def test_audit_contains_choices_and_actual_selection_rule(tmp_path):
    lab=RoutingLab(tmp_path,valid)
    row=lab.decide(payload())
    assert row['selected_choice']=='clarify'
    assert row['available_choices']==list(OPTIONS)
    assert row['calibrated'] is False
    assert row['execution_authorized'] is False
    assert 'highest AnyJev L0 score' in row['selection_explanation']
    assert row['explanation_type'].endswith('not hidden model reasoning')
    second=lab.decide(payload())
    assert second['previous_sha256']==row['sha256']
    assert lab.history()['checked']==2

@pytest.mark.parametrize('bad',[{}, {'request':'x','confirm_generic_only':False},
    {'request':'x'*1001,'confirm_generic_only':True},dict(payload(),command='run'),
    {'request':{},'confirm_generic_only':True}])
def test_reject_bad_input(tmp_path,bad):
    with pytest.raises(ValueError): RoutingLab(tmp_path,valid).decide(bad)

@pytest.mark.parametrize('kind',['error','invalid_choice','nan','uncalibrated_level'])
def test_provider_failures_are_logged_without_substitution(tmp_path,kind):
    def broken(_):
        if kind=='error': raise TimeoutError()
        result=valid('')
        if kind=='invalid_choice':result['choice']='launch_solver'
        if kind=='nan':result['distribution']['clarify']=float('nan')
        if kind=='uncalibrated_level':result['level']='L1'
        return result
    result=RoutingLab(tmp_path,broken).decide(payload())
    assert result['status']=='NOT_ESTABLISHED' and result['selected_choice'] is None
    assert result['execution_authorized'] is False

def test_tamper_blocks_next_decision(tmp_path):
    lab=RoutingLab(tmp_path,valid);lab.decide(payload())
    with sqlite3.connect(tmp_path/'decisions.sqlite3') as db:
        db.execute("UPDATE decisions SET sha256='bad'")
    with pytest.raises(RuntimeError,match='audit_integrity_failed'):lab.decide(payload())

def app_for(profile):
    app=Flask(__name__)
    def auth():
        if request.headers.get('X-Aero-Token')!='test-token':return jsonify(error='unauthorized'),401
        return None,200
    install(app,profile,auth)
    return app

@pytest.mark.parametrize('profile',['blue','public'])
def test_no_routes_on_portable_or_public(profile):
    client=app_for(profile).test_client()
    assert client.get('/routing-lab/results').status_code==404
    assert client.post('/routing-lab/decisions',json=payload()).status_code==404

def test_auth_and_origin():
    client=app_for('lab').test_client()
    assert client.get('/routing-lab/results').status_code==401
    assert client.post('/routing-lab/decisions',json=payload(),headers={'X-Auth-User':'alexblythe'}).status_code==401
    assert client.post('/routing-lab/decisions',json=payload(),headers={'X-Aero-Token':'test-token','Origin':'https://evil.example'}).status_code==403
    assert client.get('/routing-lab/results',headers={'X-Aero-Token':'test-token'}).status_code==200

def test_existing_profiles_unchanged_except_private_revision():
    catalog=json.loads((ROOT/'config/deployment_profiles.json').read_text())
    baseline=json.loads((ROOT/'revisions/private_2_0_before_anyjev_20260923/config/deployment_profiles.json').read_text())
    assert catalog['profiles']['lab']['revision']=='2.2-local'
    catalog['profiles']['lab']['revision']='2.0-local'
    assert catalog==baseline

def test_page_renders_revision_and_no_auto_execution():
    from jinja2 import Environment,FileSystemLoader
    env=Environment(loader=FileSystemLoader(str(ROOT/'templates')))
    html=env.get_template('routing_lab.html').render()
    assert 'Rev 2.1-local' in html and 'No solver launch' in html
    assert 'textContent' in html and 'innerHTML' not in html
