"""Immutable supporting-witness records. Neural answers cannot become observations."""
import copy
from datetime import datetime,timezone
import json
import math
from pathlib import Path
import re
from Aero.engineering_validity.contracts import digest
from .registry import check_applicability,evidence_independence,file_hash,get_model

def artifact(root,relative_path):
    root=Path(root).resolve();path=(root/relative_path).resolve()
    if Path(relative_path).is_absolute() or not path.is_relative_to(root) or not path.is_file():
        raise ValueError('Artifact must be retained inside its evidence root')
    return {'path':relative_path,'sha256':file_hash(path),'bytes':path.stat().st_size}

def conservation_check(signed_terms,scale,limit):
    values=[*signed_terms,scale,limit]
    if not signed_terms or not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in values) or scale<=0 or limit<0:
        raise ValueError('Finite signed terms and predeclared positive scale required')
    error=abs(sum(signed_terms))/scale
    return {'status':'PASS' if error<=limit else 'FAIL','normalized_error':error,'limit':limit,
            'signed_terms':list(signed_terms),'scale':scale,'kind':'deterministic_balance'}

def build_result(*,registry,model_id,contract,case,requested_outputs,outputs,root,
                 input_paths,field_paths,checkpoint_path,configuration,runtime,
                 code_versions,conservation=None,test_double=False):
    model=get_model(model_id,registry)
    required={'preprocessing','postprocessing','inference'}
    if set(code_versions)!=required or not all(re.fullmatch('[a-f0-9]{64}',v) for v in code_versions.values()):
        raise ValueError('Exact code hashes required for each processing stage')
    if not input_paths:raise ValueError('At least one retained input required')
    if not {'seed','precision','deterministic'}.issubset(configuration):raise ValueError('Explicit inference settings required')
    if not {'hardware','software_versions','wall_seconds'}.issubset(runtime):raise ValueError('Runtime provenance required')
    scalar=outputs.get('scalar_observables',{})
    if set(outputs)!={'scalar_observables'}:raise ValueError('Fields must use retained field artifacts')
    for key,item in scalar.items():
        if key not in requested_outputs or set(item)!={'value','units'} or not isinstance(item['units'],str) or not item['units']:
            raise ValueError('Requested scalar with explicit units required')
        if isinstance(item['value'],bool) or not isinstance(item['value'],(float,int)) or not math.isfinite(item['value']):
            raise ValueError('Finite scalar value required')
    cp=artifact(root,checkpoint_path)
    if cp['sha256']!=model['checkpoint']['sha256']:raise ValueError('Checkpoint does not match registry')
    inputs=[artifact(root,p) for p in input_paths]
    fields=[dict(artifact(root,p),spatial_correspondence='NOT_ESTABLISHED') for p in field_paths]
    if not scalar and not fields:raise ValueError('Prediction output required')
    applicability=check_applicability(model,case,requested_outputs)
    checks=[]
    for specification in conservation or []:
        checks.append(conservation_check(**specification))
    body={'schema':'aero.physics_ai_result.v1','source_type':'PHYSICS_AI_RESULT',
        'model_id':model_id,'model_version':model['model_version'],'model_entry_sha256':digest(model),
        'registry_version':registry['version'],'registry_sha256':digest(registry),
        'engineering_contract_id':contract['contract_id'],'engineering_contract_version':contract['version'],
        'engineering_contract_sha256':digest(contract),'case':copy.deepcopy(case),
        'requested_outputs':list(requested_outputs),'applicability':applicability,
        'inputs':inputs,'checkpoint':cp,'outputs':dict(copy.deepcopy(outputs),field_artifacts=fields),
        'configuration':copy.deepcopy(configuration),'runtime':copy.deepcopy(runtime),
        'code_versions':dict(code_versions),'created_at':datetime.now(timezone.utc).isoformat(),
        'source_repository':model['source_repository'],'source_commit':model['source_commit'],
        'benchmark_status':model.get('benchmark_status','NOT_ESTABLISHED'),
        'uncertainty':{'status':'NOT_ESTABLISHED','method':None},
        'evidence_independence':evidence_independence(model,case.get('conventional_solver')),
        'authority':'RESEARCH_ONLY' if test_double else applicability['authority'],
        'validity':'FAIL' if any(c['status']=='FAIL' for c in checks) else 'NOT_ESTABLISHED',
        'deterministic_checks':checks,'test_double':bool(test_double),
        'can_satisfy_qualification_gate':False}
    # An identity for rerun comparison separate from timestamps/runtime durations.
    body['reproduction_key']=digest({k:body[k] for k in ('registry_sha256','engineering_contract_sha256',
        'case','requested_outputs','inputs','checkpoint','configuration','code_versions')})
    return {'payload':body,'sha256':digest(body)}

def retain_result(root,record):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    if digest(record['payload'])!=record['sha256']:raise ValueError('Result integrity failed')
    target=root/('physics-ai-'+record['sha256']+'.json')
    # Exclusive creation: never overwrite or erase a failed/anomalous result.
    with target.open('x',encoding='utf8',newline='\n') as stream:
        json.dump(record,stream,indent=2,allow_nan=False)
    return target

def verify_result(record,root,registry,contract):
    b=record['payload']
    if digest(b)!=record['sha256'] or b['engineering_contract_sha256']!=digest(contract) or b['registry_sha256']!=digest(registry):
        raise ValueError('Result/contract/registry integrity failed')
    model=get_model(b['model_id'],registry)
    expected=check_applicability(model,b['case'],b['requested_outputs'])
    if b['applicability']!=expected or b['model_entry_sha256']!=digest(model):raise ValueError('Applicability identity changed')
    if b['source_type']!='PHYSICS_AI_RESULT' or b['can_satisfy_qualification_gate'] is not False:raise ValueError('Invalid witness authority')
    for item in b['inputs']+[b['checkpoint']]+b['outputs']['field_artifacts']:
        fresh=artifact(root,item['path'])
        if any(fresh[k]!=item[k] for k in ('sha256','bytes')):raise ValueError('Retained artifact changed')
    if b['checkpoint']['sha256']!=model['checkpoint']['sha256']:raise ValueError('Checkpoint registry mismatch')
    expected_authority='RESEARCH_ONLY' if b['test_double'] else expected['authority']
    if b['authority']!=expected_authority:raise ValueError('Witness authority escalation')
    for check in b['deterministic_checks']:
        actual=conservation_check(check['signed_terms'],check['scale'],check['limit'])
        if actual!=check:raise ValueError('Deterministic check was not reproduced')
    expected_validity='FAIL' if any(c['status']=='FAIL' for c in b['deterministic_checks']) else 'NOT_ESTABLISHED'
    if b['validity']!=expected_validity:raise ValueError('Unsupported validity promotion')
    # No result, even in-distribution, can independently pass a required gate.
    return {'result_sha256':record['sha256'],'source_type':'PHYSICS_AI_RESULT',
        'applicability':expected['status'],'authority':expected_authority,
        'validity':b['validity'],'can_satisfy_qualification_gate':False,
        'eligible_for_supporting_interpretation':not b['test_double'] and expected['status']=='IN_DISTRIBUTION' and b['validity']!='FAIL',
        'independence':evidence_independence(model,b['case'].get('conventional_solver'))}
