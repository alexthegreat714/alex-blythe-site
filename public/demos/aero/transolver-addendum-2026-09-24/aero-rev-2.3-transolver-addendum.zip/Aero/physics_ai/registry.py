"""Fail-closed catalog/applicability and read-only checkpoint capability checks."""
import copy
import hashlib
import json
import math
from pathlib import Path
import re
from Aero.engineering_validity.contracts import digest

CATALOG = Path(__file__).with_name('catalog.json')
AXES = ('geometry_family', 'mesh_type', 'dimensionality', 'regime',
        'boundary_condition_family', 'material_system', 'reynolds_number',
        'mach_number', 'temperature_K', 'pressure_Pa', 'spatial_resolution')
UNKNOWN = (None, 'UNKNOWN', 'NOT_ESTABLISHED')

def load_registry(path=CATALOG):
    data=json.loads(Path(path).read_text(encoding='utf8'))
    if data.get('schema')!='aero.physics_model_registry.v1':
        raise ValueError('Unsupported model registry')
    seen=set()
    for model in data['models']:
        if model['model_id'] in seen:raise ValueError('Duplicate model ID')
        seen.add(model['model_id'])
        for key in ('model_version','adapter','checkpoint','source_repository','source_commit',
                    'training_envelope','supported_outputs','authority','validation_status','runtime'):
            if key not in model:raise ValueError('Missing registry field: '+key)
        if model['authority'] not in ('RESEARCH_ONLY','SURROGATE_ONLY','WARM_START_ONLY','VALIDATED_SURROGATE'):
            raise ValueError('Invalid model authority')
    return data

def get_model(model_id,registry=None):
    registry=registry or load_registry()
    for model in registry['models']:
        if model['model_id']==model_id:return copy.deepcopy(model)
    raise KeyError(model_id)

def check_applicability(model,case,requested_outputs):
    """Same rules for every model/case. Unknown metadata is never filled by inference."""
    rows=[]
    envelope=model['training_envelope']
    for axis in AXES:
        rule=envelope.get(axis);value=case.get(axis)
        state='UNKNOWN'
        if rule not in UNKNOWN and value not in UNKNOWN:
            if isinstance(rule,list):state='MATCH' if value in rule else 'MISMATCH'
            elif isinstance(rule,dict) and set(rule)=={'minimum','maximum','units'}:
                if isinstance(value,dict) and set(value)=={'value','units'} and value['units']==rule['units']:
                    x=value['value'];lo=rule['minimum'];hi=rule['maximum']
                    if all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (x,lo,hi)) and lo<=hi:
                        state='MATCH' if lo<=x<=hi else 'MISMATCH'
        rows.append({'axis':axis,'state':state,'case_value':value,'documented_envelope':rule})
    outputs=model.get('supported_outputs',[])
    rows.append({'axis':'requested_outputs','state':
        'UNKNOWN' if not outputs or not requested_outputs else
        ('MATCH' if set(requested_outputs).issubset(outputs) else 'MISMATCH')})
    states={r['state'] for r in rows}
    status='OUT_OF_DISTRIBUTION' if 'MISMATCH' in states else ('NOT_ESTABLISHED' if 'UNKNOWN' in states else 'IN_DISTRIBUTION')
    return {'status':status,'checks':rows,'method':'metadata_envelope_not_statistical_OOD',
        'authority':model['authority'] if status=='IN_DISTRIBUTION' else 'RESEARCH_ONLY',
        'domain_validated':status=='IN_DISTRIBUTION' and model['validation_status']=='VALIDATED_FOR_DECLARED_DOMAIN',
        'case_sha256':digest(case),'model_entry_sha256':digest(model)}

def file_hash(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def capability(model,cache_root):
    """No download, import of Torch, deserialization, execution or GPU allocation."""
    expected=model['checkpoint'].get('sha256','UNKNOWN')
    result={'model_id':model['model_id'],'model_available':False,
        'adapter_status':model.get('adapter_status','NOT_IMPLEMENTED'),
        'hardware_compatibility':'NOT_ESTABLISHED','runtime_requirements':model['runtime'],
        'automatic_download':False,'domain_validation':model['validation_status']}
    if not re.fullmatch('[a-f0-9]{64}',expected):
        return dict(result,status='CHECKPOINT_IDENTITY_NOT_ESTABLISHED')
    root=Path(cache_root).resolve();path=(root/expected).resolve()
    if not path.is_relative_to(root):return dict(result,status='CHECKPOINT_PATH_REJECTED')
    if not path.is_file():return dict(result,status='CHECKPOINT_MISSING')
    if file_hash(path)!=expected:return dict(result,status='CHECKPOINT_HASH_MISMATCH')
    status='REFERENCE_WORKER_NOT_CONFIGURED' if model.get('adapter') in ('physicsnemo_domino','physicsnemo_transolver') else 'ADAPTER_STUB_ONLY'
    return dict(result,model_available=True,status=status,checkpoint_bytes=path.stat().st_size)

def evidence_independence(model,conventional_solver=None):
    source=model.get('training_data_source','UNKNOWN');solver=model.get('training_solver','UNKNOWN')
    if source in UNKNOWN:return {'level':'UNKNOWN','reason':'Training data origin not established'}
    if conventional_solver and solver not in UNKNOWN and solver.lower()==conventional_solver.lower():
        return {'level':'LOW','reason':'Training labels and comparison share the same solver family'}
    return {'level':'PARTIAL','reason':'Shared modeling assumptions or measurement lineage not independently excluded',
            'training_data_source':source,'training_solver':solver}
