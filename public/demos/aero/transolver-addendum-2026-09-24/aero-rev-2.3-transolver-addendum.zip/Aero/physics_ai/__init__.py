"""Optional supporting physics witnesses. No ML dependency is imported here."""
REVISION = '2.3'
