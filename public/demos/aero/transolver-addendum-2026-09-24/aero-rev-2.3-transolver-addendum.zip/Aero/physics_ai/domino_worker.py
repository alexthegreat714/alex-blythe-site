"""Linux-only worker; imported neural dependencies never enter the Aero service."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import signal
import sys
import time
import traceback


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    root, out = Path('/work'), Path('/out')
    start = time.monotonic()
    record = {'state': 'STARTED', 'authority': 'RESEARCH_ONLY', 'qualification_override': False}
    def timeout(signum, frame):
        raise TimeoutError('1800-second reference execution limit exceeded')
    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(1800)
    try:
        for filename, expected in zip(('DOWNLOAD_PLAN.json', 'REFERENCE_EXECUTION_CONTRACT.json'), sys.argv[1:]):
            if sha(root / filename) != expected:
                raise ValueError('Input manifest changed after preflight')
        for entry in json.loads((root / 'DOWNLOAD_PLAN.json').read_text())['files']:
            if entry['kind'] != 'dependency' and sha(root / entry['path']) != entry['sha256']:
                raise ValueError('Input changed: ' + entry['path'])
        import numpy as np
        import torch
        import pyvista as pv
        from omegaconf import OmegaConf
        sys.path.insert(0, '/work/upstream')
        from main import DoMINOInference
        record['software_versions'] = {p: importlib.metadata.version(p)
                                       for p in ('torch', 'nvidia-physicsnemo', 'pyvista', 'numpy')}
        record['installed_packages'] = sorted((p.metadata['Name'], p.version) for p in importlib.metadata.distributions())
        record['hardware'] = torch.cuda.get_device_name(0)
        record['cuda_version'] = torch.version.cuda
        torch.cuda.set_per_process_memory_fraction(0.9)
        torch.manual_seed(0)
        cfg = OmegaConf.load(root / 'upstream/conf/config.yaml')
        trained = OmegaConf.load(root / 'checkpoints/config.yaml')
        for key in ('bounding_box', 'bounding_box_surface'):
            if OmegaConf.to_container(cfg.data[key]) != OmegaConf.to_container(trained.data[key]):
                raise ValueError('Bounding boxes differ')
        model = DoMINOInference(cfg=cfg, model_checkpoint_path=str(root / 'checkpoints/DoMINO.0.501.mdlus'), device=torch.device('cuda'))
        mesh = pv.read(root / 'reference/drivaer_1.stl')
        results = model(mesh, stream_velocity=38.889, air_density=1.205, stencil_size=7, verbose=True)
        torch.cuda.synchronize()
        np.savez(out / 'prediction.npz', **results)
        record['outputs'] = {k: {'shape': list(v.shape), 'finite': bool(np.isfinite(v).all())} for k, v in results.items()}
        record['aerodynamic_force_N_upstream_sign'] = results['aerodynamic_force'].tolist()
        record['peak_torch_allocated_bytes'] = torch.cuda.max_memory_allocated()
        record['state'] = 'INFERENCE_COMPLETED' if all(v['finite'] for v in record['outputs'].values()) else 'NONFINITE_PREDICTION'
        record['strict_determinism'] = False
    except BaseException:
        record['state'] = 'FAILED'
        record['traceback'] = traceback.format_exc()
    finally:
        signal.alarm(0)
        record['wall_seconds'] = time.monotonic() - start
        (out / 'EXECUTION_RESULT.json').write_text(json.dumps(record, indent=2))
        print(json.dumps(record, indent=2), flush=True)
    return 0 if record['state'] == 'INFERENCE_COMPLETED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
