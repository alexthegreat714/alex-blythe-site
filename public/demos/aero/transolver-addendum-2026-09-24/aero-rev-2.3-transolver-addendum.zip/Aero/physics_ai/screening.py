"""Predeclared candidate ordering, not geometry optimization or acceptance."""
from Aero.engineering_validity.contracts import digest, number
from .evidence import verify_result


def rank_candidates(candidates, *, registry, contract, evidence_root, specification):
    if set(specification) != {'quantity', 'units', 'direction'} or specification['direction'] not in ('minimize', 'maximize'):
        raise ValueError('Predeclared quantity, units and direction required')
    if not specification['quantity'] or not specification['units']:
        raise ValueError('Quantity and units required')
    if len({c['candidate_id'] for c in candidates}) != len(candidates):
        raise ValueError('Unique candidate IDs required')
    rows = []
    for candidate in candidates:
        record = candidate['record']
        summary = verify_result(record, evidence_root, registry, contract)
        value = record['payload']['outputs']['scalar_observables'].get(specification['quantity'])
        reason = None
        if record['payload']['case'].get('candidate_id') != candidate['candidate_id']:
            raise ValueError('Candidate identity mismatch')
        if not summary['eligible_for_supporting_interpretation'] or summary['authority'] not in ('SURROGATE_ONLY', 'VALIDATED_SURROGATE'):
            reason = 'APPLICABILITY_AUTHORITY_OR_VALIDITY_NOT_ESTABLISHED'
        elif not value or value['units'] != specification['units']:
            reason = 'OBSERVABLE_OR_UNITS_NOT_COMPARABLE'
        rows.append({'candidate_id': candidate['candidate_id'], 'witness_sha256': record['sha256'],
                     'eligible': reason is None, 'reason': reason, 'summary': summary,
                     'value': number(value['value']) if value and reason is None else None,
                     'uncertainty': record['payload']['uncertainty'],
                     'disposition': 'REVIEW_ONLY' if reason is None else 'RETAINED_NOT_RANKED'})
    eligible = sorted((r for r in rows if r['eligible']), key=lambda r: ((r['value'] if specification['direction'] == 'minimize' else -r['value']), r['candidate_id']))
    return {'specification': specification, 'specification_sha256': digest(specification),
            'ranked_candidate_ids': [r['candidate_id'] for r in eligible], 'all_candidates': rows,
            'status': 'RANKED_FOR_REVIEW_ONLY' if eligible else 'NOT_ESTABLISHED',
            'automatic_rejection': False, 'geometry_mutation': False,
            'required_conventional_qualification_unchanged': True}
