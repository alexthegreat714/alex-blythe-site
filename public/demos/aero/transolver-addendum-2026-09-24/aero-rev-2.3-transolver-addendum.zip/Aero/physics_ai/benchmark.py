"""Dependency-light, identity-aligned field evaluation. Never engineering validation."""
from datetime import datetime, timezone
import json
import math
from pathlib import Path
from Aero.engineering_validity.contracts import digest, number
from .evidence import artifact, conservation_check


def field(data):
    if set(data) != {'ids', 'components', 'units', 'values', 'weights'}:
        raise ValueError('Explicit sample IDs, components, units, values and integration weights required')
    ids, components = data['ids'], data['components']
    if not ids or any(not isinstance(x, str) or not x for x in ids) or len(set(ids)) != len(ids):
        raise ValueError('Unique nonempty string sample IDs required')
    if not components or any(not isinstance(x, str) or not x for x in components) or len(set(components)) != len(components):
        raise ValueError('Unique component names required')
    if not isinstance(data['units'], str) or not data['units']:
        raise ValueError('Field units required')
    values, weights = data['values'], data['weights']
    if len(values) != len(ids) or len(weights) != len(ids):
        raise ValueError('Field length mismatch')
    for row in values:
        if len(row) != len(components):
            raise ValueError('Component count mismatch')
        for value in row:
            number(value)
    if any(number(w) <= 0 for w in weights):
        raise ValueError('Positive integration weights required')
    return data


def field_metrics(reference, prediction):
    a, b = field(reference), field(prediction)
    if any(a[k] != b[k] for k in ('ids', 'components', 'units', 'weights')):
        raise ValueError('Exact spatial/order, components, units and quadrature correspondence required')
    result = {}
    for j, component in enumerate(a['components']):
        x, y = [row[j] for row in a['values']], [row[j] for row in b['values']]
        d = [v - u for u, v in zip(x, y)]
        n = len(d); den = math.fsum(v*v for v in x)
        mx, my = math.fsum(x)/n, math.fsum(y)/n
        covariance = math.fsum((u-mx)*(v-my) for u, v in zip(x, y))
        variance = math.fsum((u-mx)**2 for u in x)*math.fsum((v-my)**2 for v in y)
        reference_integral = math.fsum(w*v for w, v in zip(a['weights'], x))
        prediction_integral = math.fsum(w*v for w, v in zip(a['weights'], y))
        result[component] = {'mean_absolute_error': math.fsum(abs(v) for v in d)/n,
            'rms_error': math.sqrt(math.fsum(v*v for v in d)/n),
            'maximum_absolute_error': max(abs(v) for v in d),
            'relative_l2_error': math.sqrt(math.fsum(v*v for v in d)/den) if den > 0 else None,
            'relative_l2_state': 'CALCULATED' if den > 0 else 'ZERO_REFERENCE_NOT_INFORMATIVE',
            'correlation': max(-1., min(1., covariance/math.sqrt(variance))) if variance > 0 else None,
            'reference_integral': reference_integral, 'prediction_integral': prediction_integral,
            'signed_integral_error': prediction_integral-reference_integral}
        if any(not math.isfinite(v) for v in result[component].values() if isinstance(v, (float, int))):
            raise ValueError('Metric overflow; no nonfinite scores retained')
    return {'samples': len(a['ids']), 'field_units': a['units'], 'components': result,
            'weight_units': 'DEFINED_BY_FROZEN_BENCHMARK_SPEC', 'engineering_validation': 'NOT_ESTABLISHED'}


def freeze_benchmark(root, specification):
    """Freeze scope/reference/metrics; explicitly distinguish retrospective scoring."""
    required = {'benchmark_id', 'dataset', 'dataset_revision', 'reference_path', 'reference_sha256',
                'reference_origin', 'geometry_identity', 'weight_units', 'limits', 'balance_limits', 'evaluation_design'}
    if set(specification) != required:
        raise ValueError('Exact benchmark specification required')
    for key in required - {'limits', 'balance_limits'}:
        if not isinstance(specification[key], str) or not specification[key].strip():
            raise ValueError('Explicit benchmark metadata required: ' + key)
    if specification['evaluation_design'] not in ('PROSPECTIVE', 'RETROSPECTIVE_DESCRIPTIVE'):
        raise ValueError('Explicit prospective or retrospective evaluation design required')
    if specification['evaluation_design']=='RETROSPECTIVE_DESCRIPTIVE' and (specification['limits'] or specification['balance_limits']):
        raise ValueError('Retrospective adapter demo cannot introduce acceptance limits')
    ref = artifact(root, specification['reference_path'])
    if ref['sha256'] != specification['reference_sha256']:
        raise ValueError('Reference identity mismatch')
    data = field(json.loads((Path(root)/ref['path']).read_text()))
    metrics = {'mean_absolute_error', 'rms_error', 'maximum_absolute_error', 'relative_l2_error'}
    for row in specification['limits']:
        if set(row) != {'component', 'metric', 'maximum'} or row['component'] not in data['components'] or row['metric'] not in metrics or number(row['maximum']) < 0:
            raise ValueError('Invalid predeclared field limit')
    for name, limit in specification['balance_limits'].items():
        if not isinstance(name, str) or not name or number(limit) < 0:
            raise ValueError('Invalid balance limit')
    body = {'schema': 'aero.physics_ai_benchmark_contract.v1', 'specification': specification,
            'reference': ref, 'created_at': datetime.now(timezone.utc).isoformat()}
    record = {'payload': body, 'sha256': digest(body)}
    path = Path(root)/('benchmark-contract-'+record['sha256']+'.json')
    with path.open('x', encoding='utf8') as stream:
        json.dump(record, stream, indent=2, allow_nan=False)
    return path


def evaluate_benchmark(root, contract_path, prediction_path):
    contract_artifact = artifact(root, contract_path)
    contract = json.loads((Path(root)/contract_path).read_text())
    body = contract['payload']
    if digest(body) != contract['sha256']:
        raise ValueError('Benchmark contract changed')
    spec = body['specification']; ref = artifact(root, spec['reference_path'])
    if ref != body['reference']:
        raise ValueError('Frozen reference changed')
    predicted = artifact(root, prediction_path)
    pred = json.loads((Path(root)/prediction_path).read_text())
    if pred['benchmark_contract_sha256'] != contract['sha256'] or pred['geometry_identity'] != spec['geometry_identity']:
        raise ValueError('Prediction does not identify the frozen benchmark/geometry')
    if not isinstance(pred.get('model_identity'), dict) or not pred['model_identity']:
        raise ValueError('Prediction model/checkpoint provenance required')
    import re
    if not re.fullmatch('[a-f0-9]{64}', pred['model_identity'].get('checkpoint_sha256','')):
        raise ValueError('Exact checkpoint hash required')
    metrics = field_metrics(json.loads((Path(root)/ref['path']).read_text()), pred['field'])
    metrics['weight_units'] = spec['weight_units']
    checks = []
    for limit in spec['limits']:
        value = metrics['components'][limit['component']][limit['metric']]
        checks.append({**limit, 'value': value, 'status': 'NOT_ESTABLISHED' if value is None else ('PASS' if value <= limit['maximum'] else 'FAIL')})
    balances = {}
    for name, limit in spec['balance_limits'].items():
        terms = pred.get('balances', {}).get(name)
        balances[name] = {'status': 'NOT_ESTABLISHED'} if terms is None else conservation_check(terms['signed_terms'], terms['scale'], limit)
    states = [c['status'] for c in checks] + [c['status'] for c in balances.values()]
    status = 'FAIL' if 'FAIL' in states else ('PASS_BENCHMARK_ONLY' if states and all(x == 'PASS' for x in states) else 'NOT_ESTABLISHED')
    result = {'schema': 'aero.physics_ai_benchmark_result.v1', 'contract': contract_artifact,
              'reference': ref, 'prediction': predicted, 'metrics': metrics, 'checks': checks,
              'balances': balances, 'status': status, 'engineering_validation': 'NOT_ESTABLISHED',
              'evaluation_design': spec['evaluation_design'],
              'model_identity': pred['model_identity'], 'qualification_override': False}
    path = Path(root)/('benchmark-result-'+digest(result)+'.json')
    with path.open('x', encoding='utf8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    return result
