"""Surrogate evidence may defer a frozen optional experiment, never a required gate."""
from Aero.engineering_validity.contracts import digest, number


def assess_optional_experiment(contract, model, diagnosis, witness, experiment_id):
    policy = contract.get('physics_ai_policy', {})
    experiment = next((x for x in policy.get('optional_experiments', []) if x['id'] == experiment_id), None)
    if experiment is None:
        raise ValueError('Experiment was not predeclared in the frozen contract')
    if experiment['hypothesis_id'] not in {h['id'] for h in diagnosis['hypotheses']}:
        raise ValueError('Hypothesis absent from current diagnosis')
    summary, payload = witness['summary'], witness['record']['payload']
    value = payload['outputs']['scalar_observables'].get(experiment['quantity'])
    reasons = []
    if payload['model_id'] not in policy['allowed_models']:
        reasons.append('MODEL_NOT_PREDECLARED')
    if not summary['eligible_for_supporting_interpretation'] or summary['authority'] not in ('SURROGATE_ONLY', 'VALIDATED_SURROGATE'):
        reasons.append('WITNESS_NOT_ELIGIBLE')
    if payload['case'].get('engineering_model_sha256') != digest(model):
        reasons.append('WITNESS_MODEL_ALIGNMENT_NOT_ESTABLISHED')
    if not value or value['units'] != experiment['units']:
        reasons.append('QUANTITY_NOT_COMPARABLE')
    margin = None
    if not reasons:
        x = number(value['value'])
        margin = max(experiment['expected_lower']-x, x-experiment['expected_upper'], 0.)
        if margin < experiment['minimum_margin']:
            reasons.append('INSUFFICIENT_CONTRADICTION_MARGIN')
    return {'experiment_id': experiment_id, 'hypothesis_id': experiment['hypothesis_id'],
            'decision': 'DEFER_OPTIONAL_EXPERIMENT' if not reasons else 'NO_SCHEDULING_CHANGE',
            'hypothesis_state': 'CONTRADICTED_BY_SURROGATE_NOT_ELIMINATED' if not reasons else 'UNRESOLVED',
            'reasons': reasons or ['Frozen hypothesis interval contradicted with the predeclared margin; defer only this optional experiment'],
            'margin': margin, 'witness_sha256': witness['record']['sha256'],
            'contract_sha256': digest(contract), 'model_sha256': digest(model),
            'diagnosis_id': diagnosis['id'], 'uncertainty': payload['uncertainty'],
            'source_independence': summary['independence'], 'qualification_override': False,
            'engineering_hypothesis_eliminated': False}


def deferred(row, proposal):
    identity = proposal.get('optional_experiment_id')
    if not identity:
        return False
    matches = [r for r in row.get('physics_ai_experiment_reviews', [])
               if r['experiment_id'] == identity and r['diagnosis_id'] == proposal['diagnosis_id']
               and r['model_sha256'] == digest(row['current']['model'])]
    return bool(matches and matches[-1]['decision'] == 'DEFER_OPTIONAL_EXPERIMENT')
