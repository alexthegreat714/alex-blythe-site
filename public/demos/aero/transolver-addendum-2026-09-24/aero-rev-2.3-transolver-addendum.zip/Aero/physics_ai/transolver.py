"""Optional, offline, hash-pinned NVIDIA Transolver reference adapter.

No model package imports, downloads, environment mutation, or arbitrary case dispatch.
"""
import json
from pathlib import Path
import re
import subprocess
import time
import uuid
from .registry import file_hash

MODEL_ID='nvidia-transolver-drivaerml-surface-1.0'
CHECKPOINT_SHA256='eb98f399a050a8f8a24919335c61642e4a835bd4044f7e21abec231aa31fd82c'


def inspect_bundle(config,model):
    result={'model_id':model['model_id'],'executed':False,'automatic_download':False,
            'conventional_workflow_available':True,'qualification_override':False}
    try:
        if model['model_id']!=MODEL_ID or model['checkpoint']['sha256']!=CHECKPOINT_SHA256:
            raise ValueError('Unsupported checkpoint identity')
        root=Path(config['bundle']).resolve();ref=Path(config['reference_bundle']).resolve()
        contract_path=root/'REFERENCE_EXECUTION_CONTRACT.json'
        if file_hash(contract_path)!=config['contract_sha256']:raise ValueError('Contract changed')
        c=json.loads(contract_path.read_text())
        if c['model_id']!=MODEL_ID or c['checkpoint_sha256']!=CHECKPOINT_SHA256:raise ValueError('Contract model mismatch')
        if c['authority']!='RESEARCH_ONLY' or c['qualification_effect']!='NONE':raise ValueError('Invalid reference authority')
        if not re.fullmatch(r'python@sha256:[a-f0-9]{64}',c['image']):raise ValueError('Pinned image required')
        if c['venv_volume']!='aero-domino-runtime-20260924':raise ValueError('Unapproved runtime volume')
        if c['sample_count']!=200000 or c['wall_seconds_limit']!=600 or c['memory_limit']!='3g':raise ValueError('Unapproved resource scope')
        if c['gpu_memory_fraction']!=0.8 or c['minimum_free_gpu_bytes']!=16000000000:raise ValueError('Unapproved GPU scope')
        if c['bundle_hashes'].get('checkpoint/Transolver.0.501.mdlus')!=CHECKPOINT_SHA256:
            raise ValueError('Checkpoint absent from custody map')
        if not {'checkpoint/global_stats.json','upstream/physicsnemo/datapipes/cae/transolver_datapipe.py'}.issubset(c['bundle_hashes']):
            raise ValueError('Preprocessing identity missing')
        if not {'reference/drivaer_1.stl','reference/boundary_1.vtp','reference/boundary_cell_area_1.npy'}.issubset(c['reference_hashes']):
            raise ValueError('Native reference custody missing')
        if file_hash(root/'APPROVAL.json')!=c['approval_sha256']:raise ValueError('Approval identity changed')
        approval=json.loads((root/'APPROVAL.json').read_text())
        if approval['model_id']!=MODEL_ID or approval['authority']!='RESEARCH_ONLY':raise ValueError('Approval scope mismatch')
        for base,hashes in ((root,c['bundle_hashes']),(ref,c['reference_hashes'])):
            for rel,h in hashes.items():
                p=(base/rel).resolve()
                if Path(rel).is_absolute() or not p.is_relative_to(base) or file_hash(p)!=h:
                    raise ValueError('Input identity failed: '+rel)
        if file_hash(Path(__file__).with_name('transolver_worker.py'))!=c['worker_sha256']:
            raise ValueError('Worker differs from frozen contract')
        return dict(result,status='REFERENCE_WORKER_READY',model_available=True,
                    hardware_compatibility='RECHECKED_IN_WORKER',contract_sha256=config['contract_sha256'])
    except (OSError,ValueError,KeyError,TypeError) as e:
        return dict(result,status='REFERENCE_PREFLIGHT_BLOCKED',model_available=False,reason=str(e))


def execute_reference(config,model,case,outputs,*,acknowledge_research=False):
    pre=inspect_bundle(config,model)
    if pre['status']!='REFERENCE_WORKER_READY':return pre
    if not acknowledge_research:return dict(pre,status='RESEARCH_ACKNOWLEDGEMENT_REQUIRED')
    if case.get('case_id')!='drivaerml-run-1-reference' or case.get('geometry_family')!='automotive_external_drivaer' or set(outputs)!={'surface_pressure','wall_shear_stress'}:
        return dict(pre,status='UNSUPPORTED_REFERENCE_CASE')
    root=Path(config['bundle']).resolve();ref=Path(config['reference_bundle']).resolve()
    c=json.loads((root/'REFERENCE_EXECUTION_CONTRACT.json').read_text())
    docker=config.get('docker_executable','docker')
    try:
        image=subprocess.run([docker,'image','inspect',c['image']],capture_output=True,text=True,timeout=15)
    except (OSError,subprocess.TimeoutExpired) as e:return dict(pre,status='DEPENDENCY_UNAVAILABLE',reason=str(e))
    if image.returncode:return dict(pre,status='DEPENDENCY_UNAVAILABLE',reason='Pinned image is not locally available')
    run_id='transolver-'+uuid.uuid4().hex[:12]
    out=root/'executions'/run_id;out.mkdir(parents=True)
    for name in ('cache','tmp','home'):(out/name).mkdir()
    (out/'DISPATCH.json').write_text(json.dumps({'model':model,'case':case,'contract_sha256':config['contract_sha256'],
        'worker_sha256':c['worker_sha256'],'image_inspect':json.loads(image.stdout)},indent=2))
    started=time.perf_counter()
    for mode in ('prepare','infer'):
        name=run_id+'-'+mode
        args=[docker,'run','--pull','never','--name',name,'--gpus','all','--network','none','--read-only',
          '--cap-drop','ALL','--security-opt','no-new-privileges','--cpus','4','--memory',c['memory_limit'],
          '--memory-swap',c['memory_limit'],'--pids-limit','256','--log-driver','none',
          '--mount',f'type=volume,src={c["venv_volume"]},dst=/work/venv,readonly',
          '--mount',f'type=bind,src={root},dst=/bundle,readonly',
          '--mount',f'type=bind,src={ref},dst=/reference,readonly',
          '--mount',f'type=bind,src={out},dst=/out',
          '--mount',f'type=bind,src={Path(__file__).parent.resolve()},dst=/adapter,readonly']
        for env in ('HOME=/out/home','TMPDIR=/out/tmp','XDG_CACHE_HOME=/out/cache','TORCH_HOME=/out/cache',
                    'HF_HUB_OFFLINE=1','PYTHONDONTWRITEBYTECODE=1','OMP_NUM_THREADS=4','OPENBLAS_NUM_THREADS=4'):
            args+=['-e',env]
        args += [c['image'],'/work/venv/bin/python','/adapter/transolver_worker.py',mode]
        (out/(mode+'_COMMAND.json')).write_text(json.dumps(args,indent=2))
        try:
            with (out/(mode+'.stdout.log')).open('x') as stdout,(out/(mode+'.stderr.log')).open('x') as stderr:
                done=subprocess.run(args,stdout=stdout,stderr=stderr,text=True,timeout=c['wall_seconds_limit']+30)
            code=done.returncode
        except subprocess.TimeoutExpired:
            subprocess.run([docker,'stop','--time','5',name],capture_output=True,timeout=15)
            code='TIMEOUT'
        except OSError as e:code=str(e)
        try:
            detail=subprocess.run([docker,'inspect',name],capture_output=True,text=True,timeout=15)
            container_detail=detail.stdout or detail.stderr
        except (OSError,subprocess.TimeoutExpired) as e:
            container_detail=json.dumps({'status':'INSPECTION_UNAVAILABLE','reason':str(e)})
        (out/(mode+'_CONTAINER.json')).write_text(container_detail)
        if code!=0:
            result=dict(pre,status='REFERENCE_EXECUTION_FAILED',executed=True,stage=mode,exit_code=code,artifact_directory=str(out))
            (out/'COMPLETION.json').write_text(json.dumps(result,indent=2));return result
    try:
        execution=json.loads((out/'EXECUTION_RESULT.json').read_text())
        if execution['state']!='INFERENCE_COMPLETED' or file_hash(out/'prediction.npz')!=execution['prediction_sha256']:
            raise ValueError('Worker output identity failed')
    except (OSError,ValueError,KeyError,TypeError) as e:
        result=dict(pre,status='REFERENCE_OUTPUT_VERIFICATION_FAILED',executed=True,artifact_directory=str(out),reason=str(e))
        (out/'COMPLETION.json').write_text(json.dumps(result,indent=2));return result
    final=inspect_bundle(config,model)
    result=dict(pre,status='REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED' if final['status']=='REFERENCE_WORKER_READY' else 'SOURCE_CHANGED_AFTER_EXECUTION',
                executed=True,artifact_directory=str(out),prediction_sha256=execution['prediction_sha256'],
                wall_seconds=time.perf_counter()-started,source_unchanged=final['status']=='REFERENCE_WORKER_READY')
    (out/'COMPLETION.json').write_text(json.dumps(result,indent=2));return result
