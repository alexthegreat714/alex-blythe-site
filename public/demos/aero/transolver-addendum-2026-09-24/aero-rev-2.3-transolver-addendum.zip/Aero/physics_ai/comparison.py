"""Deterministic comparisons, not averaging, voting, or engineering acceptance."""
from itertools import combinations
import math

SOURCES={'FIRST_PRINCIPLES_RESULT','PHYSICS_AI_RESULT','CONVENTIONAL_SOLVER_RESULT','EXPERIMENTAL_RESULT'}

def compare_observables(records,*,absolute_tolerance,relative_tolerance):
    """Tolerances must come from a predeclared comparison specification in caller custody."""
    if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and x>=0 for x in (absolute_tolerance,relative_tolerance)):
        raise ValueError('Finite nonnegative comparison tolerances required')
    if len({r['source_id'] for r in records})!=len(records):raise ValueError('Unique source IDs required')
    for r in records:
        if r['source_type'] not in SOURCES:raise ValueError('Unknown evidence source')
        for value in r['observables'].values():
            if not isinstance(value['value'],(int,float)) or isinstance(value['value'],bool) or not math.isfinite(value['value']):
                raise ValueError('Finite observations required')
    rows=[]
    for a,b in combinations(records,2):
        for name in sorted(set(a['observables'])|set(b['observables'])):
            x=a['observables'].get(name);y=b['observables'].get(name)
            row={'sources':[a['source_id'],b['source_id']],'observable':name,'status':'NOT_COMPARABLE'}
            if x and y and x.get('units') and x['units']==y.get('units'):
                delta=abs(x['value']-y['value']);limit=absolute_tolerance+relative_tolerance*max(abs(x['value']),abs(y['value']))
                row.update(status='AGREEMENT' if delta<=limit else 'DISCREPANCY',absolute_difference=delta,limit=limit,units=x['units'])
            rows.append(row)
    disagree=any(r['status']=='DISCREPANCY' for r in rows)
    comparable=any(r['status'] in ('AGREEMENT','DISCREPANCY') for r in rows)
    return {'comparisons':rows,'source_records':records,'consensus_value':None,
        'disposition':'INVESTIGATION_REQUIRED' if disagree else ('AGREEMENT_IS_NOT_VALIDATION' if comparable else 'NOT_ESTABLISHED'),
        'hypothesis_prompts':['Boundary/configuration or numerical error','Analytical approximation missing physics',
            'Surrogate applicability or shared training/model assumptions','Unexpected result represents real physics'] if disagree else [],
        'mandatory_solver_gates_unchanged':True}
