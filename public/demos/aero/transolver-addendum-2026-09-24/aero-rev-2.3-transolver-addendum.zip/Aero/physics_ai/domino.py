"""Opt-in, isolated replay of the pinned DoMINO automotive reference workflow.

This is a reference adapter, not an arbitrary-geometry CFD service. Configuration
is trusted local operator input. It never downloads or installs dependencies.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import time
import uuid

from .registry import file_hash

MODEL_ID = 'domino-drivaerml-surface-1.0'
IMAGE = 'python@sha256:9534e5a8e315485d4061ed659af0fd78a284c015f9b73661b41d6bab25604534'
CHECKPOINT = 'ad45e9477a7c0336c07a039ba70db7ddc9a2254d4ff94104d9c297ae7d7b662b'
GEOMETRY = '411e6651284a26fc94924106b833fd79febc6deba63922c929dd8acfc99720d2'
WORKFLOW = '0612ec4ed54484a47bfa134eda7b3b012a607624'


def inspect_bundle(config, model):
    """No executable or model deserialization during inspection."""
    try:
        if model['model_id'] != MODEL_ID:
            raise ValueError('Unsupported reference model')
        if model['checkpoint']['sha256'] != CHECKPOINT:
            raise ValueError('Unrecognized checkpoint revision')
        bundle = Path(config['bundle']).resolve(strict=True)
        plan_path = bundle / 'DOWNLOAD_PLAN.json'
        if file_hash(plan_path) != config['download_plan_sha256']:
            raise ValueError('Download plan identity mismatch')
        entries = json.loads(plan_path.read_text())['files']
        verified = {}
        for entry in entries:
            if entry['kind'] == 'dependency':
                continue
            relative = Path(entry['path'])
            path = (bundle / relative).resolve(strict=True)
            if relative.is_absolute() or not path.is_relative_to(bundle):
                raise ValueError('Bundle path escape')
            if file_hash(path) != entry['sha256']:
                raise ValueError('Bundle artifact changed: ' + entry['path'])
            verified[entry['path']] = entry['sha256']
        required = {'checkpoints/DoMINO.0.501.mdlus': CHECKPOINT,
                    'reference/drivaer_1.stl': GEOMETRY}
        for key, value in required.items():
            if verified.get(key) != value:
                raise ValueError('Reference identity missing: ' + key)
        for key in ('upstream/main.py', 'upstream/design_datapipe.py',
                    'upstream/conf/config.yaml', 'checkpoints/config.yaml',
                    'checkpoints/scaling_factors.pkl'):
            if key not in verified:
                raise ValueError('Required preprocessing artifact missing: ' + key)
        if config.get('workflow_commit') != WORKFLOW:
            raise ValueError('Unrecognized upstream workflow')
        contract_path = bundle / 'REFERENCE_EXECUTION_CONTRACT.json'
        if file_hash(contract_path) != config['contract_sha256']:
            raise ValueError('Reference execution contract changed')
        contract = json.loads(contract_path.read_text())
        for key, value in {'stream_velocity_m_s': 38.889, 'air_density_kg_m3': 1.205,
                           'stencil_size': 7, 'torch_seed': 0,
                           'workflow_commit': WORKFLOW}.items():
            if contract.get(key) != value:
                raise ValueError('Unsupported reference setting: ' + key)
        if json.loads((bundle / 'INSTALL_RESULT.json').read_text())['state'] != 'INSTALLED':
            raise ValueError('Runtime installation not established')
        if json.loads((bundle / 'SMOKE_RUNTIME_RESULT.json').read_text())['state'] != 'PASS':
            raise ValueError('Runtime smoke check not established')
        if config.get('image') != IMAGE:
            raise ValueError('Unrecognized container image')
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}', config['runtime_volume']):
            raise ValueError('Invalid runtime volume')
        for key in ('bundle', 'output_root'):
            if any(c in str(config[key]) for c in ('\n', '\r', ',')):
                raise ValueError('Unsafe mount path')
        return {'status': 'REFERENCE_BUNDLE_READY', 'model_available': True,
                'verified_inputs': verified, 'hardware_compatibility': 'REQUIRES_WORKER_CHECK',
                'automatic_download': False}
    except (OSError, KeyError, ValueError, TypeError) as exc:
        return {'status': 'REFERENCE_BUNDLE_UNAVAILABLE', 'model_available': False,
                'reason': str(exc), 'automatic_download': False}


def execute_reference(config, model, case, outputs, *, acknowledge_research=False):
    base = {'executed': False, 'authority': 'RESEARCH_ONLY',
            'conventional_workflow_available': True, 'qualification_override': False}
    if not acknowledge_research:
        return dict(base, status='RESEARCH_ACKNOWLEDGEMENT_REQUIRED')
    if case.get('case_id') != 'DrivAerML-run-1' or case.get('geometry_sha256') != GEOMETRY:
        return dict(base, status='REFERENCE_CASE_ONLY', reason='Arbitrary cases are not implemented')
    if not outputs or not set(outputs).issubset({'surface_pressure', 'wall_shear_stress'}):
        return dict(base, status='UNSUPPORTED_OUTPUT')
    ready = inspect_bundle(config, model)
    if ready['status'] != 'REFERENCE_BUNDLE_READY':
        return dict(base, **ready)
    docker = config.get('docker', 'docker')
    # Probe only; no pull, install, daemon restart or shared worker mutation.
    try:
        probe = subprocess.run([docker, 'image', 'inspect', IMAGE], capture_output=True,
                               text=True, timeout=20, check=True)
    except (OSError, subprocess.SubprocessError) as exc:
        return dict(base, status='DEPENDENCY_UNAVAILABLE', reason=str(exc))
    run_id = 'domino-' + uuid.uuid4().hex
    out = Path(config['output_root']).resolve() / run_id
    out.mkdir(parents=True, exist_ok=False)
    for folder in ('cache', 'home', 'tmp'):
        (out / folder).mkdir()
    worker = Path(__file__).with_name('domino_worker.py').resolve()
    args = [docker, 'run', '--pull', 'never', '--name', run_id, '--gpus', 'all',
            '--network', 'none', '--read-only', '--cap-drop', 'ALL',
            '--security-opt', 'no-new-privileges', '--cpus', '4',
            '--memory', '2560m', '--memory-swap', '2560m', '--pids-limit', '256',
            '--log-driver', 'none', '--mount',
            f'type=bind,source={Path(config["bundle"]).resolve()},target=/work,readonly',
            '--mount', f'type=volume,source={config["runtime_volume"]},target=/work/venv,readonly',
            '--mount', f'type=bind,source={out},target=/out', '--mount',
            f'type=bind,source={worker.parent},target=/adapter,readonly']
    for key, value in {'HOME': '/out/home', 'TMPDIR': '/out/tmp', 'XDG_CACHE_HOME': '/out/cache',
                       'TORCH_HOME': '/out/cache/torch', 'WARP_CACHE_PATH': '/out/cache/warp',
                       'MPLCONFIGDIR': '/out/cache/matplotlib', 'CUPY_CACHE_DIR': '/out/cache/cupy',
                       'NUMBA_CACHE_DIR': '/out/cache/numba', 'PYTHONDONTWRITEBYTECODE': '1',
                       'HF_HUB_OFFLINE': '1', 'OMP_NUM_THREADS': '4', 'OPENBLAS_NUM_THREADS': '4'}.items():
        args.extend(['--env', key + '=' + value])
    args.extend(['--workdir', '/work', IMAGE, '/work/venv/bin/python', '-u',
                 '/adapter/domino_worker.py', config['download_plan_sha256'], config['contract_sha256']])
    receipt = {'schema': 'aero.domino_reference_execution.v1', 'run_id': run_id,
               'started_at': datetime.now(timezone.utc).isoformat(), 'command': args,
               'adapter_sha256': file_hash(__file__), 'worker_sha256': file_hash(worker),
               'image_inspection': json.loads(probe.stdout), 'inputs': ready['verified_inputs'],
               'case': case, 'model_entry_at_dispatch': model,
               'authority': 'RESEARCH_ONLY', 'qualification_override': False}
    (out / 'LAUNCH.json').write_text(json.dumps(receipt, indent=2))
    started = time.monotonic()
    status = 'WORKER_FAILED'
    try:
        with (out / 'stdout.log').open('x') as stdout, (out / 'stderr.log').open('x') as stderr:
            result = subprocess.run(args, stdout=stdout, stderr=stderr, timeout=1860, check=False)
        receipt['exit_code'] = result.returncode
        if result.returncode == 0:
            record = json.loads((out / 'EXECUTION_RESULT.json').read_text())
            if record['state'] == 'INFERENCE_COMPLETED' and (out / 'prediction.npz').is_file():
                status = 'REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED'
                receipt['prediction_sha256'] = file_hash(out / 'prediction.npz')
    except subprocess.TimeoutExpired:
        status = 'WORKER_TIMEOUT'
        try:
            subprocess.run([docker, 'stop', '--time', '10', run_id], capture_output=True, timeout=20)
        except (OSError, subprocess.SubprocessError) as exc:
            receipt['stop_error'] = str(exc)
    except (OSError, ValueError, KeyError) as exc:
        receipt['error'] = str(exc)
    receipt.update(status=status, wall_seconds=time.monotonic() - started)
    try:
        state = subprocess.run([docker, 'inspect', '--format', '{{json .State}}', run_id],
                               capture_output=True, text=True, timeout=20)
        receipt['container_state'] = json.loads(state.stdout)
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        receipt['container_inspection_error'] = str(exc)
    (out / 'COMPLETION.json').write_text(json.dumps(receipt, indent=2))
    return dict(base, status=status, executed=True, run_id=run_id, artifact_directory=str(out),
                prediction_sha256=receipt.get('prediction_sha256'))
