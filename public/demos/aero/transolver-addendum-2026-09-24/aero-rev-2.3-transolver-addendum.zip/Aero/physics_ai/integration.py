"""Supporting-witness annotation cannot promote or replace the existing gate."""
import copy
from .evidence import verify_result

def annotate_gate(gate,records,root,registry,contract):
    out=copy.deepcopy(gate)
    out['physics_ai_supporting_witnesses']=[verify_result(r,root,registry,contract) for r in records]
    out['physics_ai_policy']={'may_override_disposition':False,'may_waive_required_solver_run':False,
        'may_change_acceptance_criteria':False,'may_satisfy_missing_field_custody':False}
    return out
