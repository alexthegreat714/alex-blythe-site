"""Retain an executed reference witness using the existing evidence contract.

This receipt is explicitly not an approved campaign acceptance contract. Attaching
evidence to a real campaign still requires that campaign's contract and controller.
"""
import json
from pathlib import Path
from .evidence import build_result, retain_result, verify_result
from .integration import annotate_gate
from .registry import file_hash


def retain_transolver_reference(result, config, registry, evidence_root):
    """Ingest the bounded native-cell demo; cannot attach itself to a campaign."""
    from .transolver import MODEL_ID, inspect_bundle
    from .registry import get_model
    if result.get('status') != 'REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED':
        raise ValueError('Completed reference execution required')
    if inspect_bundle(config,get_model(MODEL_ID,registry))['status']!='REFERENCE_WORKER_READY':
        raise ValueError('Reference source integrity failed')
    root=Path(evidence_root).resolve();bundle=Path(config['bundle']).resolve()
    out=Path(result['artifact_directory']).resolve()
    def relative(p):return p.resolve().relative_to(root).as_posix()
    receipt=json.loads((out/'COMPLETION.json').read_text())
    execution=json.loads((out/'EXECUTION_RESULT.json').read_text())
    dispatch=json.loads((out/'DISPATCH.json').read_text())
    contract=json.loads((bundle/'REFERENCE_EXECUTION_CONTRACT.json').read_text())
    if dispatch['model']!=get_model(MODEL_ID,registry):raise ValueError('Use registry retained at dispatch')
    if dispatch['contract_sha256']!=config['contract_sha256']:raise ValueError('Dispatch contract changed')
    if execution['state']!='INFERENCE_COMPLETED' or execution['qualification_override'] is not False:
        raise ValueError('Invalid execution receipt')
    actual=file_hash(out/'prediction.npz')
    if any(actual!=r['prediction_sha256'] for r in (receipt,execution,result)):
        raise ValueError('Prediction custody changed')
    prep=json.loads((out/'PREPROCESS_RESULT.json').read_text())
    if file_hash(out/'reference_sample.npz')!=prep['sample_sha256']:raise ValueError('Reference sample changed')
    paths=[bundle/'REFERENCE_EXECUTION_CONTRACT.json',bundle/'APPROVAL.json',bundle/'DOWNLOAD_RECEIPT.json',
           out/'reference_sample.npz',out/'COMPLETION.json',out/'DISPATCH.json',out/'EXECUTION_RESULT.json']
    paths += [bundle/p for p in contract['bundle_hashes'] if p!='checkpoint/Transolver.0.501.mdlus']
    paths += [Path(config['reference_bundle'])/p for p in contract['reference_hashes']]
    record=build_result(registry=registry,model_id=MODEL_ID,contract=contract,
        case=dispatch['case'],requested_outputs=['surface_pressure','wall_shear_stress'],
        outputs={'scalar_observables':{}},root=root,input_paths=[relative(p) for p in paths],
        field_paths=[relative(out/'prediction.npz')],checkpoint_path=relative(bundle/'checkpoint/Transolver.0.501.mdlus'),
        configuration={'seed':contract['seed'],'precision':contract['precision'],'deterministic':False,
                       'sample_count':contract['sample_count'],'full_mesh':False,'authority':'RESEARCH_ONLY'},
        runtime={'hardware':execution['hardware'],'software_versions':execution['software_versions'],
                 'wall_seconds':receipt['wall_seconds'],'inference_seconds':execution['inference_seconds']},
        code_versions={k:contract['worker_sha256'] for k in ('preprocessing','inference','postprocessing')})
    retained=retain_result(root,record)
    verified=verify_result(record,root,registry,contract)
    prior={'overall_disposition':'INCONCLUSIVE','context':'Reference demonstration, not engineering acceptance'}
    report={'witness':relative(retained),'verification':verified,
            'active_campaign_attached':False,
            'gate':annotate_gate(prior,[record],root,registry,contract),
            'native_cell_mapping_receipt':relative(out/'PREPROCESS_RESULT.json'),
            'benchmark_scope':'200000-cell sample; no full-surface force or conservation verification'}
    with (out/'WITNESS_INGESTION.json').open('x') as f:json.dump(report,f,indent=2)
    return report


def retain_reference(result, config, registry, evidence_root):
    if result.get('status') != 'REFERENCE_INFERENCE_COMPLETED_NOT_VALIDATED':
        raise ValueError('Completed reference execution required')
    root = Path(evidence_root).resolve()
    bundle = Path(config['bundle']).resolve()
    out = Path(result['artifact_directory']).resolve()
    def relative(path):
        return path.resolve().relative_to(root).as_posix()
    execution = json.loads((out / 'EXECUTION_RESULT.json').read_text())
    receipt = json.loads((out / 'COMPLETION.json').read_text())
    if execution['state'] != 'INFERENCE_COMPLETED':
        raise ValueError('Worker did not complete')
    if file_hash(out / 'prediction.npz') != receipt['prediction_sha256'] or receipt['prediction_sha256'] != result['prediction_sha256']:
        raise ValueError('Prediction custody changed')
    contract = json.loads((bundle / 'REFERENCE_EXECUTION_CONTRACT.json').read_text())
    if file_hash(bundle / 'REFERENCE_EXECUTION_CONTRACT.json') != config['contract_sha256']:
        raise ValueError('Contract changed')
    input_files = ['reference/drivaer_1.stl', 'checkpoints/config.yaml', 'checkpoints/scaling_factors.pkl',
                   'upstream/conf/config.yaml', 'upstream/main.py', 'upstream/design_datapipe.py',
                   'REFERENCE_EXECUTION_CONTRACT.json', 'DOWNLOAD_PLAN.json']
    # Recheck the identities actually verified before execution, not only current files.
    for name in input_files:
        if name in receipt['inputs'] and file_hash(bundle / name) != receipt['inputs'][name]:
            raise ValueError('Executed input changed: ' + name)
    if file_hash(bundle / 'DOWNLOAD_PLAN.json') != config['download_plan_sha256']:
        raise ValueError('Download plan changed')
    record = build_result(registry=registry, model_id='domino-drivaerml-surface-1.0',
        contract=contract, case=receipt['case'], requested_outputs=['surface_pressure', 'wall_shear_stress'],
        outputs={'scalar_observables': {}}, root=root,
        input_paths=[relative(bundle / p) for p in input_files] + [relative(out / 'COMPLETION.json')],
        field_paths=[relative(out / 'prediction.npz')],
        checkpoint_path=relative(bundle / 'checkpoints/DoMINO.0.501.mdlus'),
        configuration={'seed': 0, 'precision': 'float32', 'deterministic': False,
                       'workflow': 'pinned_upstream_reference_only'},
        runtime={'hardware': execution['hardware'], 'software_versions': execution['software_versions'],
                 'wall_seconds': execution['wall_seconds'], 'worker_receipt': relative(out / 'COMPLETION.json')},
        code_versions={'preprocessing': file_hash(bundle / 'upstream/design_datapipe.py'),
                       'inference': file_hash(bundle / 'upstream/main.py'),
                       'postprocessing': receipt['worker_sha256']})
    retained = retain_result(root, record)
    verification = verify_result(record, root, registry, contract)
    prior = {'overall_disposition': 'INCONCLUSIVE',
             'context': 'Reference witness boundary only; no approved engineering campaign acceptance contract'}
    gate = annotate_gate(prior, [record], root, registry, contract)
    report = {'witness': relative(retained), 'verification': verification,
              'dispatch_model_entry': receipt.get('model_entry_at_dispatch', 'NOT_RETAINED_IN_INITIAL_ADAPTER_ATTEMPT'),
              'retention_registry_version': registry['version'],
              'contract_kind': 'REFERENCE_EXECUTION_NOT_CAMPAIGN_ACCEPTANCE',
              'active_campaign_attached': False, 'gate': gate}
    with (out / 'WITNESS_INGESTION.json').open('x') as stream:
        json.dump(report, stream, indent=2)
    return report
