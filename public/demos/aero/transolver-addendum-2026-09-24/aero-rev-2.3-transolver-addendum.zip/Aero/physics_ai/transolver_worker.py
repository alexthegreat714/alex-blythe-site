"""Isolated NVIDIA Transolver reference worker; never imported by Aero core.

Uses the upstream PhysicsNeMo model and datapipe, not a rewritten neural model.
Reference extraction and inference are separate processes to bound host memory.
"""
import argparse
import hashlib
import json
from pathlib import Path
import signal
import time
import traceback
import zipfile


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()


def write(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)


def prepare(c,out):
    import gc
    import numpy as np
    import pyvista as pv
    ref=Path('/reference/reference')
    print('Reading native boundary',flush=True)
    mesh=pv.read(ref/'boundary_1.vtp')
    assert mesh.n_cells==c['native_cell_count']
    # Freeze IDs before consulting any field values; preserve native polygon ordering.
    ids=np.sort(np.random.default_rng(c['seed']).choice(mesh.n_cells,c['sample_count'],replace=False))
    centers=np.asarray(mesh.cell_centers().points,dtype=np.float32)[ids].copy()
    print('Computing native polygon normals',flush=True)
    normals=np.asarray(mesh.cell_normals,dtype=np.float32)[ids].copy()
    normals/=np.linalg.norm(normals,axis=1,keepdims=True)+1e-8
    pressure=np.asarray(mesh.cell_data['pMeanTrim'],dtype=np.float32)[ids].copy()
    shear=np.asarray(mesh.cell_data['wallShearStressMeanTrim'],dtype=np.float32)[ids].copy()
    cp=np.asarray(mesh.cell_data['CpMeanTrim'],dtype=np.float32)[ids].copy()
    del mesh;gc.collect()
    # Full geometry is used for upstream translation-origin semantics; no decimation.
    stl=pv.read(ref/'drivaer_1.stl')
    stl_centers=np.asarray(stl.cell_centers().points,dtype=np.float32).copy()
    del stl;gc.collect()
    area=np.load(ref/'boundary_cell_area_1.npy',mmap_mode='r',allow_pickle=False)[ids].copy()
    for x in (centers,normals,pressure,shear,cp,stl_centers,area):
        if not np.isfinite(x).all():raise ValueError('Nonfinite reference input')
    if np.any(np.linalg.norm(normals,axis=1)<0.99):raise ValueError('Degenerate surface normal')
    np.savez(out/'reference_sample.npz',native_cell_id=ids,coordinates=centers,normals=normals,
             pressure_native=pressure,shear_native=shear,cp_native=cp,area_m2=area,stl_centers=stl_centers)
    mask=np.abs(cp)>0.05
    ratio=np.median(pressure[mask]/cp[mask])
    write(out/'PREPROCESS_RESULT.json',{'state':'REFERENCE_SAMPLE_RETAINED',
        'sample_count':len(ids),'native_cell_count':c['native_cell_count'],
        'selection':'numpy.default_rng(seed).choice without replacement, sorted native IDs',
        'seed':c['seed'],'spatial_correspondence':'EXACT_NATIVE_CELL_IDS',
        'pressure_over_Cp_median':float(ratio),
        'expected_half_rho_U_squared':0.5*c['air_density_kg_m3']*c['stream_velocity_m_s']**2,
        'pressure_unit_confirmation':'REQUIRES_REVIEW_OF_REFERENCE_CONVENTION',
        'sample_sha256':sha(out/'reference_sample.npz')})
    print('Reference extraction completed',flush=True)


def infer(c,out):
    import numpy as np
    import torch
    import physicsnemo
    from physicsnemo.models.transolver import Transolver
    from physicsnemo.datapipes.cae.transolver_datapipe import TransolverDataPipe
    torch.manual_seed(c['seed'])
    torch.cuda.set_per_process_memory_fraction(c['gpu_memory_fraction'])
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    device=torch.device('cuda:0')
    free,total=torch.cuda.mem_get_info()
    if free<c['minimum_free_gpu_bytes']:raise RuntimeError('Insufficient free GPU memory; no workloads displaced')
    checkpoint=Path('/bundle/checkpoint/Transolver.0.501.mdlus')
    if sha(checkpoint)!=c['checkpoint_sha256']:raise ValueError('Checkpoint hash mismatch')
    with zipfile.ZipFile(checkpoint) as z:
        args=json.loads(z.read('args.json'))['__args__']
        if args!=c['model_arguments']:raise ValueError('Checkpoint architecture changed')
        model=Transolver(**args)
        with z.open('model.pt') as f:state=torch.load(f,map_location='cpu',weights_only=True)
        model.load_state_dict(state,strict=True)
    model=model.to(device).eval()
    stats=json.loads(Path('/bundle/checkpoint/global_stats.json').read_text())
    mean=stats['mean']['pressure']+stats['mean']['shear_stress']
    std=stats['std_dev']['pressure']+stats['std_dev']['shear_stress']
    factors={'mean':torch.tensor(mean,dtype=torch.float32,device=device),
             'std':torch.tensor(std,dtype=torch.float32,device=device)}
    prep=json.loads((out/'PREPROCESS_RESULT.json').read_text())
    if sha(out/'reference_sample.npz')!=prep['sample_sha256']:raise ValueError('Reference sample custody changed')
    sample=np.load(out/'reference_sample.npz',allow_pickle=False)
    def t(x):return torch.from_numpy(np.array(x,copy=True)).to(device=device,dtype=torch.float32)
    dp=TransolverDataPipe(input_path=None,model_type='surface',resolution=None,
        scaling_type='mean_std_scaling',surface_factors=factors,
        include_normals=True,include_sdf=False,broadcast_global_features=True,
        include_geometry=False,translational_invariance=True,
        scale_invariance=True,reference_scale=c['reference_scale'],return_mesh_features=False)
    dp.config.reference_scale=dp.config.reference_scale.to(device)
    # Reference output fields are NOT supplied to the neural model. Dummy target channel only.
    data={'surface_mesh_centers':t(sample['coordinates']), 'surface_normals':t(sample['normals']),
          'surface_fields':torch.zeros((c['sample_count'],4),device=device),
          'stl_centers':t(sample['stl_centers']),
          'air_density':torch.tensor([c['air_density_kg_m3']],device=device),
          'stream_velocity':torch.tensor([c['stream_velocity_m_s']],device=device)}
    batch=dp(data)
    torch.cuda.synchronize();start=time.perf_counter()
    with torch.inference_mode():
        pred=model(fx=batch['fx'],embedding=batch['embeddings'])
        pred=dp.unscale_model_targets(pred,factor_type='surface').squeeze(0)
        pred=pred*(c['air_density_kg_m3']*c['stream_velocity_m_s']**2)
    torch.cuda.synchronize();inference_seconds=time.perf_counter()-start
    pred=pred.cpu().numpy()
    if pred.shape!=(c['sample_count'],4) or not np.isfinite(pred).all():raise ValueError('Invalid prediction')
    np.savez(out/'prediction.npz',native_cell_id=sample['native_cell_id'],coordinates=sample['coordinates'],
             surface_pressure_Pa=pred[:,0],wall_shear_stress_Pa=pred[:,1:])
    comparison={}
    for name,p,y in [('pressure',pred[:,0],sample['pressure_native']),('shear',pred[:,1:],sample['shear_native'])]:
        p=p.astype(float);y=y.astype(float);d=p-y
        denom=np.linalg.norm(y)
        comparison[name]={'rmse':float(np.sqrt(np.mean(d*d))),
            'mae':float(np.mean(np.abs(d))),'relative_L2':float(np.linalg.norm(d)/denom) if denom else None,
            'reference_range':[float(y.min()),float(y.max())],
            'prediction_range':[float(p.min()),float(p.max())],
            'reference_units':'NATIVE_VTP_CONVENTION_REVIEW_REQUIRED',
            'interpretation':'DESCRIPTIVE_ONLY_NOT_ACCEPTANCE'}
    write(out/'EXECUTION_RESULT.json',{'state':'INFERENCE_COMPLETED',
        'authority':'RESEARCH_ONLY','physical_validation':'NOT_ESTABLISHED',
        'held_out_status':'NOT_ESTABLISHED','qualification_override':False,
        'sample_count':len(pred),'full_mesh_inference':False,'integral_force_comparison':'NOT_EVALUATED_SUBSAMPLE',
        'comparison':comparison,'inference_seconds':inference_seconds,
        'hardware':torch.cuda.get_device_name(0),'gpu_peak_allocated_bytes':torch.cuda.max_memory_allocated(),
        'gpu_peak_reserved_bytes':torch.cuda.max_memory_reserved(),
        'software_versions':{'torch':torch.__version__,'physicsnemo':physicsnemo.__version__,'numpy':np.__version__},
        'model_arguments':args,'parameters':sum(x.numel() for x in model.parameters()),
        'prediction_sha256':sha(out/'prediction.npz'),
        'reproducibility':'SEED_RECORDED_NOT_YET_REPEATED',
        'normalization_source':'checkpoint/global_stats.json','model_equations_modified':False})
    print('Inference completed',inference_seconds,comparison,flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare','infer']);a=parser.parse_args()
    out=Path('/out');start=time.perf_counter()
    c=json.loads(Path('/bundle/REFERENCE_EXECUTION_CONTRACT.json').read_text())
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Worker time bound exceeded')))
    signal.alarm(c['wall_seconds_limit'])
    try:
        for rel,expected in c['bundle_hashes'].items():
            if sha(Path('/bundle')/rel)!=expected:raise ValueError('Bundle identity changed: '+rel)
        for rel,expected in c['reference_hashes'].items():
            if sha(Path('/reference')/rel)!=expected:raise ValueError('Reference identity changed: '+rel)
        if sha(__file__)!=c['worker_sha256']:raise ValueError('Worker code identity changed')
        (prepare if a.mode=='prepare' else infer)(c,out)
        write(out/(a.mode+'_TIMING.json'),{'wall_seconds':time.perf_counter()-start})
    except Exception as e:
        write(out/(a.mode+'_FAILURE.json'),{'state':'FAILED','type':type(e).__name__,'reason':str(e),'traceback':traceback.format_exc()})
        raise
if __name__=='__main__':main()
