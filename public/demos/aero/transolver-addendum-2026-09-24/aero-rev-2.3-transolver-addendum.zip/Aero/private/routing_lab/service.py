"""Scoped workflow choices plus durable audit. No engineering execution imports."""
from datetime import datetime, timezone
from contextlib import closing
import hashlib
import json
import math
import os
from pathlib import Path
import sqlite3
import subprocess
import threading
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OPTIONS = ('analytical', 'tolerance', 'cad', 'cfd', 'fea', 'clarify', 'review')
MEANINGS = {
    'analytical': 'Start with a bounded first-principles calculation.',
    'tolerance': 'Review dimensional variation and assembly tolerances.',
    'cad': 'Review geometry or a proposed CAD change.',
    'cfd': 'Prepare a reviewed fluid/thermal simulation proposal, not a solver launch.',
    'fea': 'Prepare a reviewed structural simulation proposal, not a solver launch.',
    'clarify': 'Ask for essential missing inputs before choosing an analysis.',
    'review': 'Inspect evidence or request human review; this does not approve anything.',
}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)

def sha(value):
    return hashlib.sha256(value).hexdigest()

class RoutingLab:
    def __init__(self, root=HERE, runner=None):
        self.root = Path(root)
        self.runner = runner or self._infer
        self.busy = threading.Lock()

    def _infer(self, request):
        executable = ROOT/'.runtime/anyjev/Scripts/python.exe' if os.name == 'nt' else ROOT/'.runtime/anyjev/bin/python'
        if not executable.is_file():
            raise RuntimeError('local_runtime_unavailable')
        env = dict(os.environ)
        env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', PYTHONUTF8='1')
        result = subprocess.run([str(executable), '-m', 'Aero.private.routing_lab.worker'],
            input=json.dumps({'request':request}), encoding='utf-8', capture_output=True,
            cwd=str(ROOT.parent), env=env, timeout=180, check=False,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if result.returncode:
            raise RuntimeError('local_inference_failed')
        return json.loads(result.stdout)

    def _db(self):
        self.root.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(self.root/'decisions.sqlite3', timeout=10)
        db.execute('CREATE TABLE IF NOT EXISTS decisions (seq INTEGER PRIMARY KEY, record TEXT NOT NULL, sha256 TEXT NOT NULL)')
        return db

    def _record(self, row):
        with closing(self._db()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            previous = db.execute('SELECT sha256 FROM decisions ORDER BY seq DESC LIMIT 1').fetchone()
            row['previous_sha256'] = previous[0] if previous else None
            blob = canonical(row)
            digest = sha(blob.encode())
            db.execute('INSERT INTO decisions(record, sha256) VALUES (?,?)', (blob,digest))
        return dict(row, sha256=digest)

    def history(self):
        with closing(self._db()) as db, db:
            rows = db.execute('SELECT record,sha256 FROM decisions ORDER BY seq').fetchall()
        previous = None
        for blob, digest in rows:
            row = json.loads(blob)
            if sha(blob.encode()) != digest or row['previous_sha256'] != previous:
                raise RuntimeError('audit_integrity_failed')
            previous = digest
        return {'checked':len(rows), 'integrity':'PASS', 'records':[
            dict(json.loads(blob), sha256=digest) for blob,digest in rows[-20:]][::-1]}

    def decide(self, payload):
        if not isinstance(payload,dict) or set(payload) != {'request','confirm_generic_only'}:
            raise ValueError('Expected request and confirm_generic_only only')
        text = payload['request']
        if payload['confirm_generic_only'] is not True or not isinstance(text,str) or not 1 <= len(text.strip()) <= 1000:
            raise ValueError('Confirm generic-only data and provide 1–1000 characters')
        if not self.busy.acquire(blocking=False):
            raise BlockingIOError('A routing choice is already running')
        try:
            self.history()  # no new decisions over a broken audit chain
            contract = json.loads((HERE/'contract.json').read_text())
            row = {'id':uuid.uuid4().hex, 'timestamp':datetime.now(timezone.utc).isoformat(),
                'revision':'2.1-local', 'request':text.strip(), 'available_choices':list(OPTIONS),
                'model':contract['model'], 'model_revision':contract['model_revision'],
                'anyjev_commit':contract['anyjev_commit'], 'contract_sha256':sha((HERE/'contract.json').read_bytes()),
                'worker_sha256':sha((HERE/'worker.py').read_bytes()), 'question':contract['question'],
                'method':'L0; content-free prior; all cyclic option rotations', 'calibrated':False,
                'execution_authorized':False, 'engineering_disposition_changed':False,
                'authority':'workflow choice only; no automatic handoff', 'status':'SELECTED'}
            try:
                output = self.runner(row['request'])
                scores = output['distribution']
                if set(scores) != set(OPTIONS) or not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and 0<=v<=1 for v in scores.values()) or abs(sum(scores.values())-1)>1e-5:
                    raise ValueError('invalid_model_scores')
                ordered = sorted(scores, key=scores.get, reverse=True)
                choice = output['choice']
                if choice not in OPTIONS or scores[choice] != scores[ordered[0]] or output['level'] != 'L0':
                    raise ValueError('invalid_model_choice')
                row.update(selected_choice=choice, scores=scores, score_gap=scores[ordered[0]]-scores[ordered[1]],
                    seconds=output['seconds'], workflow_meaning=MEANINGS[choice],
                    selection_explanation=f"{choice} had the highest AnyJev L0 score ({scores[choice]:.4f}); next was {ordered[1]} ({scores[ordered[1]]:.4f}). These are uncalibrated ranking scores, not a probability of engineering correctness.",
                    explanation_type='Observable selection rule, not hidden model reasoning')
            except Exception as exc:
                row.update(status='NOT_ESTABLISHED',selected_choice=None,error_type=type(exc).__name__,
                    selection_explanation='No usable model decision. No substitute choice or action was made.')
            return self._record(row)
        finally:
            self.busy.release()

def install(app, profile_id, authorize):
    if profile_id != 'lab':
        return
    from flask import jsonify, request
    lab = RoutingLab()
    @app.route('/routing-lab/results', methods=['GET'])
    def routing_results():
        denied, status = authorize()
        if denied is not None:
            return denied,status
        path = HERE/'evidence/results.json'
        response = jsonify(json.loads(path.read_text()) if path.exists() else {'status':'NOT_RUN'})
        response.headers['Cache-Control']='no-store'
        return response
    @app.route('/routing-lab/decisions', methods=['GET','POST'])
    def routing_decisions():
        denied, status = authorize()
        if denied is not None:
            return denied,status
        origin = request.headers.get('Origin')
        if origin and origin not in {'https://your-aero-host.example','http://127.0.0.1:5213','http://localhost:5213'}:
            return jsonify(error='origin_not_allowed'),403
        try:
            if request.method=='POST':
                if not request.is_json or (request.content_length or 0)>8192:
                    return jsonify(error='bounded_json_required'),400
                result=lab.decide(request.get_json(silent=True))
            else:
                result=lab.history()
            response=jsonify(result)
            response.headers['Cache-Control']='no-store'
            return response
        except ValueError as exc:
            return jsonify(error=str(exc)),400
        except BlockingIOError:
            return jsonify(error='routing_busy'),409
        except Exception:
            return jsonify(error='routing_audit_unavailable'),503
