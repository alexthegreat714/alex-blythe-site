"""Fixed generic-only benchmark. Run in the isolated AnyJev environment."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import math
import os
import re
import time

HERE = Path(__file__).resolve().parent
OUT = HERE / 'evidence'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def heuristic(text):
    text = text.lower()
    rules = [('review', r'qualif|approve|review the retained'),
             ('clarify', r'not specified|not provided|no temperature'),
             ('tolerance', r'tolerance|clearance|assembly yield'),
             ('cad', r'cad|step geometry|geometry revision'),
             ('cfd', r'cfd|openfoam|conjugate heat'),
             ('fea', r'calculix|finite elements|buckling')]
    return next((label for label, pattern in rules if re.search(pattern, text)), 'analytical')

def summarize(rows, key, labels):
    confusion = {a: {b: 0 for b in labels} for a in labels}
    for row in rows:
        confusion[row['label']][row[key]['choice']] += 1
    probabilities = [row[key].get('distribution') for row in rows]
    out = {'count': len(rows), 'accuracy': sum(row[key]['choice'] == row['label'] for row in rows)/len(rows),
           'errors': [row['id'] for row in rows if row[key]['choice'] != row['label']], 'confusion': confusion}
    if all(probabilities):
        out['brier_multiclass'] = sum(sum((row[key]['distribution'][label] - int(label == row['label']))**2 for label in labels) for row in rows)/len(rows)
        ece = 0.0
        for i in range(5):
            bucket = [row for row in rows if min(4, int(max(row[key]['distribution'].values())*5)) == i]
            if bucket:
                confidence = sum(max(row[key]['distribution'].values()) for row in bucket)/len(bucket)
                accuracy = sum(row[key]['choice'] == row['label'] for row in bucket)/len(bucket)
                ece += len(bucket)/len(rows)*abs(confidence-accuracy)
        out['ece_5_equal_width_bins'] = ece
        out['order_flip_fraction'] = sum(row[key]['choice'] != row[key+'_reversed']['choice'] for row in rows)/len(rows)
        out['mean_seconds'] = sum(row[key]['seconds'] for row in rows)/len(rows)
    return out

def main():
    import torch
    from huggingface_hub import snapshot_download
    from anyjev import Decider, Question
    from anyjev.backends.hf import HFBackend
    contract = json.loads((HERE/'contract.json').read_text())
    examples = json.loads((HERE/'examples.json').read_text())
    OUT.mkdir(exist_ok=True)
    # Fail rather than overwrite an earlier run or change its frozen inputs.
    freeze = OUT/'input_manifest.json'
    inputs = {name: digest(HERE/name) for name in ['contract.json', 'examples.json', 'benchmark.py']}
    if freeze.exists():
        if json.loads(freeze.read_text()) != inputs:
            raise RuntimeError('frozen_inputs_changed')
    else:
        freeze.write_text(json.dumps(inputs, indent=2), encoding='utf-8')
    if (OUT/'results.json').exists():
        raise RuntimeError('results_already_exist')
    torch.set_num_threads(contract['threads'])
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    print('Frozen input hashes verified. Loading pinned model on CPU.', flush=True)
    local = snapshot_download(contract['model'], revision=contract['model_revision'],
        allow_patterns=['*.json','*.safetensors','*.txt','*.jinja'])
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    backend = HFBackend(local, device='cpu', dtype='float32', batch_size=7, trust_remote_code=False)
    labels = contract['options']
    forward = Question.choice(contract['question'], labels, name='engineering_route')
    reverse = Question.choice(contract['question'], labels[::-1], name='engineering_route_reversed')
    deciders = {'raw': Decider(backend, level='raw', prior='none', shared_prefix=False),
                'anyjev': Decider(backend, level='L0', prior='content_free', shared_prefix=False, adapt=False)}
    rows = []
    started = time.monotonic()
    for example in examples:
        if time.monotonic() - started > contract['timeout_seconds']:
            raise TimeoutError('benchmark_budget_exceeded')
        row = dict(example)
        row['heuristic'] = {'choice': heuristic(example['request'])}
        for key, decider in deciders.items():
            for suffix, question in [('', forward), ('_reversed', reverse)]:
                t0 = time.monotonic()
                result = decider.decide({'request': example['request']}, [question])[question.name]
                distribution = {str(k): float(v) for k,v in result.distribution.items()}
                if set(distribution) != set(labels) or not all(math.isfinite(v) and 0 <= v <= 1 for v in distribution.values()):
                    raise ValueError('invalid_distribution')
                row[key+suffix] = {'choice': result.argmax, 'distribution': distribution,
                    'level': result.level, 'calibrated': False, 'seconds': time.monotonic()-t0}
        rows.append(row)
        (OUT/'progress.json').write_text(json.dumps({'completed':len(rows),'total':len(examples)}), encoding='utf-8')
        print(f"Completed {row['id']}: {len(rows)}/{len(examples)}", flush=True)
    result = {'revision': '2.1-local', 'status': 'EXPERIMENT_COMPLETE_NOT_QUALIFIED',
        'mode': 'READ_ONLY', 'author': 'Alex Blythe', 'date': '2026-09-23',
        'contract': contract, 'input_hashes': inputs,
        'runtime': {k: importlib.metadata.version(k) for k in ['anyjev','torch','transformers','numpy']},
        'rows': rows, 'metrics': {key:summarize(rows,key,labels) for key in ['heuristic','raw','anyjev']},
        'decision': 'NO_PRODUCTION_PROMOTION',
        'limitations': ['Small developer-authored challenge set, not independent engineering validation.',
          'L0 scores are uncalibrated. No acceptance probability threshold is authorized.',
          'No comparison against the existing production router; raw logits are a same-model baseline.',
          'CPU 0.6B pilot is not a benchmark of Aero existing chat models.',
          'No private chats, employer data, RAG corpus or qualification evidence used.']}
    (OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result['metrics']),flush=True)

if __name__ == '__main__':
    main()
