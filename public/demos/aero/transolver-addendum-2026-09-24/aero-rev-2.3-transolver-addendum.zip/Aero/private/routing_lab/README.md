# Private Aero Routing Lab — Rev 2.1-local

Owner: Alex Blythe · Date: 2026-09-23

The previous private build is Rev 2.0-local. A pre-change four-file source
snapshot and hashes are retained in `Aero/revisions/private_2_0_before_anyjev_20260923`.
That is not a full application backup. Unrelated local changes were preserved.

## Authority and decision record

The user authorizes model-selected workflow choices with a log. The private page
offers a Routing Lab tab: submit a **generic/personal** request, explicitly consent
to local retention, and inspect the selected route. Normal chat routing is not
replaced. No automatic tool handoff, solver execution, approval, evidence-gate
override, or qualification disposition is granted by selecting a route.

Records include input, all allowed choices, complete ranking scores, selected
choice, runner-up gap, observable selection explanation, model/revision, AnyJev
commit, contract/worker hashes, timestamps, and record/previous-record hashes.
This is a faithful explanation of the selection rule, not a claim to expose
hidden chain-of-thought or to independently verify the model's understanding.
There is no fabricated model rationale. Inference failures are recorded with no
fallback decision. Audit failure prevents a new choice. No choice is returned
successfully unless persistence succeeds.

The local SQLite log is append-only through this API. Hash-chain verification
detects edits relative to the stored chain; it cannot prevent a privileged
administrator rewriting the whole database. Requests may be sensitive: use only
generic/personal content. The consent box is not DLP. No employer data belongs here.
There is no delete/export-current-state endpoint or outward sync.

## Runtime

AnyJev is separately installed in `Aero/.runtime/anyjev`, pinned to the commit in
`contract.json`. The environment reuses host Python libraries; exact executed
versions are recorded in the benchmark results. Qwen3-0.6B weights/tokenizer are
revision-pinned, cached locally and loaded with `trust_remote_code=False`.
Interactive inference is offline, CPU-only, four threads, one choice at a time,
180-second subprocess timeout, 1,000-character request limit. Heavy dependencies
are never imported by the Aero web server or public/portable profiles.

Scores are **L0 and uncalibrated**. No score threshold is promoted. All choices
remain workflow recommendations, not a probability that a design is correct.
There is no paid model API, private RAG, training, or continuous self-adaptation.

## Fixed pilot

Run from Engineering with the isolated Python:

`Aero/.runtime/anyjev/Scripts/python.exe -m Aero.private.routing_lab.benchmark`

Inputs are hashed before model loading. One fixed set of 21 developer-authored
generic requests is evaluated under a fixed keyword baseline, same-model raw
logits and AnyJev L0. Forward/reversed option ordering is tested. Outputs retain
every decision, errors/confusion, Brier/ECE diagnostics and latency. This small
set is not independently reviewed, and raw logits do not represent the existing
production router. Do not promote based on this pilot. No examples or parameters
are retuned after outcomes.

## Deployment and checks

Private URL: `https://your-aero-host.example/aero/` → Routing Lab.
APIs `/routing-lab/results` and `/routing-lab/decisions` require the existing
local token; an `X-Auth-User` header alone is not enough. Existing Caddy login
continues to protect the page. Blue/public apps register no Routing Lab routes.
No authentication configuration was changed.

Run `python -m pytest Aero/tests/test_private_routing_lab.py`.
Any production routing promotion needs an independent held-out comparison with
the existing router, reviewed labels, calibration and a separate approval.
