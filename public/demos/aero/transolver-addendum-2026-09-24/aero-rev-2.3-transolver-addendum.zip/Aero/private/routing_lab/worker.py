"""One local, offline inference. Invoked with a fixed executable, never a shell."""
import json
import os
import sys
import time
from pathlib import Path

def main():
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_PROGRESS_BARS'] = '1'
    import torch
    from huggingface_hub import snapshot_download
    from anyjev import Decider, Question
    from anyjev.backends.hf import HFBackend
    from importlib.metadata import distribution
    contract = json.loads(Path(__file__).with_name('contract.json').read_text())
    identity = json.loads(distribution('anyjev').read_text('direct_url.json'))
    if identity.get('vcs_info', {}).get('commit_id') != contract['anyjev_commit']:
        raise RuntimeError('anyjev_identity_mismatch')
    payload = json.load(sys.stdin)
    text = payload.get('request')
    if not isinstance(text, str) or not 1 <= len(text.strip()) <= 1000:
        raise ValueError('invalid_request')
    torch.set_num_threads(contract['threads'])
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    path = snapshot_download(contract['model'], revision=contract['model_revision'], local_files_only=True)
    started = time.monotonic()
    backend = HFBackend(path, device='cpu', dtype='float32', batch_size=7, trust_remote_code=False)
    decider = Decider(backend, level='L0', prior='content_free', shared_prefix=False, adapt=False)
    question = Question.choice(contract['question'], contract['options'], name='engineering_route')
    result = decider.decide({'request': text}, [question])['engineering_route']
    print(json.dumps({'choice': result.argmax, 'distribution': result.distribution,
        'level': result.level, 'seconds': time.monotonic()-started}))

if __name__ == '__main__':
    main()
