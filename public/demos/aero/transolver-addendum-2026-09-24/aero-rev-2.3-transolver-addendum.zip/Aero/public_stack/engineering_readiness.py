"""Deterministic engineering-readiness review for Aero OpenFOAM cases.

The contract in this module is deliberately conservative.  It does not turn a
tutorial seed into a flight/design model.  It makes the missing evidence
machine-readable and supplies independent first-principles screens that never
reuse solver output as a reference value.
"""
from __future__ import annotations

import math
from typing import Any, Mapping

from Aero.core.measurement_contract import measurement_audit, reference_audit


TEMPLATE_FIDELITY_LADDERS: dict[str, list[dict[str, str]]] = {
    "compressible_nozzle": [
        {"level": "L0", "model": "perfect-gas steady precursor", "status": "available"},
        {"level": "L1", "model": "choked quasi-1D nozzle with stagnation conditions", "status": "review_required"},
        {"level": "L2", "model": "viscous compressible RANS with wall treatment", "status": "review_required"},
        {"level": "L3", "model": "real-gas/reacting multispecies nozzle", "status": "specialist_validation_required"},
    ],
    "incompressible_internal": [
        {"level": "L0", "model": "constant-property single-phase surrogate", "status": "available"},
        {"level": "L1", "model": "Darcy-Weisbach/minor-loss correlation comparison", "status": "inputs_required"},
        {"level": "L2", "model": "temperature-dependent real-fluid RANS", "status": "review_required"},
        {"level": "L3", "model": "cavitation/flashing/two-phase transient", "status": "specialist_validation_required"},
    ],
    "external_aerodynamics": [
        {"level": "L0", "model": "incompressible public regression geometry", "status": "available"},
        {"level": "L1", "model": "compressibility-corrected coefficient study", "status": "inputs_required"},
        {"level": "L2", "model": "compressible RANS with transition/wall review", "status": "review_required"},
        {"level": "L3", "model": "unsteady separated-flow/aeroheating validation", "status": "specialist_validation_required"},
    ],
    "rotating_turbomachinery": [
        {"level": "L0", "model": "steady SRF public mixer precursor", "status": "available"},
        {"level": "L1", "model": "Euler head/coefficient and map comparison", "status": "inputs_required"},
        {"level": "L2", "model": "blade-resolved MRF/mixing-plane RANS", "status": "review_required"},
        {"level": "L3", "model": "sliding-mesh cavitating real-fluid transient", "status": "specialist_validation_required"},
    ],
    "conjugate_heat_transfer": [
        {"level": "L0", "model": "generic coupled fluid-solid regression", "status": "available"},
        {"level": "L1", "model": "Nusselt/thermal-resistance correlation comparison", "status": "inputs_required"},
        {"level": "L2", "model": "temperature-dependent conjugate cooling channel", "status": "review_required"},
        {"level": "L3", "model": "real-fluid reacting-wall conjugate model", "status": "specialist_validation_required"},
    ],
}

CORRELATION_PLANS: dict[str, list[dict[str, Any]]] = {
    "compressible_nozzle": [
        {"quantity": "choked_mass_flow", "method": "isentropic critical-flow relation", "required_inputs": ["p0", "T0", "gamma", "R", "throat_area"]},
        {"quantity": "exit_mach_and_pressure_ratio", "method": "quasi-1D area-Mach relation", "required_inputs": ["area_ratio", "p0", "T0", "gamma"]},
    ],
    "incompressible_internal": [
        {"quantity": "pressure_loss", "method": "Darcy-Weisbach plus declared minor-loss coefficients", "required_inputs": ["length", "hydraulic_diameter", "roughness", "rho", "mu", "velocity"]},
    ],
    "external_aerodynamics": [
        {"quantity": "lift_and_drag_coefficients", "method": "published geometry polar at matched Re/Mach/AoA", "required_inputs": ["geometry_id", "Re", "Mach", "angle_of_attack", "reference_area"]},
    ],
    "rotating_turbomachinery": [
        {"quantity": "head_or_pressure_rise", "method": "Euler turbomachinery equation and nondimensional map coefficients", "required_inputs": ["radii", "blade_angles", "rpm", "flow_rate", "rho"]},
    ],
    "conjugate_heat_transfer": [
        {"quantity": "heat_transfer_and_wall_temperature", "method": "Gnielinski/Dittus-Boelter plus series thermal resistance", "required_inputs": ["Re", "Pr", "k_fluid", "hydraulic_diameter", "solid_thickness", "k_solid", "heat_flux"]},
    ],
}


def _finite(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def _calculation(name: str, value: Any, units: str, equation: str, assumptions: list[str]) -> dict[str, Any]:
    return {
        "name": name,
        "status": "evaluated" if _finite(value) else "inputs_required",
        "value": float(value) if _finite(value) else None,
        "units": units,
        "equation": equation,
        "source": "independent_first_principles",
        "assumptions": assumptions,
    }


def first_principles_screen(spec: Mapping[str, Any]) -> dict[str, Any]:
    """Return independent regime/correlation quantities from declared inputs."""
    template = str(spec.get("template") or "")
    physics = spec.get("physics") if isinstance(spec.get("physics"), Mapping) else {}
    boundaries = spec.get("boundaries") if isinstance(spec.get("boundaries"), Mapping) else {}
    rows: list[dict[str, Any]] = []
    missing: list[str] = []

    if template == "compressible_nozzle":
        inlet = boundaries.get("inlet") if isinstance(boundaries.get("inlet"), Mapping) else {}
        gamma = float(physics.get("gamma") or 1.4)
        gas_constant = float(physics.get("gas_constant_j_kg_k") or 287.0)
        temperature = inlet.get("temperature_k")
        if _finite(temperature):
            sound_speed = math.sqrt(gamma * gas_constant * float(temperature))
            rows.append(_calculation("reference_speed_of_sound", sound_speed, "m/s", "sqrt(gamma R T)", ["calorically perfect gas"]))
        else:
            missing.append("boundaries.inlet.temperature_k")
        critical_ratio = (2.0 / (gamma + 1.0)) ** (gamma / (gamma - 1.0))
        rows.append(_calculation("critical_static_to_stagnation_pressure_ratio", critical_ratio, "", "(2/(gamma+1))^(gamma/(gamma-1))", ["isentropic", "calorically perfect gas"]))
        missing.extend(["upstream stagnation pressure", "throat area"])
    elif template == "incompressible_internal":
        inlet = boundaries.get("inlet") if isinstance(boundaries.get("inlet"), Mapping) else {}
        velocity = inlet.get("case_value_m_s")
        nu = physics.get("kinematic_viscosity_m2_s")
        diameter = physics.get("hydraulic_diameter_m")
        if all(_finite(v) and float(v) > 0 for v in (velocity, nu, diameter)):
            re = float(velocity) * float(diameter) / float(nu)
            rows.append(_calculation("hydraulic_reynolds_number", re, "", "V Dh / nu", ["single phase", "declared constant properties"]))
            friction = 64.0 / re if re < 2300 else 0.3164 / re ** 0.25
            rows.append(_calculation("screening_darcy_friction_factor", friction, "", "64/Re or Blasius 0.3164 Re^-0.25", ["fully developed smooth duct", "screening only"]))
            missing.extend(["physics.flow_length_m", "physics.roughness_m", "boundaries.minor_loss_coefficients"])
        else:
            missing.append("physics.hydraulic_diameter_m")
    elif template == "external_aerodynamics":
        farfield = boundaries.get("farfield") if isinstance(boundaries.get("farfield"), Mapping) else {}
        vector = farfield.get("case_velocity_m_s")
        speed = math.sqrt(sum(float(v) ** 2 for v in vector)) if isinstance(vector, list) and vector and all(_finite(v) for v in vector) else None
        rho = physics.get("density_kg_m3")
        if _finite(speed) and _finite(rho):
            rows.append(_calculation("freestream_dynamic_pressure", 0.5 * float(rho) * float(speed) ** 2, "Pa", "0.5 rho V^2", ["constant density"]))
        else:
            missing.extend(["freestream velocity", "density"])
        missing.append("dynamic viscosity for Reynolds-number screen")
    elif template == "rotating_turbomachinery":
        rpm = physics.get("rotational_speed_rpm")
        if _finite(rpm):
            rows.append(_calculation("shaft_angular_speed", float(rpm) * 2.0 * math.pi / 60.0, "rad/s", "2 pi RPM / 60", ["constant shaft speed"]))
        missing.extend(["impeller radius for tip speed", "flow rate and blade geometry for Euler head"])
    elif template == "conjugate_heat_transfer":
        missing.extend(["hydraulic diameter", "conductivity", "viscosity", "heat capacity", "solid thickness", "solid conductivity"])

    return {
        "schema": "aero_first_principles_screen_v1",
        "template": template,
        "calculations": rows,
        "missing_inputs": list(dict.fromkeys(missing)),
        "correlation_status": "complete" if rows and not missing else ("partial" if rows else "inputs_required"),
        "trust_boundary": "Independent screening only; solver fields are never used as validation truth.",
    }


def audit_boundary_and_turbulence(spec: Mapping[str, Any], metrics: Mapping[str, Any] | None = None) -> dict[str, Any]:
    physics = spec.get("physics") if isinstance(spec.get("physics"), Mapping) else {}
    boundaries = spec.get("boundaries") if isinstance(spec.get("boundaries"), Mapping) else {}
    required = boundaries.get("required_patches") if isinstance(boundaries.get("required_patches"), list) else []
    model = str(physics.get("turbulence_model") or "").strip()
    turbulent = bool(model and model.lower() not in {"laminar", "none"})
    wall_treatment = physics.get("wall_treatment")
    yplus = physics.get("target_y_plus")
    checks = [
        {"name": "required_patches_declared", "passed": bool(required), "evidence": required},
        {"name": "inlet_declared", "passed": "inlet" in boundaries or "farfield" in boundaries, "evidence": boundaries.get("inlet") or boundaries.get("farfield")},
        {"name": "outlet_declared", "passed": "outlet" in boundaries or "farfield" in boundaries, "evidence": boundaries.get("outlet") or boundaries.get("farfield")},
        {"name": "turbulence_model_declared", "passed": bool(model), "evidence": model or "missing"},
        {"name": "wall_treatment_declared", "passed": (not turbulent) or bool(wall_treatment), "evidence": wall_treatment or ("not_required_for_laminar" if not turbulent else "missing")},
        {"name": "target_y_plus_declared", "passed": (not turbulent) or (_finite(yplus) and float(yplus) > 0), "evidence": yplus if _finite(yplus) else "missing"},
    ]
    if turbulent and metrics:
        monitors = metrics.get("monitors") if isinstance(metrics.get("monitors"), Mapping) else {}
        samples = monitors.get("wall_y_plus") or monitors.get("y_plus") or []
        measured = [float(value) for value in samples if _finite(value)] if isinstance(samples, list) else []
        checks.append({"name": "sampled_y_plus_available", "passed": bool(measured), "evidence": measured[-20:]})
    failures = [row["name"] for row in checks if not row["passed"]]
    recommendation = "laminar model: y+ is not applicable"
    if turbulent and not _finite(yplus):
        recommendation = "declare wall-resolved target near 1 or a reviewed wall-function target before meshing"
    elif turbulent:
        recommendation = f"verify sampled wall y+ against declared target {float(yplus):g} after solving"
    return {
        "schema": "aero_boundary_turbulence_audit_v1",
        "status": "pass" if not failures else "review_required",
        "checks": checks,
        "blocking_items": failures,
        "wall_resolution_plan": recommendation,
    }


def audit_imported_cad(cad: Mapping[str, Any] | None) -> dict[str, Any]:
    cad = cad if isinstance(cad, Mapping) else {}
    imported = str(cad.get("provenance") or "").upper() in {"IMPORTED", "USER_PROVIDED"}
    if not imported:
        return {"schema": "aero_imported_cad_audit_v1", "status": "not_applicable", "checks": [], "blocking_items": []}
    required = {
        "source_hash": bool(cad.get("source_sha256")),
        "units_declared": bool(cad.get("units")),
        "watertight": cad.get("watertight") is True,
        "manifold": cad.get("manifold") is True,
        "positive_volume": _finite(cad.get("volume_m3")) and float(cad.get("volume_m3")) > 0,
        "named_boundaries": isinstance(cad.get("named_boundaries"), list) and bool(cad.get("named_boundaries")),
        "repair_ledger": isinstance(cad.get("repairs"), list),
    }
    failed = [name for name, passed in required.items() if not passed]
    return {
        "schema": "aero_imported_cad_audit_v1",
        "status": "pass" if not failed else "blocked",
        "checks": [{"name": name, "passed": passed} for name, passed in required.items()],
        "blocking_items": failed,
        "repair_policy": "Repairs require a retained before/after hash, tolerance, operation, and reviewer disposition.",
    }


def build_readiness_contract(spec: Mapping[str, Any], metrics: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Build the eight-part first-cut contract used by API, UI, and reports."""
    validation = spec.get("validation") if isinstance(spec.get("validation"), Mapping) else {}
    first = first_principles_screen(spec)
    bc = audit_boundary_and_turbulence(spec, metrics)
    cad = audit_imported_cad(spec.get("geometry") if isinstance(spec.get("geometry"), Mapping) else None)
    mesh_evidence = validation.get("mesh_independence_evidence") if isinstance(validation.get("mesh_independence_evidence"), Mapping) else {}
    reference = str(validation.get("validation_reference") or "").strip()
    reference_review = reference_audit(spec)
    measurements = measurement_audit(spec)
    comparison = validation.get("reference_comparison") if isinstance(validation.get("reference_comparison"), Mapping) else {}
    uncertainty = validation.get("uncertainty") if isinstance(validation.get("uncertainty"), Mapping) else {}
    required_uncertainty = {"input", "numerical", "model_form", "validation_reference"}
    present_uncertainty = {str(key) for key, value in uncertainty.items() if value not in (None, "", [])}
    uncertainty_missing = sorted(required_uncertainty - present_uncertainty)
    template = str(spec.get("template") or "")
    items = [
        {"id": "linux_openfoam_execution", "status": "evaluated_after_run", "required": True},
        {"id": "three_level_mesh_study", "status": "pass" if mesh_evidence.get("passed") and len(mesh_evidence.get("samples") or []) >= 3 else "required", "required": True},
        {
            "id": "independent_reference",
            "status": "pass" if reference_review["comparison_passed"] else (
                reference_review["status"] if reference else "required"),
            "required": True,
            "evidence": {"reference": reference, "comparison": comparison, "provenance": reference_review},
        },
        {"id": "first_principles_screen", "status": "pass" if first["correlation_status"] == "complete" else first["correlation_status"], "required": True, "evidence": first},
        {"id": "fidelity_ladder", "status": "review_required" if not validation.get("design_model_ready") else "pass", "required": True, "evidence": TEMPLATE_FIDELITY_LADDERS.get(template, [])},
        {"id": "boundary_turbulence_wall_review", "status": bc["status"], "required": True, "evidence": bc},
        {"id": "imported_cad_quality", "status": cad["status"], "required": True, "evidence": cad},
        {"id": "uncertainty_margin_risk_report", "status": "required" if uncertainty_missing else "pass", "required": True, "evidence": {"missing": uncertainty_missing}},
    ]
    design_ready = (not measurements["errors"] and all(
        row["status"] in {"pass", "declared", "not_applicable"} for row in items))
    return {
        "schema": "aero_engineering_readiness_v1",
        "template": template,
        "assessment": "design_ready" if design_ready else "preliminary_first_cut_only",
        "design_ready": design_ready,
        "items": items,
        "fidelity_ladder": TEMPLATE_FIDELITY_LADDERS.get(template, []),
        "correlation_plan": CORRELATION_PLANS.get(template, []),
        "first_principles": first,
        "boundary_turbulence_audit": bc,
        "cad_import_audit": cad,
        "requirements": spec.get("objectives") or [],
        "measurement_audit": measurements,
        "reference_audit": reference_review,
        "margins": validation.get("margins") or {},
        "uncertainty": uncertainty,
        "unresolved_risks": list(dict.fromkeys(
            list(first.get("missing_inputs") or [])
            + list(bc.get("blocking_items") or [])
            + list(cad.get("blocking_items") or [])
            + uncertainty_missing
            + list(measurements["errors"])
        )),
        "trust_boundary": "Aero supports first-cut engineering decisions; flight/design release requires reviewed requirements, validated fidelity, uncertainty, and domain authority.",
    }
