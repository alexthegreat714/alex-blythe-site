# Engineering Validity Gate — implementation plan

Alex Blythe · 2026-09-23 · Private Rev 2.2-local

## Repository discovery

| Concern | Existing component | Extension decision |
|---|---|---|
| CFD orchestration, queues, controls, retention | `openfoam_pipeline.py` | Reuse worker/run IDs, immutable case input and result manifests. Add managed-campaign admission/control guards. |
| CFD numerical/readiness gates | `cfd/evidence.py`, `public_stack/engineering_readiness.py` | Preserve existing verdicts; evaluate independent axes from deterministic evidence, never a solver's desired verdict. |
| FEA execution, hashes, approval | `fea/bounded/controller.py`, `routes.py`, `integration.py` | Delegate bounded execution, verified manifests and exact-case approval; no new solver. |
| Existing proposal/freeze/launch | `core/engineering_guidance_harness.py` | Reuse exact-fingerprint approval semantics; share its human credential policy, not a new credential or approval service. |
| Persistent state | OpenFOAM atomic JSON, bounded FEA `WorkerLease` | Reuse atomic writer and fail-closed cross-process lease for new campaign records. |
| Analytical calculations | `engineering_toolkit/kernel.py` | Reuse channel loss/Re, nozzle, pressure-vessel and sensible-heat calculations with their limitations. |
| CHT accounting | `cfd/two_fluid_cht.py` | Consume existing retained accounting outputs when available; preserve explicit sign/storage definitions. No duplicate native-field reconstruction. |
| Field custody | `tools/hx_retention_contract.py`, run manifests | Require hashed files and complete checkpoint data; missing evidence cannot pass. |
| Test correlation | `core/measurement_contract.py`, pipeline Fluent comparison | Preserve measurement semantics. New generic correlation check requires matched configuration/coordinates/units and declared uncertainty. |
| HX qualification | Frozen V2.1 Core, CHT Profile V1.1 and case contracts in reports | Reference only. No threshold edits, historical rescoring or HX execution. |
| Overnight/batch | `autorun_supervisor.py`, `tools/overnight_study_tool.py` | These are UI-proof/research jobs, not a simulation campaign queue. Do not turn their LLM grades into engineering evidence. A bounded campaign tick delegates to existing solver queues. |
| Decision log | `agentic/decision_ledger.py`, private Routing Lab | Chat/routing logs are not campaign authority. Keep them separate; persist full engineering evidence references in campaign history. |

## New components genuinely required

1. Validated Engineering Contract and pre-run baseline, immutable versions/hashes.
2. Evidence-only evaluator with numerical and physical axes plus alignment,
   model form, provenance, uncertainty, drift and experimental-correlation domains.
3. Persistent campaign controller: hypotheses, evidence-linked mutations,
   cumulative drift comparison, run/cost bounds and crash-uncertain dispatch stop.
4. Adapters to the existing OpenFOAM and bounded FEA controllers and a private
   authenticated control panel/API. No new CFD/FEA implementation or new model.

## Data flow and safety boundary

Frozen contract + independent baseline → existing solver queue → retained,
hash-verified evidence → deterministic validity gate → persisted competing
hypotheses → ranked discriminating proposal → mutation authority + original
contract comparison → existing approval boundary → next bounded run.

Only campaigns explicitly frozen and authorized by a human may execute through
this controller. Class C physical changes require a reviewed contract revision;
LOCKED fields cannot change within a campaign. Unknown fields default to locked.
No production simulation is launched to test this release. Synthetic tests and
stub workers verify sequencing, negative controls, custody and authorization.

Model-form adequacy, applicability of analytical approximations and engineering
uncertainty still require independent human evidence. Unsupported checks return
NOT_ESTABLISHED; no empty checklist can produce PASS. Historical reports and
their frozen gates remain untouched. Legacy manual entry points are not silently
reclassified as governed campaigns.
