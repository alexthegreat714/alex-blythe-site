# Physics-AI witnesses — Rev 2.3 implementation plan

**Release update — September 24, 2026:** the discovery below is historical.
The bounded DoMINO reference adapter has now executed with retained discrepancies.
See `PHYSICS_AI_REV_2_3_IMPLEMENTATION.md` for current implementation and limitations.
The later approved download/runtime lives on D:, separate from the main runtime.
This note does not retroactively change the original discovery/approval record.

Alex Blythe · September 23, 2026

Historical plan status: **DISCOVERY_COMPLETE_FOR_INITIAL_PLAN**.
September 24 update: personal DoMINO license use was already approved in the
retained upstream-discovery receipt. Large downloads were not approved.
Rev 2.3-dev.1 implementation has begun; see `PHYSICS_AI_REV_2_3_IMPLEMENTATION.md`
for implemented boundaries and tests. The historical discovery text below is
retained, not a claim that pretrained inference is operational.
This is a proposed revision, not a released capability. Private Rev 2.2 remains
current. No checkpoint downloaded, model package installed, pretrained inference
performed, solver run launched, or qualification disposition changed by this study.

## Discovery and reuse

| Requested area | Existing implementation / disposition |
|---|---|
| Engineering Contract and frozen baseline | `engineering_validity/contracts.py`; extend with optional witness policy, not new contract authority |
| Independent gate and provenance | `engineering_validity/gate.py`, `cfd/evidence.py`; preserve numerical/physical axes and mandatory checks |
| Hypotheses, state, mutation and overnight control | `engineering_validity/controller.py`; attach evidence-linked witness observations to existing history; no second campaign queue |
| CFD/FEA adapters | `engineering_validity/adapters.py`; conventional solver paths remain unchanged |
| OpenFOAM | `openfoam_pipeline.py`; preserve run IDs, immutable input/result manifests, preflight, numerical gates and mesh qualification |
| CalculiX | `fea/bounded/controller.py`; preserve worker isolation, verified artifacts and exact-case approval |
| ANSYS | Existing Fluent/OpenFOAM comparison and `fluent_ui_workflow.py`, engineering tooling/WVM hooks; no generic autonomous ANSYS physics-AI warm-start adapter established |
| Analytical calculations | `engineering_toolkit/kernel.py`, registered through `engineering_toolkit/registry.py`; remain independent sources |
| Model registry | `config/AERO_MODEL_CAPABILITY_MANIFEST.example.json` describes language-model routing, not physical training domains or checkpoint applicability; needs a separate typed physics-model catalog, not a replacement LLM router |
| Extension/adaptor discovery | `config/extension_points.json`, `docs/EXTENSION_POINTS.md`, `tool_registry.py`; register new optional capability here |
| Approval | `core/approval_policy.py`; reuse existing human credential and frozen-contract authority |
| Artifact hashing | Existing digest/atomic JSON/manifest patterns; add witness artifact manifests and exact input/checkpoint/code identities |
| Configuration | `config/deployment_profiles.json`; private lab only, optional defaults disabled, preserve public/portable surfaces |
| Dataset work | Existing qualification evidence and specialist/Step-9 dataset tooling; these are not a qualified physical-field training corpus. Add schema only; no automatic training or employer-data ingestion |
| Isolated inference precedent | `private/routing_lab/service.py` launches a bounded subprocess in `.runtime/anyjev`; reuse the isolation pattern, not that environment or its text model |
| Runtime | Host Windows Python; existing Docker containers responded to read-only inventory. No VM actions/restarts performed |
| GPU | `nvidia-smi` was not found on the current command PATH. This does not establish absence of a GPU. Actual target GPU/VRAM/driver/package compatibility remains NOT_ESTABLISHED |
| Benchmark tests | Existing `tests/test_engineering_validity.py` and worker/evidence regression suites; extend with surrogate counterexamples, not replacements for solver qualification |

## Proposed architecture

1. **Reuse:** contract IDs/hashes, baseline, controller state, hypotheses, mutation
   policy, approval, conventional workers, numerical gates and analytical utilities.
2. **Extend:** gate output with a separately typed supporting-witness assessment;
   controller history with surrogate-informed hypothesis updates and recorded
   reasons for deferring unnecessary optional experiments. A surrogate cannot
   remove a required qualification run or resolve a mandatory missing field.
3. **New:** physics-model registry/schema, applicability evaluator, isolated
   adapter protocol, checkpoint cache verifier, standardized prediction record,
   multi-source comparison, benchmark records, screening interface and future
   qualified-physics-dataset schema.
4. **Integration:** registry → applicability/capability → optional worker → immutable
   PHYSICS_AI_RESULT → evidence set → gate supporting analysis → existing hypotheses
   and approved next action. No consensus average or majority vote.
5. **Dependencies:** prefer one pinned PhysicsNeMo worker environment for compatible
   architectures. Keep Torch/CUDA/PhysicsNeMo out of the main Flask process. Exact
   package/container selection follows checkpoint/preprocessing and hardware checks;
   do not install every example or mutate the existing AnyJev environment.
6. **Optionality:** lazy worker boundary; dependency/checkpoint/GPU failures return
   structured statuses and leave the conventional workflow available. No automatic
   downloads, remote transmission, training, geometry optimization or warm starts.
7. **Gate entry:** neural fields stay explicitly PHYSICS_AI_RESULT and cannot enter
   OBSERVED experimental records or substitute for conventional gate values.
   Unknown/OOD results are RESEARCH_ONLY and cannot influence engineering disposition.

## Registry / applicability design

Each entry must identify model/version/adapter, upstream repository+commit when
verified, checkpoint/hash, model and code licenses, framework/runtime, hardware,
equations/representations, inputs/outputs, training dataset and envelope,
limitations, provenance, allowed/prohibited actions, benchmark and validation state.

Availability, applicability and domain validation are independent states. Missing
training ranges remain UNKNOWN. Applicability compares geometry, topology,
dimensionality, regime, material/fluid, BC family, quantities, scale and resolution
where documented; it does not extrapolate from the word “CFD.”

Independence records training-data origin and shared assumptions. Solver-generated
training data cannot be promoted to an independent experimental witness.
Uncertainty remains NOT_ESTABLISHED unless a supported method actually produces it.

## Upstream investigation — primary sources

- [PhysicsNeMo](https://github.com/NVIDIA/physicsnemo) is a PyTorch framework and
  includes DoMINO and Transolver families. Architecture support alone does not
  establish checkpoint compatibility or inference readiness. The release listing
  identifies v2.2.0; no local installation has been performed.
- [PhysicsNeMo DoMINO workflow](https://github.com/NVIDIA/physicsnemo-cfd/blob/main/workflows/domino_design_sensitivities/README.md)
  documents a Linux/CUDA-oriented surface-inference workflow using a model archive,
  scaling factors, training configuration and an automotive STL. Its normalization
  and mesh/field correspondence must be retained, not improvised.
- [DoMINO model card](https://huggingface.co/nvidia/domino_drivaerml)
  identifies automotive external-aerodynamics training on synthetic DrivAerML CFD
  and the NVIDIA Open Model Agreement. This is not a heat-exchanger checkpoint.
  Download size, exact selected checkpoint hash, source commit and local execution
  compatibility are not yet established. The metadata listing could not be read
  through the web tool; this is not evidence of an authentication requirement.
- [Transolver++](https://github.com/thuml/Transolver_plus) links pretrained standard
  benchmark checkpoints in a Google Drive folder. [Original Transolver](https://github.com/thuml/Transolver)
  is MIT-licensed code. That does not automatically establish the license, complete
  preprocessing, or PhysicsNeMo compatibility of every separately hosted checkpoint.
  No checkpoint was loaded or converted.
- [PDEBench](https://github.com/pdebench/PDEBench) provides benchmark code, data and
  pretrained-model links. Treat as an evaluation resource, not a production solver.
- [RealPDEBench](https://github.com/AI4Science-WestlakeU/RealPDEBench) provides paired
  measured/simulated scenarios and benchmark tooling. Metadata-only discovery is
  available; full dataset download/evaluation has not been performed.
- [PFEM](https://github.com/yizheng-wang/PFEM) describes neural predictions followed
  by conventional FEM warm starts for 2-D elasticity/hyperelasticity. A future
  Aero adapter would need explicit node/DOF mapping, units/material/BC correspondence,
  solver-supported initialization, residual/iteration comparisons and independent
  final qualification. CalculiX-compatible initialization and licensing are not
  established; no production dependency is proposed now.

## Required tests and demonstration

Implement the twelve requested counterexamples, including source agreement that
does not waive solver gates, shared solver lineage, OOD/unknown domains, bad
conservation despite low field error, absent dependencies, reproducible artifact
identity and avoiding an optional expensive test without waiving required evidence.
Use synthetic test doubles only for software tests and label them accordingly.

The release needs at least one real, approved pretrained reference inference with
documented preprocessing, reference comparison, applicability, custody and gate
ingestion. A randomly initialized architecture or synthetic mock is not that demo.
No pretrained demo has been run yet.

## Human-action stop

The concrete initial DoMINO checkpoint is governed by the
[NVIDIA Open Model Agreement](https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-open-model-agreement/).
It states that use/reproduction constitutes acceptance. The user explicitly
instructed this task to stop when model-license acceptance is required.

**Historical requested action (now satisfied for personal use):** Alex was asked whether to authorize use of this model
under that agreement for personal Aero. This does not authorize use on behalf of
an employer. Then verify the exact download footprint and runtime before fetching
weights; obtain separate approval if a large download is needed.

Rev 2.3 foundation implementation has begun. Model installation and pretrained inference remain pending.
No adapter is claimed operational. No license was accepted on Alex's behalf.
Historical HX evidence, HX-03 and HX-04 remain unchanged.
