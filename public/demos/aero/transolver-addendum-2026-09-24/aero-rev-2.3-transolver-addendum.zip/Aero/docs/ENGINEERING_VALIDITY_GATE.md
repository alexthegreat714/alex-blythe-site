# Aero Engineering Validity Gate — private Rev 2.2

Alex Blythe · September 23, 2026 · `ENGINEERING_VALIDITY_GATE.v1`

## Result and scope

Rev 2.2 adds an evidence-only engineering assessment and a persistent, bounded
campaign controller. It extends the existing OpenFOAM and bounded CalculiX
workers; it does not implement another solver or replace Aero qualification.
Numerical PASS does not imply physical PASS. Missing evidence stays
NOT_ESTABLISHED. A discrepancy from an approximate analytical model triggers an
investigation rather than an instruction to force the simulation toward it.

This release does **not** execute CFD/FEA, requalify a capability, change any
historical result, or unblock HX-03/HX-04. It is software-control verification,
not an engineering validation campaign. The private website provides the new
Engineering Control tab, schemas, campaign audit records and this report.

Release verification: **189 tests passed**, including 38 dedicated control-layer
tests; private runtime smoke checks passed. The live human-approval credential is
currently unconfigured, so campaign freeze/execution remains blocked. The final
artifact counts and hashes are in `private/engineering_validity_release_20260923/VERIFICATION.json`.

## Architecture and reused components

Frozen Engineering Contract + pre-run baseline → existing worker → verified
evidence → independent validity gate → competing hypotheses → one proposed
experiment → mutation policy and original-contract check → approved next run.

| Responsibility | Existing component reused | Rev 2.2 extension |
|---|---|---|
| CFD queue/preflight/execution | `openfoam_pipeline.py` | Managed-campaign admission and live-retuning guards; worker/run manifests retained |
| FEA mesh/solve/approval | `fea/bounded/controller.py` | Thin adapter; existing exact-case fingerprint approval remains mandatory |
| Numerical evidence semantics | `cfd/evidence.py`, existing worker gates | Required failures remain blocking; separate physical assessment |
| Atomic persistence/lease | OpenFOAM `_atomic_json`, FEA `WorkerLease` | Versioned campaign files and hash-linked event history |
| Human authorization | Guidance and bounded FEA approval credentials | Shared `core/approval_policy.py`; no new approval service or secret |
| First-principles calculations | `engineering_toolkit/kernel.py` | Freeze input/output, envelope, applicability and calculation-source hash |
| Existing CHT accounting/retention | Existing profile outputs and manifest custody | Consume retained evidence; never infer missing native energy fields |
| Private UI | Existing Flask/Jinja lab surface | Engineering Control tab and authenticated `/engineering-validity` API |

`autorun_supervisor.py` and `overnight_study_tool.py` serve UI-proof and research
jobs, not solver campaigns. They were deliberately not repurposed. Routing Lab
choices still carry no engineering execution authority.

## Engineering Contract schema

Machine-readable: `private/engineering_validity_release_20260923/ENGINEERING_CONTRACT_SCHEMA_FINAL.json`
or authenticated `GET /engineering-validity/schemas`.

Required contract fields:

- `schema`, `contract_id`, integer `version`, verified `parent_sha256` and explicit engineering `revision_reason` for revisions.
- `engineering`: original question, required outputs, requirements, geometry,
  materials, loads, constraints, BCs, physical assumptions, operating regime,
  model assumptions, required fidelity, allowable uncertainty, validation requirements.
- `backend`, complete `model`, `checks`, all eight `domains`, and named required acceptance criteria.
- `mutation_policy`, analytical `baseline_requests`, and bounded run/time `budget`.

Contracts begin as DRAFT. An exact fingerprint and the existing separate human
credential are required to freeze. The baseline is calculated and stored before
dispatch. Analytical inputs, approximation range, confidence and applicability
are declared before results exist. If no supported analytical calculation applies,
an explicit reason is required; no synthetic analytical check is invented.
Native `case_source` files are hashed at freeze and checked again before each
dispatch. Changes, missing files and unexpected files block dispatch.

Frozen contract/baseline files and state digests are verified on reads. Revisions
must name the immediately preceding frozen contract; exact changes and the reason
are recorded in a human-approved revision review. Old campaigns and failed
runs are retained. Hashes detect accidental alteration, not an administrator with
unrestricted filesystem access deliberately recomputing every hash.

## ENGINEERING_VALIDITY_GATE schema and state logic

Machine-readable: `private/engineering_validity_release_20260923/ENGINEERING_VALIDITY_GATE_SCHEMA.json`.

```text
engineering_validity:
  numerical_status
  physics_status
  requirement_alignment
  model_form_status
  evidence_status
  uncertainty_status
  assumption_drift_status
  experimental_correlation_status
overall_disposition: PASS | PASS_WITH_ANOMALY | INCONCLUSIVE | FAIL
recommended_action: ACCEPT | COLLECT_MORE_EVIDENCE | RUN_DISCRIMINATING_TEST |
                    NUMERICAL_ADJUSTMENT | MODEL_FORM_INVESTIGATION | HUMAN_REVIEW | BLOCK
checks: definitions, computed values, units, requirements, sources, reasons
contract_sha256 / baseline_sha256 / evidence_sha256 / run_id
existing_required_blockers / assumption_changes / qualification_override=false
```

Domains retain PASS, PASS_WITH_ANOMALY, FAIL, INCONCLUSIVE or NOT_ESTABLISHED.
Only experimental correlation may be declared NOT_APPLICABLE, with rationale,
when test data does not exist. Any required FAIL makes the overall result FAIL;
missing required evidence makes it INCONCLUSIVE; otherwise an anomaly remains
PASS_WITH_ANOMALY. Only an unqualified overall PASS produces controller ACCEPTED.
That state is acceptance under this campaign contract, **not design release or
capability qualification**. An anomaly is never automatically accepted.

Provenance distinguishes OBSERVED/CALCULATED raw evidence from INFERRED diagnoses,
PROPOSED experiments and UNESTABLISHED checks. Assumptions belong explicitly to
the contract. Inferred statements cannot be submitted as observed measurements.

## Deterministic checks implemented

| Check | Exact behavior |
|---|---|
| Limit | Finite value ≤ frozen limit; units must match |
| Physical/property range | Every finite supplied value lies within frozen lower/upper limits |
| Signed balance | `abs(sum(signed_terms))/throughput_scale`; positive scale and exact ordered term coverage required |
| Energy/interface/momentum accounting | Same signed-balance primitive with explicit named terms; storage must be included when declared, never assumed zero |
| Monitor history | Last predeclared N chronological samples: `(max-min)/scale`; incomplete windows cannot pass |
| Global/local field stationarity | Corresponding cell IDs/components required; unweighted component RMS difference divided by frozen positive scale |
| Analytical envelope | Compare retained value against frozen approximation; outside becomes anomaly, not automatically unphysical |
| Test correlation | Matched configuration, locations and times; multiple matched observables; max absolute error divided by declared combined uncertainty |
| Independent review | Only human-authenticated, evidence/contract-hash-bound receipt; cannot override a deterministic check |
| Custody | Root-confined manifest-listed JSON sources, hashes, run identity, exact JSON-pointer value equality and declared units |

Analytical baseline tools currently available are channel pressure loss (including
its existing Reynolds/regime calculation and surrogate limitations), first-order
nozzle calculation, pressure-vessel screening and sensible heat. They are reused,
not newly validated by this release. Confidence/envelope width requires engineering
justification; the software does not manufacture calibrated uncertainty.

Property/model-form checks need meaningful operating ranges or independent review.
A successful generic range check is not proof that a constitutive law applies.
Conservation can be represented on both axes where appropriate, but cannot replace
stationarity or mesh evidence. Existing required backend gates remain blocking.

## Mutation authority and assumption drift

Every field defaults to LOCKED unless explicitly declared. Policies may be LOCKED,
AGENT_ADJUSTABLE or HUMAN_APPROVAL_REQUIRED. Paths are classified by code, not by
the proposing model's label.

- Class A: recognized tolerance/iteration/output controls and declared refinement controls.
- Class B: recognized timestep, scheme/coupling or reviewed mesh-strategy controls.
- Class C: physical BCs, geometry, materials, model form, loads, criteria and unknown fields.

Only predeclared A/B changes can execute within the human-frozen campaign scope.
All require an evidence-linked hypothesis, engineering justification and two
predicted outcomes. Class C/HUMAN_APPROVAL_REQUIRED changes are blocked in the
current campaign; a new human-approved contract revision is required. LOCKED
cannot be waived by the agent.

The controller compares every proposal both with the current state and the original
frozen model. Predeclared min/max and maximum cumulative deviation are enforced;
successive small steps cannot bypass the original bound. Native input drift and
physical/cumulative policy divergence create ASSUMPTION_DRIFT records. Refinement
control availability is backend-specific: the controller does not invent a local
refinement implementation that the underlying worker does not provide.

## Hypothesis tree and next-experiment selection

After a non-PASS gate, the controller stops at AWAITING_DIAGNOSIS. A reasoning
agent or engineer may supply two to eight competing hypotheses, each with:
parent/id, statement, supporting/contradicting check IDs, missing evidence,
qualitative confidence and a discriminating test. Parents must precede children;
cycles and unknown evidence references are rejected.

Proposals name one hypothesis, exactly one changed numerical dimension, reason,
outcomes if correct/incorrect, comparison quantities, retained evidence plan,
runtime estimate and information-value estimate/rationale. The eligible proposal
with highest declared information-value per estimated second is selected. These
scores are **model/engineer estimates, not measured information gain**. All
alternatives, policy decisions and reasons remain logged. Stale proposals cannot
execute after the model or gate evidence changes.

## Overnight integration and human responsibility

Authenticated API operations are create/read, freeze, diagnosis, proposal, review,
tick, run-bounded and stop-loop. The loop delegates to existing workers and stops
on missing evidence, diagnosis, approval, budget, ambiguity or error. It does not
generate hypotheses internally; existing agent clients can submit them through
the typed API. This is a usable bounded controller, **not an end-to-end unattended
engineering scientist or a newly scheduled nightly task**.

Run-count and campaign-wall budgets constrain admission. Existing backend timeouts
govern active jobs. A control-loop stop does not cancel an already-running solver;
use the backend cancel control. Ambiguous dispatch/extraction after a crash is not
retried automatically. Stale leases and uncertain runs require human reconciliation.

Freeze/review use the existing guidance approval credential
`AERO_GUIDANCE_APPROVAL_TOKEN` with `X-Aero-Guidance-Approval`; it is separate from
the ordinary Aero API token. FEA additionally retains its existing exact-case
approval route and credential. No credential is generated, displayed or bypassed
by this release. If unconfigured, execution approval is unavailable by design.

Engineers remain responsible for question fidelity, baseline applicability,
model-form suitability, uncertainty budgets, validation data relevance, case/profile
limits and physical changes. A model may choose among allowed experiments and log
why; it may not grade itself by submitting a PASS flag.

## Tests and release evidence

`tests/test_engineering_validity.py` covers all eight requested counterexamples:
converged/nonconserving; conserved/outside approximation; plausible/missing mesh;
blocked autonomous BC change; justified refinement; cumulative drift; persistent
surprise without forced analytical agreement; missing field custody. Additional
tests cover forged reviews/grid eligibility, source tampering, wrong units,
storage omission, history completeness, correlation alignment, exact FEA approval,
backend-default changes, crash duplication, budgets and API access.

Existing routing, OpenFOAM pipeline, bounded FEA, guidance and CFD evidence suites
are also run. Exact counts and results are recorded in the release JUnit XML and
`VERIFICATION.json`, not inferred from this report. Tests use synthetic histories,
temporary files and stub workers. No new solver qualification is claimed.

Runtime verification checks private revision/tab, authenticated report/schema,
ordinary-token versus human-approval separation, cross-origin rejection and the
external private edge. The previous Rev 2.1 scoped source snapshot remains under
`revisions/private_2_1_before_validity_20260923`; it is not a complete runtime backup.

## Files added and modified

Added: `engineering_validity/{contracts,gate,controller,adapters,http,__init__}.py`,
`core/approval_policy.py`, `templates/engineering_validity.html`,
`tests/test_engineering_validity.py`, this report and its implementation plan,
`tools/engineering_validity_release.py`, `tools/verify_engineering_validity_release.py`,
and the private release evidence/schema package.

Modified: `app.py`, `templates/index.html`, `config/deployment_profiles.json`,
`REVISION.md`, `openfoam_pipeline.py`, `portable_app.py`,
`fea/bounded/integration.py`, `tests/test_private_routing_lab.py`.
The portable/FEA edits only consolidate the existing credential policy; no new
private control routes are installed for public or portable profiles.

## Limitations — deliberately unimplemented or unqualified

1. New adapters extract **manifest-listed JSON** quantities. They do not parse every
   native CFD/FEA field format or reconstruct unavailable energy/interface terms.
   Each production profile needs retained deterministic extraction outputs with
   documented units and coverage; absent outputs remain NOT_ESTABLISHED.
2. Generic cross-campaign `mesh` eligibility/comparison is fail-closed, not a working
   alternative to Aero's existing qualified mesh workflow. Existing mesh gates
   are preserved; claimed per-grid eligibility flags are not accepted. Equivalent
   settled-state integration must be supplied by the applicable profile before
   generic campaign mesh acceptance can be enabled.
3. No general model-form oracle, dimensionally aware unit-conversion engine,
   automatic experimental-data ingestion, or automatic uncertainty estimation.
   Units must match exactly; analytical tools retain their original scope limits.
4. No internal LLM diagnosis generator or scheduler was added. The persistent API
   supports external reasoning clients; missing hypotheses stop progress.
5. Enforcement applies to **managed campaigns**. Legacy manual tools are not
   retroactively governed; this is not an OS sandbox against a privileged agent
   bypassing the application. Source/hash custody is not a digital signature.
6. Hardware/solver-backed end-to-end execution of this new controller is not yet
   validated. Worker adapters are contract-tested with stubs and existing worker
   regression tests. No production simulation ran for this release.

## Recommended next step

Have an engineer freeze one small, non-HX validation campaign using an existing
supported worker, a complete exported model, justified analytical envelope and
complete retained JSON measurements. Verify the controller/worker path end-to-end
under that explicit contract before enabling unattended production campaigns.
Do not use this software release to reopen historical qualification or unblock
HX-03/HX-04.
