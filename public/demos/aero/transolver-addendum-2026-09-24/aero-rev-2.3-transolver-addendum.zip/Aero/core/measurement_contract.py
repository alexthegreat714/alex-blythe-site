"""Pre-run output and reference provenance admission for reviewed CFD templates.

This is a conservative, explicit capability registry, not an NLP claim that
every engineering request has been understood. Unrecognized requests still
need human review; recognized unsupported quantities fail before meshing.
"""

from __future__ import annotations

import hashlib
import math
import os
from pathlib import Path
import re
from typing import Any, Mapping


TEMPLATE_OUTPUTS: dict[str, frozenset[str]] = {
    "compressible_nozzle": frozenset({"mass_flow", "pressure_ratio", "temperature", "mach", "courant"}),
    "incompressible_internal": frozenset({"mass_flow", "total_pressure_loss", "pressure_drop"}),
    "external_aerodynamics": frozenset({"lift_coefficient", "drag_coefficient"}),
    "rotating_turbomachinery": frozenset({"mass_flow", "relative_total_pressure_change"}),
    "conjugate_heat_transfer": frozenset({"wall_temperature"}),
}

OUTPUT_PHRASES = {
    "reattachment_length": (r"\breattach(?:ment|ed|ing)?\b", r"\bseparation[- ]bubble length\b"),
    "wall_y_plus": (r"(?<!\w)y\s*\+", r"\byplus\b", r"\bnear[- ]wall resolution\b"),
    "lift_coefficient": (r"\blift coefficients?\b", r"\blift\s*(?:and|/|&)\s*drag\s+coefficients?\b", r"\bcl\b"),
    "drag_coefficient": (r"\bdrag coefficients?\b", r"\blift\s*(?:and|/|&)\s*drag\s+coefficients?\b", r"\bcd\b"),
    "pressure_ratio": (r"\bpressure ratio\b",),
    "total_pressure_loss": (r"\btotal pressure loss\b", r"\bpressure[- ]loss\b"),
    "pressure_drop": (r"\bpressure drop\b", r"\bdelta[- ]p\b"),
    "wall_temperature": (r"\bwall temperature\b",),
    "mass_flow": (r"\bmass flow\b", r"\bmass[- ]flow rate\b"),
    "mach": (r"\bmach(?: number)?\b",),
}


def inferred_outputs(text: str) -> list[str]:
    if not isinstance(text, str):
        return []
    return [name for name, patterns in OUTPUT_PHRASES.items()
            if any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)]


def _criteria_outputs(criteria: str) -> list[str]:
    """Do not turn an explicitly open near-wall gate into a requested monitor."""
    requested = set()
    for line in criteria.splitlines():
        found = set(inferred_outputs(line))
        if "wall_y_plus" in found and re.search(r"\b(remain(?:s)? open|not established|not evaluated|unverified|missing|pending)\b", line, re.I):
            if not re.search(r"\b(measure|compute|calculate|plot|histogram|report|record|extract)\b.{0,80}y\s*\+", line, re.I):
                found.remove("wall_y_plus")
        requested.update(found)
    return sorted(requested)


def measurement_audit(spec: Mapping[str, Any]) -> dict[str, Any]:
    template = str(spec.get("template") or "")
    requirements = spec.get("requirements") if isinstance(spec.get("requirements"), Mapping) else {}
    explicit = requirements.get("required_outputs")
    errors: list[str] = []
    if explicit is not None and (not isinstance(explicit, list) or len(explicit) > 24
                                 or any(not isinstance(item, str) or not item.strip() for item in explicit)):
        errors.append("invalid:requirements.required_outputs")
        explicit = []
    question = str(requirements.get("engineering_question") or "")
    criteria = str(requirements.get("success_criteria") or "")
    requested = sorted(set((explicit or []) + inferred_outputs(question) + _criteria_outputs(criteria)))
    supported = TEMPLATE_OUTPUTS.get(template, frozenset())
    declared = spec.get("monitoring") if isinstance(spec.get("monitoring"), Mapping) else {}
    monitor_list = declared.get("engineering_monitors")
    active = {item for item in monitor_list if isinstance(item, str)} if isinstance(monitor_list, list) else set()
    # pressure_drop is derived from the retained inlet/outlet pressure stream.
    if template == "incompressible_internal" and "total_pressure_loss" in active:
        active.add("pressure_drop")
    unsupported = [name for name in requested if name not in supported or name not in active]
    for name in unsupported:
        errors.append(f"requested_measurement_unsupported:{name}:template={template}")
    return {"status": "blocked" if errors else "supported" if requested else "unscoped",
            "requested_outputs": requested, "supported_outputs": sorted(supported),
            "retained_outputs": sorted(active), "unsupported_outputs": unsupported,
            "errors": errors,
            "note": "Only recognized or explicitly declared outputs are checked; unrecognized engineering requests need review."}


def reference_audit(spec: Mapping[str, Any]) -> dict[str, Any]:
    validation = spec.get("validation") if isinstance(spec.get("validation"), Mapping) else {}
    reference = str(validation.get("validation_reference") or "").strip()
    provenance = validation.get("reference_provenance") if isinstance(validation.get("reference_provenance"), Mapping) else {}
    comparison = validation.get("reference_comparison") if isinstance(validation.get("reference_comparison"), Mapping) else {}
    seed = str(spec.get("case_source") or "").strip()
    source = str(provenance.get("source_id") or reference).strip()
    same_seed = bool(seed and source and (
        source.casefold() == seed.casefold()
        or Path(source).name.casefold() == Path(seed).name.casefold()
        or ("/" in source or "\\" in source) and seed.replace("\\", "/").casefold() in source.replace("\\", "/").casefold()
    ))
    quantities = provenance.get("matched_quantities")
    requested = measurement_audit(spec)["requested_outputs"]
    artifact_name = str(provenance.get("source_artifact") or "").strip()
    artifact_verified = False
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,119}", artifact_name):
        root = Path(os.getenv("AERO_REFERENCE_SOURCE_ROOT") or
                    Path(__file__).resolve().parents[1] / "reference_sources").resolve()
        artifact = (root / artifact_name).resolve()
        if artifact.parent == root and artifact.is_file() and artifact.stat().st_size <= 100 * 1024 * 1024:
            digest = hashlib.sha256()
            with artifact.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
            artifact_verified = digest.hexdigest().casefold() == str(provenance.get("source_sha256") or "").casefold()
    metadata_complete = (bool(reference) and not same_seed
                   and provenance.get("independent") is True
                   and bool(str(provenance.get("source_id") or "").strip())
                   and isinstance(provenance.get("source_type"), str)
                   and provenance.get("source_type") in {"experimental", "published", "analytical", "independent_simulation"}
                   and bool(re.fullmatch(r"[0-9a-fA-F]{64}", str(provenance.get("source_sha256") or "")))
                   and bool(str(provenance.get("reviewed_by") or "").strip())
                   and isinstance(quantities, list) and bool(quantities)
                   and all(isinstance(item, str) and item.strip() for item in quantities)
                   and set(requested).issubset(set(quantities)))
    independent = bool(metadata_complete and artifact_verified)
    numeric_fields = ("predicted", "expected", "tolerance_fraction", "reference_uncertainty_fraction")
    def numeric_row(row: Mapping[str, Any]) -> bool:
        return row.get("passed") is True and all(
            type(row.get(key)) in (int, float) and math.isfinite(row[key]) for key in numeric_fields)
    per_metric = comparison.get("per_metric") if isinstance(comparison.get("per_metric"), Mapping) else {}
    if len(requested) > 1:
        numeric = all(isinstance(per_metric.get(name), Mapping) and numeric_row(per_metric[name]) for name in requested)
    else:
        numeric = numeric_row(comparison) and (not requested or comparison.get("metric") == requested[0])
    compared = bool(independent and numeric)
    status = ("missing" if not reference else "reused_seed" if same_seed else
              "provenance_unverified" if not metadata_complete else
              "source_artifact_unverified" if not artifact_verified else
              "comparison_missing" if not compared else "matched_independent_comparison")
    return {"status": status, "independent_provenance_reviewed": bool(independent),
            "comparison_passed": compared, "seed_reused": same_seed,
            "source_artifact_verified": artifact_verified,
            "reference": reference,
            "note": "The referenced artifact hash must verify under the reference root; identity does not establish scientific validity."}
