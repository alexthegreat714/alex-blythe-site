"""Shared existing engineering human-approval credential policy; no new secret."""
import hmac
import os

def human_approval_authorized(headers,scope='guidance'):
    key,header=('AERO_GUIDANCE_APPROVAL_TOKEN','X-Aero-Guidance-Approval') if scope=='guidance' else ('AERO_FEA_APPROVAL_TOKEN','X-Aero-Approval-Token')
    secret=str(os.environ.get(key) or '')
    return len(secret)>=32 and hmac.compare_digest(secret,str(headers.get(header) or ''))
