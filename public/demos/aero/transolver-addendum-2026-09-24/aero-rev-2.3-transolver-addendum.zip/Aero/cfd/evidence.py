"""Authoritative engineering evidence model for Aero CFD runs.

The distinction this module exists to make:

    EXECUTION        the solver workflow ran and produced its artifacts
    NUMERICAL        the numbers are acceptable for their own sake
    READINESS        the evidence supports using the result for engineering

These are three different questions and must never collapse into one boolean.
A run is routinely NUMERICALLY ACCEPTABLE and NOT DESIGN READY at the same time;
that is the normal state of a precursor case, not a defect.

Design rules enforced here:

* A required gate that could not be evaluated is **NOT_EVALUATED**, never PASS,
  and it prevents numerical acceptability from being established.
* Every evidence item carries its provenance, so solver measurement is
  structurally distinguishable from Aero's interpretation.
* Readiness gates are computed from case metadata and run records. Nothing in
  this module lets a caller assert readiness as a literal.

Pure functions and dataclasses only -- no VM, solver, or network dependency, so
every rule here is unit-testable and deterministic.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional, Sequence


class GateStatus(str, Enum):
    """Four states. NOT_EVALUATED is emphatically not PASS."""

    PASS = "PASS"
    FAIL = "FAIL"
    NOT_EVALUATED = "NOT_EVALUATED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class AggregateStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    NOT_ESTABLISHED = "NOT_ESTABLISHED"


class ReadinessStatus(str, Enum):
    READY = "READY"
    NOT_READY = "NOT_READY"
    NOT_ESTABLISHED = "NOT_ESTABLISHED"


class Provenance(str, Enum):
    """Where an evidence value came from. Never blur these."""

    USER_INPUT = "USER_INPUT"
    CASE_CONFIGURATION = "CASE_CONFIGURATION"
    ANALYTICAL = "ANALYTICAL"
    SOLVER_OUTPUT = "SOLVER_OUTPUT"
    DERIVED = "DERIVED"
    VALIDATION_REFERENCE = "VALIDATION_REFERENCE"
    AERO_INTERPRETATION = "AERO_INTERPRETATION"


@dataclass
class EvidenceItem:
    """One gate result with the numbers that produced it."""

    id: str
    status: GateStatus
    required: bool
    source: Provenance
    reason: str
    value: Optional[float] = None
    limit: Optional[float] = None
    units: str = ""
    detail: Dict[str, Any] = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return self.status is GateStatus.PASS

    @property
    def blocks(self) -> bool:
        """True when this item prevents the aggregate from being established."""
        if not self.required:
            return False
        return self.status in (GateStatus.FAIL, GateStatus.NOT_EVALUATED)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "status": self.status.value,
            "required": self.required,
            "source": self.source.value,
            "reason": self.reason,
            "value": self.value,
            "limit": self.limit,
            "units": self.units,
            "detail": self.detail,
        }


# --------------------------------------------------------------------------
# runtime instrumentation
# --------------------------------------------------------------------------

_PHASES = (
    "request_received",
    "execution_started",
    "solver_started",
    "solver_finished",
    "evidence_finished",
    "response_ready",
)


@dataclass
class RuntimeTrace:
    """Monotonic phase timing. Durations only from perf_counter, never wall clock.

    A trace that was never marked yields ``recorded=False`` and the UI must show
    RUNTIME NOT RECORDED rather than inventing a representative number.
    """

    marks: Dict[str, float] = field(default_factory=dict)
    wall_started_at: Optional[str] = None

    def mark(self, phase: str) -> None:
        if phase not in _PHASES:
            raise ValueError(f"unknown phase {phase!r}; expected one of {_PHASES}")
        self.marks[phase] = time.perf_counter()
        if phase == "request_received" and self.wall_started_at is None:
            self.wall_started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    def _delta(self, a: str, b: str) -> Optional[float]:
        if a in self.marks and b in self.marks:
            return round(max(0.0, self.marks[b] - self.marks[a]), 3)
        return None

    @property
    def recorded(self) -> bool:
        return "solver_started" in self.marks and "solver_finished" in self.marks

    def to_dict(self) -> Dict[str, Any]:
        return {
            "recorded": self.recorded,
            "wall_started_at": self.wall_started_at,
            "queue_time_s": self._delta("request_received", "execution_started"),
            "setup_time_s": self._delta("execution_started", "solver_started"),
            "solver_runtime_s": self._delta("solver_started", "solver_finished"),
            "evidence_runtime_s": self._delta("solver_finished", "evidence_finished"),
            "request_to_result_s": self._delta("request_received", "response_ready"),
            "phases_marked": sorted(self.marks.keys()),
        }


# --------------------------------------------------------------------------
# numerical gates
# --------------------------------------------------------------------------

DEFAULT_MASS_IMBALANCE_FRAC = 0.01
DEFAULT_MONITOR_VARIATION_FRAC = 0.01


def gate_run_completed(*, completed: Optional[bool], wrote_artifacts: Optional[bool]) -> EvidenceItem:
    """Execution finished and finalization artifacts exist.

    This says nothing about convergence, conservation, validation or readiness.
    """
    if completed is None and wrote_artifacts is None:
        return EvidenceItem(
            id="run_completed", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.SOLVER_OUTPUT,
            reason="no execution record available",
        )
    if bool(completed) and bool(wrote_artifacts):
        return EvidenceItem(
            id="run_completed", status=GateStatus.PASS, required=True,
            source=Provenance.SOLVER_OUTPUT,
            reason="solver workflow completed and wrote its finalization artifacts",
            detail={"completed": bool(completed), "wrote_artifacts": bool(wrote_artifacts)},
        )
    return EvidenceItem(
        id="run_completed", status=GateStatus.FAIL, required=True,
        source=Provenance.SOLVER_OUTPUT,
        reason="solver workflow did not complete with the expected artifacts",
        detail={"completed": bool(completed), "wrote_artifacts": bool(wrote_artifacts)},
    )


def gate_mesh_quality(
    *,
    min_orthogonal_quality: Optional[float],
    max_aspect_ratio: Optional[float],
    negative_volumes: Optional[int] = None,
    min_orthogonal_limit: float = 0.01,
    max_aspect_limit: float = 1000.0,
) -> EvidenceItem:
    if negative_volumes is not None and negative_volumes > 0:
        return EvidenceItem(
            id="mesh_quality", status=GateStatus.FAIL, required=True,
            source=Provenance.SOLVER_OUTPUT, value=float(negative_volumes), limit=0.0,
            units="cells", reason=f"{negative_volumes} negative-volume cells",
        )
    if min_orthogonal_quality is None and max_aspect_ratio is None:
        return EvidenceItem(
            id="mesh_quality", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.SOLVER_OUTPUT,
            reason="no mesh quality metrics reported by the mesher",
        )
    if min_orthogonal_quality is not None and min_orthogonal_quality < min_orthogonal_limit:
        return EvidenceItem(
            id="mesh_quality", status=GateStatus.FAIL, required=True,
            source=Provenance.SOLVER_OUTPUT, value=float(min_orthogonal_quality),
            limit=min_orthogonal_limit, units="",
            reason=f"minimum orthogonal quality {min_orthogonal_quality:.4g} below {min_orthogonal_limit}",
        )
    if max_aspect_ratio is not None and max_aspect_ratio > max_aspect_limit:
        return EvidenceItem(
            id="mesh_quality", status=GateStatus.FAIL, required=True,
            source=Provenance.SOLVER_OUTPUT, value=float(max_aspect_ratio),
            limit=max_aspect_limit, units="",
            reason=f"maximum aspect ratio {max_aspect_ratio:.4g} above {max_aspect_limit}",
        )
    return EvidenceItem(
        id="mesh_quality", status=GateStatus.PASS, required=True,
        source=Provenance.SOLVER_OUTPUT, value=min_orthogonal_quality,
        limit=min_orthogonal_limit,
        reason="mesh metrics within limits and no negative volumes",
        detail={"min_orthogonal_quality": min_orthogonal_quality, "max_aspect_ratio": max_aspect_ratio},
    )


def gate_residual_convergence(
    *,
    converged_flag: Optional[bool] = None,
    final_residuals: Optional[Dict[str, float]] = None,
    residual_target: float = 1e-3,
) -> EvidenceItem:
    if converged_flag is None and not final_residuals:
        return EvidenceItem(
            id="residual_convergence", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.SOLVER_OUTPUT, limit=residual_target,
            reason="no residual history or convergence statement in solver output",
        )
    if final_residuals:
        worst_key, worst = max(final_residuals.items(), key=lambda kv: kv[1])
        if worst <= residual_target:
            return EvidenceItem(
                id="residual_convergence", status=GateStatus.PASS, required=True,
                source=Provenance.SOLVER_OUTPUT, value=float(worst), limit=residual_target,
                reason=f"worst final residual {worst_key}={worst:.3e} at or below {residual_target:.0e}",
                detail={"final_residuals": final_residuals},
            )
        return EvidenceItem(
            id="residual_convergence", status=GateStatus.FAIL, required=True,
            source=Provenance.SOLVER_OUTPUT, value=float(worst), limit=residual_target,
            reason=f"worst final residual {worst_key}={worst:.3e} above {residual_target:.0e}",
            detail={"final_residuals": final_residuals},
        )
    if converged_flag:
        return EvidenceItem(
            id="residual_convergence", status=GateStatus.PASS, required=True,
            source=Provenance.SOLVER_OUTPUT, limit=residual_target,
            reason="solver reported the solution converged",
        )
    return EvidenceItem(
        id="residual_convergence", status=GateStatus.FAIL, required=True,
        source=Provenance.SOLVER_OUTPUT, limit=residual_target,
        reason="solver did not report convergence",
    )


def gate_mass_conservation(
    *,
    net_mass_flux: Optional[float],
    throughput: Optional[float],
    max_imbalance_frac: float = DEFAULT_MASS_IMBALANCE_FRAC,
    required: bool = True,
) -> EvidenceItem:
    """Normalized mass imbalance against a real throughput reference.

    Deliberately refuses to judge without a throughput reference. The previous
    implementation fell back to comparing an ABSOLUTE net flux in kg/s against
    the dimensionless fraction 0.01, so a 0.009 kg/s imbalance on a 0.010 kg/s
    nozzle -- about 90 percent of the flow -- compared as 0.009 <= 0.01 and
    PASSED. Comparing kg/s to a fraction is not a tolerance, so that path is
    gone: no reference means NOT_EVALUATED.
    """
    if net_mass_flux is None:
        return EvidenceItem(
            id="mass_conservation", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, limit=max_imbalance_frac, units="fraction",
            reason="no flux or imbalance report in solver output",
        )
    if not _finite(net_mass_flux):
        return EvidenceItem(
            id="mass_conservation", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, limit=max_imbalance_frac, units="fraction",
            reason="net mass flux reported as a non-finite value",
            detail={"net_mass_flux": str(net_mass_flux)},
        )
    if throughput is None or not _finite(throughput) or abs(throughput) <= 0.0:
        return EvidenceItem(
            id="mass_conservation", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, value=float(net_mass_flux),
            limit=max_imbalance_frac, units="fraction",
            reason=(
                "no usable throughput reference, so the imbalance cannot be normalized; "
                "an absolute mass flux is not comparable to a fractional tolerance"
            ),
            detail={"net_mass_flux": float(net_mass_flux), "throughput": throughput},
        )
    frac = abs(float(net_mass_flux)) / abs(float(throughput))
    status = GateStatus.PASS if frac <= max_imbalance_frac else GateStatus.FAIL
    return EvidenceItem(
        id="mass_conservation", status=status, required=required,
        source=Provenance.SOLVER_OUTPUT, value=frac, limit=max_imbalance_frac, units="fraction",
        reason=(
            f"net mass flux {net_mass_flux:.3e} kg/s is {frac:.3%} of throughput "
            f"{abs(float(throughput)):.3e} kg/s (limit {max_imbalance_frac:.2%})"
        ),
        detail={"net_mass_flux": float(net_mass_flux), "throughput": float(throughput),
                "imbalance_fraction": frac},
    )


def gate_energy_conservation(
    *,
    energy_imbalance: Optional[float] = None,
    energy_throughput: Optional[float] = None,
    max_imbalance_frac: float = DEFAULT_MASS_IMBALANCE_FRAC,
    required: bool = False,
    applicable: bool = True,
) -> EvidenceItem:
    """Energy balance. Honest by default: NOT_EVALUATED unless real numbers arrive.

    The current compressible-nozzle precursor does not emit an energy balance
    report, so this returns NOT_EVALUATED rather than fabricating a PASS. The
    computation is implemented so that the moment a solver reports the numbers,
    the gate becomes real without a schema change.
    """
    if not applicable:
        return EvidenceItem(
            id="energy_conservation", status=GateStatus.NOT_APPLICABLE, required=False,
            source=Provenance.CASE_CONFIGURATION,
            reason="case does not solve an energy equation",
        )
    if energy_imbalance is None or energy_throughput is None:
        return EvidenceItem(
            id="energy_conservation", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, limit=max_imbalance_frac, units="fraction",
            reason="solver output contains no energy balance report for this case",
        )
    if not (_finite(energy_imbalance) and _finite(energy_throughput)) or abs(energy_throughput) <= 0.0:
        return EvidenceItem(
            id="energy_conservation", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, limit=max_imbalance_frac, units="fraction",
            reason="energy balance values unusable; cannot normalize the imbalance",
            detail={"energy_imbalance": str(energy_imbalance), "energy_throughput": str(energy_throughput)},
        )
    frac = abs(float(energy_imbalance)) / abs(float(energy_throughput))
    status = GateStatus.PASS if frac <= max_imbalance_frac else GateStatus.FAIL
    return EvidenceItem(
        id="energy_conservation", status=status, required=required,
        source=Provenance.SOLVER_OUTPUT, value=frac, limit=max_imbalance_frac, units="fraction",
        reason=f"energy imbalance is {frac:.3%} of energy throughput (limit {max_imbalance_frac:.2%})",
        detail={"energy_imbalance": float(energy_imbalance), "energy_throughput": float(energy_throughput)},
    )


def gate_monitor_stability(
    *,
    monitor_name: Optional[str] = None,
    series: Optional[Sequence[float]] = None,
    window: int = 20,
    max_variation_frac: float = DEFAULT_MONITOR_VARIATION_FRAC,
    required: bool = False,
) -> EvidenceItem:
    """Stability of an engineering quantity, independent of residual convergence.

    Residuals can fall while the quantity a decision depends on still drifts, so
    this is a separate question. Not invented to fill a UI row: with no monitor
    series it reports NOT_EVALUATED.
    """
    if not monitor_name or series is None:
        return EvidenceItem(
            id="monitor_stability", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, limit=max_variation_frac, units="fraction",
            reason="no engineering monitor series was recorded for this case",
        )
    values = [float(v) for v in series if _finite(v)]
    if len(values) < max(3, min(window, 3)):
        return EvidenceItem(
            id="monitor_stability", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, limit=max_variation_frac, units="fraction",
            reason=f"monitor {monitor_name!r} has too few finite samples to judge stability",
            detail={"monitor": monitor_name, "samples": len(values)},
        )
    tail = values[-window:] if len(values) >= window else values
    ref = abs(tail[-1])
    if ref <= 0.0:
        return EvidenceItem(
            id="monitor_stability", status=GateStatus.NOT_EVALUATED, required=required,
            source=Provenance.SOLVER_OUTPUT, limit=max_variation_frac, units="fraction",
            reason=f"monitor {monitor_name!r} final value is zero; relative variation undefined",
            detail={"monitor": monitor_name},
        )
    variation = (max(tail) - min(tail)) / ref
    status = GateStatus.PASS if variation <= max_variation_frac else GateStatus.FAIL
    return EvidenceItem(
        id="monitor_stability", status=status, required=required,
        source=Provenance.SOLVER_OUTPUT, value=variation, limit=max_variation_frac, units="fraction",
        reason=(
            f"monitor {monitor_name!r} varied {variation:.3%} over the last {len(tail)} samples "
            f"(limit {max_variation_frac:.2%})"
        ),
        detail={"monitor": monitor_name, "window": len(tail), "min": min(tail), "max": max(tail),
                "final": tail[-1]},
    )


# --------------------------------------------------------------------------
# readiness gates
# --------------------------------------------------------------------------

def gate_validation_reference(reference: Optional[Dict[str, Any]]) -> EvidenceItem:
    """Computed from the case record. MISSING is represented as NOT_EVALUATED."""
    if not reference:
        return EvidenceItem(
            id="validation_reference", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.VALIDATION_REFERENCE,
            reason="no validation reference is attached to this case",
            detail={"expected_reference_types": ["experimental", "analytical", "published_benchmark",
                                                 "trusted_solver_comparison"]},
        )
    metric = reference.get("metric")
    predicted = reference.get("predicted")
    expected = reference.get("expected")
    tolerance = reference.get("tolerance")
    detail = {k: reference.get(k) for k in ("type", "identifier", "metric", "tolerance")}
    if predicted is None or expected is None or tolerance is None:
        return EvidenceItem(
            id="validation_reference", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.VALIDATION_REFERENCE,
            reason="validation reference attached but incomplete; needs predicted, expected and tolerance",
            detail=detail,
        )
    if not (_finite(predicted) and _finite(expected)) or abs(float(expected)) <= 0.0:
        return EvidenceItem(
            id="validation_reference", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.VALIDATION_REFERENCE,
            reason="validation reference values unusable for a relative comparison",
            detail=detail,
        )
    rel = abs(float(predicted) - float(expected)) / abs(float(expected))
    status = GateStatus.PASS if rel <= float(tolerance) else GateStatus.FAIL
    return EvidenceItem(
        id="validation_reference", status=status, required=True,
        source=Provenance.VALIDATION_REFERENCE, value=rel, limit=float(tolerance), units="fraction",
        reason=f"{metric or 'metric'} differs from the reference by {rel:.3%} (tolerance {float(tolerance):.2%})",
        detail={**detail, "predicted": predicted, "expected": expected},
    )


def gate_model_fidelity(assessment: Optional[Dict[str, Any]]) -> EvidenceItem:
    """Explicit per-claim fidelity evidence. No invented composite score."""
    if not assessment:
        return EvidenceItem(
            id="model_fidelity", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.CASE_CONFIGURATION,
            reason="no model fidelity assessment is recorded for this case",
            detail={"expected_claims": ["turbulence_model_suitability", "compressibility_treatment",
                                        "dimensionality", "steady_vs_transient", "material_properties",
                                        "boundary_condition_fidelity", "known_omissions"]},
        )
    claims = assessment.get("claims") or {}
    if not claims:
        return EvidenceItem(
            id="model_fidelity", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.CASE_CONFIGURATION,
            reason="fidelity assessment present but contains no substantiated claims",
        )
    unmet = [k for k, v in claims.items() if not bool((v or {}).get("established"))]
    if unmet:
        return EvidenceItem(
            id="model_fidelity", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.CASE_CONFIGURATION,
            reason="fidelity claims not established: " + ", ".join(sorted(unmet)),
            detail={"claims": claims, "unestablished": sorted(unmet)},
        )
    return EvidenceItem(
        id="model_fidelity", status=GateStatus.PASS, required=True,
        source=Provenance.CASE_CONFIGURATION,
        reason="all recorded fidelity claims are established with evidence",
        detail={"claims": claims},
    )


@dataclass
class MeshLevelRun:
    """One refinement level offered as mesh-independence evidence."""

    level: str
    cell_count: Optional[int]
    metric_name: str
    metric_value: Optional[float]
    numerically_acceptable: bool
    run_id: str = ""
    stale: bool = False
    ineligible_reason: str = ""

    @property
    def eligible(self) -> bool:
        return (
            self.numerically_acceptable
            and not self.stale
            and self.metric_value is not None
            and _finite(self.metric_value)
            and not self.ineligible_reason
        )


def gate_mesh_independence(
    runs: Sequence[MeshLevelRun],
    *,
    max_relative_change: float = 0.02,
) -> EvidenceItem:
    """Computed from real runs at different refinement levels.

    A run that is not numerically acceptable, is stale, or lacks the metric is
    excluded from the comparison and recorded in ``ineligible_runs``. It can
    never contribute to a positive result.
    """
    eligible = [r for r in runs if r.eligible]
    ineligible = [
        {"level": r.level, "run_id": r.run_id, "cell_count": r.cell_count,
         "reason": r.ineligible_reason or ("stale run record" if r.stale else
                   ("metric not recorded" if r.metric_value is None else
                    "run is not numerically acceptable"))}
        for r in runs if not r.eligible
    ]
    if len(eligible) < 2:
        return EvidenceItem(
            id="mesh_independence", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.DERIVED, limit=max_relative_change, units="fraction",
            reason=(
                f"only {len(eligible)} eligible refinement level(s); at least two are required "
                "to demonstrate independence"
            ),
            detail={"eligible_levels": [r.level for r in eligible], "ineligible_runs": ineligible,
                    "comparisons": []},
        )
    ordered = sorted(eligible, key=lambda r: (r.cell_count if r.cell_count is not None else 0))
    comparisons: List[Dict[str, Any]] = []
    worst = 0.0
    for coarse, fine in zip(ordered, ordered[1:]):
        denom = abs(float(fine.metric_value))  # type: ignore[arg-type]
        if denom <= 0.0:
            comparisons.append({"from": coarse.level, "to": fine.level,
                                "relative_change": None, "reason": "finer metric is zero"})
            continue
        rel = abs(float(fine.metric_value) - float(coarse.metric_value)) / denom  # type: ignore[arg-type]
        worst = max(worst, rel)
        comparisons.append({
            "from": coarse.level, "to": fine.level, "metric": fine.metric_name,
            "coarse_value": coarse.metric_value, "fine_value": fine.metric_value,
            "relative_change": rel,
        })
    usable = [c for c in comparisons if c.get("relative_change") is not None]
    if not usable:
        return EvidenceItem(
            id="mesh_independence", status=GateStatus.NOT_EVALUATED, required=True,
            source=Provenance.DERIVED, limit=max_relative_change, units="fraction",
            reason="no usable comparison between eligible refinement levels",
            detail={"comparisons": comparisons, "ineligible_runs": ineligible},
        )
    metric_name = ordered[-1].metric_name
    if worst <= max_relative_change:
        return EvidenceItem(
            id="mesh_independence", status=GateStatus.PASS, required=True,
            source=Provenance.DERIVED, value=worst, limit=max_relative_change, units="fraction",
            reason=(
                f"{metric_name} changed at most {worst:.2%} between eligible refinement levels "
                f"(limit {max_relative_change:.2%})"
            ),
            detail={"comparisons": comparisons, "ineligible_runs": ineligible},
        )
    return EvidenceItem(
        id="mesh_independence", status=GateStatus.NOT_EVALUATED, required=True,
        source=Provenance.DERIVED, value=worst, limit=max_relative_change, units="fraction",
        reason=(
            f"eligible refinement levels did not demonstrate stability: {metric_name} changed "
            f"{worst:.2%}, above the {max_relative_change:.2%} threshold"
        ),
        detail={"comparisons": comparisons, "ineligible_runs": ineligible},
    )


# --------------------------------------------------------------------------
# aggregation
# --------------------------------------------------------------------------

def aggregate_numerical(items: Sequence[EvidenceItem]) -> AggregateStatus:
    """FAIL beats NOT_ESTABLISHED beats PASS. Required + NOT_EVALUATED never passes."""
    required = [i for i in items if i.required]
    if any(i.status is GateStatus.FAIL for i in required):
        return AggregateStatus.FAIL
    if any(i.status is GateStatus.NOT_EVALUATED for i in required):
        return AggregateStatus.NOT_ESTABLISHED
    if not required:
        return AggregateStatus.NOT_ESTABLISHED
    return AggregateStatus.PASS


def aggregate_readiness(
    numerical: AggregateStatus, items: Sequence[EvidenceItem]
) -> ReadinessStatus:
    """Readiness requires numerical acceptability first, then every readiness gate."""
    required = [i for i in items if i.required]
    if numerical is AggregateStatus.FAIL or any(i.status is GateStatus.FAIL for i in required):
        return ReadinessStatus.NOT_READY
    if numerical is not AggregateStatus.PASS:
        return ReadinessStatus.NOT_ESTABLISHED
    if any(i.status is GateStatus.NOT_EVALUATED for i in required) or not required:
        return ReadinessStatus.NOT_ESTABLISHED
    return ReadinessStatus.READY


def build_result_contract(
    *,
    execution_status: str,
    numerical_items: Sequence[EvidenceItem],
    readiness_items: Sequence[EvidenceItem],
    trace: Optional[RuntimeTrace] = None,
    case_id: str = "",
    solver: str = "",
) -> Dict[str, Any]:
    """The single authoritative object the UI is allowed to read."""
    numerical = aggregate_numerical(numerical_items)
    readiness = aggregate_readiness(numerical, readiness_items)
    timing = (trace or RuntimeTrace()).to_dict()
    return {
        "schema": "aero.cfd.evidence.v1",
        "case_id": case_id,
        "solver": solver,
        "execution": {
            "status": execution_status,
            "runtime": timing,
            "runtime_display": _runtime_display(timing),
        },
        "numerical": {
            "status": numerical.value,
            "blocking": [i.id for i in numerical_items if i.blocks],
            "gates": [i.to_dict() for i in numerical_items],
        },
        "readiness": {
            "status": readiness.value,
            "blocking": [i.id for i in readiness_items if i.blocks],
            "gates": [i.to_dict() for i in readiness_items],
        },
        "interpretation": {
            "note": (
                "Numerical acceptability concerns the numbers only. Design readiness "
                "additionally requires validation, fidelity and mesh independence. "
                "A numerically acceptable run is not a validated engineering result."
            ),
            "source": Provenance.AERO_INTERPRETATION.value,
        },
    }


def _runtime_display(timing: Dict[str, Any]) -> Dict[str, str]:
    """Never invent a number. Unmeasured phases render as NOT RECORDED."""
    if not timing.get("recorded"):
        return {"solver": "NOT RECORDED", "total": "NOT RECORDED"}
    solver = timing.get("solver_runtime_s")
    total = timing.get("request_to_result_s")
    return {
        "solver": f"{solver:.2f} s" if isinstance(solver, (int, float)) else "NOT RECORDED",
        "total": f"{total:.2f} s" if isinstance(total, (int, float)) else "NOT RECORDED",
    }


def _finite(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


# --------------------------------------------------------------------------
# evidence panel (text surface; the web panel renders the same contract)
# --------------------------------------------------------------------------

_LABELS = {
    "run_completed": "Run completed",
    "mesh_quality": "Mesh quality",
    "residual_convergence": "Residual convergence",
    "mass_conservation": "Mass conservation",
    "energy_conservation": "Energy conservation",
    "monitor_stability": "Monitor stability",
    "validation_reference": "Validation reference",
    "model_fidelity": "Model fidelity",
    "mesh_independence": "Mesh independence",
}


def render_evidence_panel(contract: Dict[str, Any]) -> str:
    """Render strictly from the contract. No row is ever a literal."""
    lines: List[str] = ["AERO / ENGINEERING EVIDENCE", ""]
    ex = contract.get("execution") or {}
    disp = ex.get("runtime_display") or {}
    lines.append("EXECUTION")
    lines.append(f"  {'Status':<28}{ex.get('status', 'UNKNOWN')}")
    lines.append(f"  {'Solver runtime':<28}{disp.get('solver', 'NOT RECORDED')}")
    lines.append(f"  {'Request to result':<28}{disp.get('total', 'NOT RECORDED')}")
    lines.append("")
    lines.append("NUMERICAL EVIDENCE")
    for g in (contract.get("numerical") or {}).get("gates", []):
        label = _LABELS.get(g["id"], g["id"])
        lines.append(f"  {label:<28}{_fmt_status(g['status'])}")
    lines.append("")
    lines.append(f"  {'NUMERICAL ACCEPTABILITY':<28}{_fmt_status((contract.get('numerical') or {}).get('status'))}")
    lines.append("")
    lines.append("DESIGN READINESS")
    for g in (contract.get("readiness") or {}).get("gates", []):
        label = _LABELS.get(g["id"], g["id"])
        lines.append(f"  {label:<28}{_fmt_status(g['status'])}")
    lines.append("")
    lines.append(f"  {'OVERALL DESIGN READINESS':<28}{_fmt_status((contract.get('readiness') or {}).get('status'))}")
    return "\n".join(lines)


def render_evidence_detail(item: Dict[str, Any]) -> str:
    """Expandable detail for one gate: the numbers behind the verdict."""
    label = _LABELS.get(item.get("id", ""), item.get("id", ""))
    out = [f"{label.upper()} - {_fmt_status(item.get('status'))}", ""]
    if item.get("value") is not None:
        out.append(f"  Measured value      {item['value']:.6g} {item.get('units', '')}".rstrip())
    if item.get("limit") is not None:
        out.append(f"  Acceptance limit    {item['limit']:.6g} {item.get('units', '')}".rstrip())
    out.append(f"  Required            {'yes' if item.get('required') else 'no'}")
    out.append(f"  Provenance          {item.get('source', '')}")
    out.append(f"  Reason              {item.get('reason', '')}")
    detail = item.get("detail") or {}
    if detail:
        out.append("  Evidence")
        for k, v in detail.items():
            out.append(f"    {k}: {v}")
    return "\n".join(out)


def _fmt_status(status: Any) -> str:
    return str(status or "UNKNOWN").replace("_", " ")
