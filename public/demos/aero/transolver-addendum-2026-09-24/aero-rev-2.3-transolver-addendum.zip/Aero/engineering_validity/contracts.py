"""Versioned schemas, baseline construction and field-level authority."""
import copy
import hashlib
import json
import math
import re
from pathlib import Path
from Aero.engineering_toolkit import kernel

DOMAINS=('numerical_status','physics_status','requirement_alignment','model_form_status',
         'evidence_status','uncertainty_status','assumption_drift_status','experimental_correlation_status')
STATES=('PASS','PASS_WITH_ANOMALY','INCONCLUSIVE','FAIL','NOT_ESTABLISHED','NOT_APPLICABLE')
KINDS=('limit','range','balance','history','field_delta','envelope','correlation','review','mesh')
TOOLS={name:getattr(kernel,name) for name in ('channel_pressure_loss','nozzle_first_order','pressure_vessel_screen','thermal_sensible_heat')}
ENGINEERING_FIELDS=('original_question','required_outputs','requirements','geometry','materials','loads','constraints',
 'boundary_conditions','physical_assumptions','operating_regime','model_assumptions','required_fidelity',
 'allowable_uncertainty','validation_requirements')

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def number(value):
    if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value):
        raise ValueError('finite numeric value required')
    return float(value)

def pointer(obj,path):
    if not isinstance(path,str) or not path.startswith('/'):
        raise ValueError('JSON pointer required')
    for part in path[1:].split('/'):
        part=part.replace('~1','/').replace('~0','~')
        obj=obj[int(part)] if isinstance(obj,list) else obj[part]
    return obj

def replace(obj,path,value):
    parent,_,leaf=path.rpartition('/')
    target=pointer(obj,parent) if parent else obj
    leaf=leaf.replace('~1','/').replace('~0','~')
    if isinstance(target,list):target[int(leaf)]=copy.deepcopy(value)
    else:
        if leaf not in target:raise ValueError('Cannot introduce undeclared field')
        target[leaf]=copy.deepcopy(value)

def differences(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        for key in sorted(set(a)|set(b)):
            p=path+'/'+key.replace('~','~0').replace('/','~1')
            if key not in a or key not in b:out.append({'path':p,'before':a.get(key),'after':b.get(key)})
            else:out.extend(differences(a[key],b[key],p))
        return out
    return [] if a==b else [{'path':path,'before':a,'after':b}]

def mutation_class(path):
    # Never let a caller label a physical change as numerical/class A.
    if path.startswith('/model/numerics/'):
        leaf=path.rsplit('/',1)[-1]
        if leaf in ('end_time','timeout_sec','write_interval','max_iterations','tolerance','rel_tol'):return 'A'
        if leaf in ('delta_t','max_delta_t','max_courant','schemes','relaxation','nOuterCorrectors','nCorrectors'):return 'B'
        return 'C'
    if path.startswith('/model/monitoring/') and path.endswith('/sample_interval_sec'):return 'A'
    if path in ('/model/mesh/refinement_passes','/model/mesh/local_refinement'):return 'A'
    if path in ('/model/mesh/cell_size','/model/mesh/refinement_strategy','/model/mesh/topology'):return 'B'
    return 'C'

def assess_changes(contract,current,proposed):
    changes=differences(current,proposed)
    cumulative=differences(contract['model'],proposed['model'],'/model')
    reasons=[]; classes=[]
    for row in changes:
        rule=contract['mutation_policy'].get(row['path'],{'authority':'LOCKED'})
        cls=mutation_class(row['path']); classes.append(cls)
        row.update(classification=cls,authority=rule['authority'])
        if rule['authority']=='LOCKED':reasons.append('LOCKED:'+row['path'])
        if cls=='C' or rule['authority']=='HUMAN_APPROVAL_REQUIRED':reasons.append('HUMAN_APPROVAL_AND_CONTRACT_REVISION:'+row['path'])
    for row in cumulative:
        rule=contract['mutation_policy'].get(row['path'],{})
        if mutation_class(row['path'])=='C':reasons.append('ASSUMPTION_DRIFT:'+row['path'])
        if 'max_delta_from_frozen' in rule:
            if abs(number(row['after'])-number(row['before']))>rule['max_delta_from_frozen']:
                reasons.append('CUMULATIVE_DRIFT:'+row['path'])
        if 'minimum' in rule and number(row['after'])<rule['minimum']:reasons.append('BELOW_BOUND:'+row['path'])
        if 'maximum' in rule and number(row['after'])>rule['maximum']:reasons.append('ABOVE_BOUND:'+row['path'])
    return {'allowed':bool(changes) and not reasons,'changes':changes,'cumulative_changes':cumulative,
            'classification':max(classes,default='C'),'reasons':sorted(set(reasons)),
            'physical_problem_changed':any(mutation_class(r['path'])=='C' for r in changes)}

def validate_contract(raw):
    from jsonschema import validate
    validate(raw,CONTRACT_SCHEMA)
    value=copy.deepcopy(raw); digest(value)
    if value['version']>1 and (not isinstance(value.get('revision_reason'),str) or len(value['revision_reason'].strip())<10):raise ValueError('Contract revisions require an explicit engineering reason')
    if set(value['domains'])!=set(DOMAINS):raise ValueError('All eight domains need an applicability declaration')
    for domain in DOMAINS:
        if domain!='experimental_correlation_status' and not value['domains'][domain]['applicable']:
            raise ValueError('Core engineering domain cannot be declared inapplicable: '+domain)
    ids=[c['id'] for c in value['checks']]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate check IDs')
    if not set(value['acceptance_criteria']).issubset(ids):raise ValueError('Acceptance criteria must reference checks')
    if any(not c['required'] for c in value['checks'] if c['id'] in value['acceptance_criteria']):raise ValueError('Acceptance criteria must be required')
    for name in DOMAINS:
        if name not in ('requirement_alignment','evidence_status','assumption_drift_status') and value['domains'][name]['applicable']:
            if not any(c['domain']==name and c['required'] for c in value['checks']):raise ValueError('Required checks missing for '+name)
    for path,rule in value['mutation_policy'].items():
        pointer(value,path)
        if rule['authority']=='AGENT_ADJUSTABLE' and mutation_class(path)=='C':raise ValueError('Physical or unknown field cannot be autonomous')
        for k in ('minimum','maximum','max_delta_from_frozen'):
            if k in rule:number(rule[k])
        if rule.get('max_delta_from_frozen',0)<0 or rule.get('minimum',-math.inf)>rule.get('maximum',math.inf):raise ValueError('Invalid mutation bounds')
    for check in value['checks']:
        if check['kind'] in ('limit','balance','history','field_delta','mesh','correlation'):
            if number(check.get('limit'))<0:raise ValueError('Nonnegative predeclared limit required')
        if check['kind']=='range' and number(check.get('lower'))>number(check.get('upper')):raise ValueError('Invalid range')
        if check['kind'] in ('history','field_delta') and number(check.get('scale'))<=0:raise ValueError('Positive normalization scale required')
        if check['kind']=='history' and int(check.get('samples',0))<2:raise ValueError('History window requires at least two samples')
        if check['kind']=='balance':
            names=check.get('term_names')
            if not isinstance(names,list) or len(names)<2 or not all(isinstance(n,str) and n for n in names) or len(set(names))!=len(names):raise ValueError('Explicit unique signed balance terms required')
    if value['backend']=='openfoam' and value['model'].get('automation',{}).get('auto_adjust'):
        raise ValueError('Managed campaigns require predeclared experiments, not live automatic retuning')
    policy=value.get('physics_ai_policy')
    if policy:
        experiment_ids=set()
        for experiment in policy['optional_experiments']:
            if experiment['id'] in experiment_ids or experiment['id'] in ids:
                raise ValueError('Optional experiment must be distinct from every required/check evidence ID')
            experiment_ids.add(experiment['id'])
            if number(experiment['expected_lower'])>number(experiment['expected_upper']) or number(experiment['minimum_margin'])<=0:
                raise ValueError('Predeclared hypothesis interval and positive margin required')
            path=experiment['mutation_path']
            rule=value['mutation_policy'].get(path,{})
            if rule.get('authority')!='AGENT_ADJUSTABLE' or mutation_class(path)=='C':
                raise ValueError('Optional screening must use an already authorized numerical mutation')
    return value

def build_baseline(contract):
    results={}
    for request in contract['baseline_requests']:
        if request['id'] in results:raise ValueError('Duplicate baseline ID')
        result=TOOLS[request['tool']](request['inputs'])
        if not result['ok']:raise ValueError('Analytical baseline inputs invalid: '+request['id'])
        nominal=number(pointer(result,'/results/'+request['output']))
        fraction=number(request['plausible_fraction'])
        if fraction<0:raise ValueError('Negative envelope width')
        width=abs(nominal)*fraction+number(request.get('absolute_allowance',0))
        if width<0:raise ValueError('Negative envelope width')
        results[request['id']]={'nominal':nominal,'lower':nominal-width,'upper':nominal+width,
            'units':request['units'],'derivation':request['tool'],'inputs':request['inputs'],
            'applicability':request['applicability'],'confidence':request['confidence'],
            'result':result,'provenance':'CALCULATED','script_sha256':hashlib.sha256(open(kernel.__file__,'rb').read()).hexdigest()}
    if not results and not contract.get('baseline_unavailable_reason'):raise ValueError('Baseline or explicit applicability gap required')
    for check in contract['checks']:
        if check['kind']=='envelope' and check.get('baseline_id') not in results:raise ValueError('Missing frozen baseline')
    return {'schema':'PRE_RUN_PHYSICS_BASELINE.v1','contract_sha256':digest(contract),'predictions':results,
        'source_case_identity':source_case_identity(contract['model']),
        'unavailable_reason':contract.get('baseline_unavailable_reason'),'constructed_before_dispatch':True}

def source_case_identity(model):
    """Freeze the actual native input tree, not just its mutable directory name."""
    source=model.get('case_source')
    if not source:return None # Payload-defined FEA geometry is fingerprinted by its existing worker.
    root=Path(source).resolve()
    if not root.is_dir():raise ValueError('Native source case directory missing')
    rows=[]
    for path in sorted(root.rglob('*')):
        if path.is_symlink():raise ValueError('Source case symlinks require a reviewed materialized copy')
        if path.is_file():
            rows.append({'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
            if len(rows)>10000:raise ValueError('Source case exceeds bounded input custody scope')
    if not rows:raise ValueError('Empty native source case')
    return {'root':str(root),'files':rows,'sha256':digest(rows)}

CONTRACT_SCHEMA={
 '$schema':'https://json-schema.org/draft/2020-12/schema','title':'Aero Engineering Contract v1','type':'object',
 'additionalProperties':False,
 'required':['schema','contract_id','version','engineering','backend','model','checks','domains','acceptance_criteria','mutation_policy','baseline_requests','budget'],
 'properties':{
  'schema':{'const':'aero.engineering_contract.v1'},'contract_id':{'type':'string','pattern':'^[A-Za-z0-9_-]{1,80}$'},
  'version':{'type':'integer','minimum':1},'parent_sha256':{'type':['string','null']},'revision_reason':{'type':'string','minLength':10},
  'engineering':{'type':'object','required':list(ENGINEERING_FIELDS),'properties':{k:{'type':['string','object','array'],'minLength':1,'minItems':1,'minProperties':1} for k in ENGINEERING_FIELDS}},
  'backend':{'enum':['openfoam','calculix']},'model':{'type':'object','minProperties':1},
  'domains':{'type':'object','additionalProperties':{'type':'object','required':['applicable','rationale'],'properties':{'applicable':{'type':'boolean'},'rationale':{'type':'string','minLength':5}}}},
  'checks':{'type':'array','minItems':1,'items':{'type':'object','required':['id','domain','kind','required','units','requirement'],
    'properties':{'id':{'type':'string','minLength':1},'domain':{'enum':list(DOMAINS)},'kind':{'enum':list(KINDS)},'required':{'type':'boolean'},'units':{'type':'string'},'requirement':{'type':'string','minLength':1}}}},
  'acceptance_criteria':{'type':'array','minItems':1,'uniqueItems':True,'items':{'type':'string'}},
  'mutation_policy':{'type':'object','additionalProperties':{'type':'object','required':['authority','reason'],'properties':{
   'authority':{'enum':['LOCKED','AGENT_ADJUSTABLE','HUMAN_APPROVAL_REQUIRED']},'reason':{'type':'string','minLength':5}}}},
  'baseline_requests':{'type':'array','items':{'type':'object','required':['id','tool','inputs','output','units','plausible_fraction','applicability','confidence'],'properties':{
   'tool':{'enum':list(TOOLS)},'inputs':{'type':'object'},'applicability':{'type':'string','minLength':5},'confidence':{'enum':['low','medium','high']}}}},
  'baseline_unavailable_reason':{'type':['string','null']},
  'physics_ai_policy':{'type':'object','additionalProperties':False,'required':['allowed_models','optional_experiments'],'properties':{
   'allowed_models':{'type':'array','minItems':1,'uniqueItems':True,'items':{'type':'string','minLength':1}},
   'optional_experiments':{'type':'array','items':{'type':'object','additionalProperties':False,
    'required':['id','hypothesis_id','quantity','units','expected_lower','expected_upper','minimum_margin','mutation_path','required'],
    'properties':{'id':{'type':'string','minLength':1},'hypothesis_id':{'type':'string','minLength':1},
     'quantity':{'type':'string','minLength':1},'units':{'type':'string','minLength':1},
     'expected_lower':{'type':'number'},'expected_upper':{'type':'number'},'minimum_margin':{'type':'number','exclusiveMinimum':0},
     'mutation_path':{'type':'string'},'required':{'const':False}}}}}},
  'budget':{'type':'object','required':['max_runs','max_wall_seconds'],'properties':{'max_runs':{'type':'integer','minimum':1,'maximum':20},'max_wall_seconds':{'type':'number','exclusiveMinimum':0,'maximum':86400}}}
 }}
GATE_SCHEMA={'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object',
 'required':['schema','engineering_validity','overall_disposition','recommended_action','checks','contract_sha256','evidence_sha256'],
 'properties':{'schema':{'const':'ENGINEERING_VALIDITY_GATE.v1'},
 'engineering_validity':{'type':'object','required':list(DOMAINS),'properties':{d:{'enum':list(STATES)} for d in DOMAINS}},
 'overall_disposition':{'enum':['PASS','PASS_WITH_ANOMALY','INCONCLUSIVE','FAIL']},
 'recommended_action':{'enum':['ACCEPT','COLLECT_MORE_EVIDENCE','RUN_DISCRIMINATING_TEST','NUMERICAL_ADJUSTMENT','MODEL_FORM_INVESTIGATION','HUMAN_REVIEW','BLOCK']}}}
