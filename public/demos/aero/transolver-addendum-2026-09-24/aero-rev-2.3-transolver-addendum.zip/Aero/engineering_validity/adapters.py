"""Thin custody/dispatch adapters; all numerical work stays in existing workers."""
import copy
import hashlib
import json
from pathlib import Path
from .contracts import digest,pointer,differences

ENGINEERING_DISPATCH_PERMIT=object() # not expressible as an HTTP/LLM JSON flag

def raw_records(root,run_id,contract,allowed_files):
    records={}
    for check in contract['checks']:
        source=check.get('source')
        if not source:continue
        try:
            relative=source['file'];path=(root/relative).resolve();path.relative_to(root.resolve())
            if relative not in allowed_files or not path.is_file():continue
            value=pointer(json.loads(path.read_text(encoding='utf-8')),source['pointer'])
            records[check['id']]={'value':value,'units':check['units'],'run_id':run_id,
                'provenance':'CALCULATED','sources':[{'path':relative,'pointer':source['pointer'],
                'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}]}
        except (OSError,ValueError,KeyError,TypeError):continue
    return records

class OpenFOAMAdapter:
    def __init__(self,pipeline):self.pipeline=pipeline
    def start(self,model,*,campaign_id,contract_sha256):
        spec=copy.deepcopy(model)
        for key in ('spec_id','created_at','updated_at'):spec.pop(key,None)
        spec['engineering_control']={'campaign_id':campaign_id,'contract_sha256':contract_sha256,'model_sha256':digest(model)}
        created=self.pipeline.create_spec(spec)
        if not created.get('ok'):raise RuntimeError('Existing OpenFOAM specification rejected')
        metadata={'spec_id','schema','created_at','updated_at','engineering_readiness','spec_validation','engineering_control'}
        frozen={k:v for k,v in model.items() if k not in metadata}
        effective={k:v for k,v in created['spec'].items() if k not in metadata}
        if differences(frozen,effective):raise RuntimeError('Frozen model is incomplete or changed by backend defaults; freeze the complete exported specification first')
        launched=self.pipeline.start_run(created['spec']['spec_id'],_engineering_permit=ENGINEERING_DISPATCH_PERMIT)
        if not launched.get('ok'):raise RuntimeError('Existing OpenFOAM preflight rejected')
        return {'run_id':launched['run_id'],'spec_id':created['spec']['spec_id'],'model_sha256':digest(model)}
    def status(self,reference):
        state=self.pipeline.get_run(reference['run_id'])
        return {'terminal':state.get('status') in ('completed','failed','cancelled','timed_out','interrupted'), 'state':state.get('status')}
    def extract(self,reference,contract,model):
        run_id=reference['run_id'];root=self.pipeline._run_dir(run_id)
        verified=self.pipeline.verify_evidence_manifest(run_id)
        if verified.get('file_count',0)==0:verified=dict(verified,ok=False,error='empty_manifest')
        manifest_path=root/'evidence_manifest.json'
        manifest=json.loads(manifest_path.read_text()) if manifest_path.is_file() else {}
        allowed={r['relative_path'] for r in manifest.get('files',[])} if verified.get('ok') and verified.get('file_count',0)>0 else set()
        state=self.pipeline.get_run(run_id)
        records=raw_records(root,run_id,contract,allowed)
        # Preserve every existing required gate. The new layer cannot waive it.
        existing=state.get('gate_evaluation',{}).get('gates',[])
        blockers=[r for r in existing if r.get('required') and r.get('passed') is not True]
        if not existing:blockers.append({'name':'existing_numerical_qualification','passed':None})
        return {'run_id':run_id,'model_sha256':reference['model_sha256'],'records':records,
            'manifest_verification':verified,'existing_required_blockers':blockers,
            'source_configuration':{'spec_sha256':state.get('input_spec_sha256'),'case_manifest_sha256':state.get('input_case_manifest_sha256'),
                'solver':model.get('numerics',{}).get('solver'),'run_created_at':state.get('created_at')},
            'execution_completed':state.get('status')=='completed','extractor':'Aero.engineering_validity.adapters.OpenFOAMAdapter',
            'extractor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},root

class CalculixAdapter:
    def __init__(self,controller):self.controller=controller
    def start(self,model,*,campaign_id,contract_sha256):
        built=self.controller.build(model)
        return {'case_id':built['case_id'],'model_sha256':digest(model),'fingerprint':built['case']['fingerprint'],
            'approval_route':'/tools/aero/structural/approve','campaign_id':campaign_id}
    def status(self,reference):
        cid=reference['case_id'];state=self.controller.status(cid)['state']
        if state=='PROPOSED':
            file=self.controller.path(cid)/'approval.json'
            approval=json.loads(file.read_text()) if file.is_file() else {}
            if approval.get('fingerprint')!=reference['fingerprint'] or approval.get('authority')!='human_ui':
                return {'terminal':False,'needs_human':True,'state':'EXACT_FEA_APPROVAL_REQUIRED'}
            if self.controller.preflight(cid)['status']!='PASS':self.controller.prepare(cid,'mesh')
            self.controller.run(cid,approval=reference['fingerprint'])
            state=self.controller.status(cid)['state']
        return {'terminal':state in ('COMPLETE','COMPLETE_WITH_OPEN_GATES','FAILED','TIMED_OUT'),'state':state}
    def extract(self,reference,contract,model):
        cid=reference['case_id'];root=self.controller.path(cid);case=self.controller.case(cid)
        allowed=set();verified=True
        for level in case['mesh_levels']:
            try:
                manifest=self.controller.verified_manifest(cid,'solve',level)
                allowed.update('solve-'+level+'/'+name for name in manifest['artifacts'])
            except (ValueError,OSError,RuntimeError):verified=False
        result=self.controller.results(cid)
        existing=result.get('evidence',{})
        return {'run_id':cid,'model_sha256':reference['model_sha256'],
            'records':raw_records(root,cid,contract,allowed), 'manifest_verification':{'ok':verified},
            'existing_required_blockers':[{'name':k,'passed':False if v=='FAIL' else None} for k,v in existing.items() if isinstance(v,str) and v not in ('PASS','NOT_APPLICABLE')],
            'execution_completed':self.controller.status(cid)['state'] in ('COMPLETE','COMPLETE_WITH_OPEN_GATES'),
            'source_configuration':{'case_fingerprint':case['fingerprint'],'worker_image':self.controller.image},
            'extractor':'Aero.engineering_validity.adapters.CalculixAdapter'},root
