"""Independent deterministic assessment. No model, solver launch or PASS setters."""
from pathlib import Path
import hashlib
import math
import json
from statistics import mean
from .contracts import DOMAINS, digest, number, differences, mutation_class, pointer
from Aero.cfd.evidence import EvidenceItem, GateStatus, Provenance, aggregate_numerical

def aggregate(states):
    if 'FAIL' in states:return 'FAIL'
    if not states or any(s in ('NOT_ESTABLISHED','INCONCLUSIVE') for s in states):return 'NOT_ESTABLISHED'
    if 'PASS_WITH_ANOMALY' in states:return 'PASS_WITH_ANOMALY'
    # Reuse Aero's conservative required-gate aggregation.
    items=[EvidenceItem(str(i),GateStatus.PASS,True,Provenance.DERIVED,'verified check') for i in range(len(states))]
    return aggregate_numerical(items).value

def custody(record,root,run_id):
    if record.get('run_id')!=run_id or record.get('provenance') not in ('OBSERVED','CALCULATED'):
        return False,'Missing/wrong run or non-observational evidence'
    if not record.get('sources'):return False,'Source custody missing'
    root=Path(root).resolve()
    for source in record['sources']:
        try:
            path=(root/source['path']).resolve()
            path.relative_to(root)
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=source['sha256']:
                return False,'Source missing or hash mismatch'
            if source is record['sources'][0]:
                extracted=pointer(json.loads(path.read_text(encoding='utf-8')),source['pointer'])
                if digest(extracted)!=digest(record['value']):return False,'Value does not match retained source'
        except (OSError,KeyError,ValueError,TypeError):return False,'Invalid source reference'
    return True,'Source hashes verified'

def flatten(value):
    if isinstance(value,list):return [x for part in value for x in flatten(part)]
    return [number(value)]

def compute(check,data,baseline):
    kind=check['kind']; limit=check.get('limit')
    if kind=='review':
        # Only controller-authenticated, hash-bound independent review receipts.
        if data.get('_verified_human_review') is not True:return 'NOT_ESTABLISHED',None,'Independent review required'
        return data['status'],None,data['rationale']
    if kind=='limit':value=number(data)
    elif kind=='range':
        values=flatten(data)
        if not values:raise ValueError('Empty range')
        passed=all(check['lower']<=v<=check['upper'] for v in values)
        return 'PASS' if passed else 'FAIL',{'minimum':min(values),'maximum':max(values)},'Declared physical/property range'
    elif kind=='balance':
        terms=flatten(data['signed_terms']); scale=number(data['throughput_scale'])
        if not terms or scale<=0:raise ValueError('Signed balance terms and positive throughput required')
        # Terms must explicitly include accumulation/storage when applicable.
        if data['term_names']!=check['term_names'] or len(terms)!=len(data['term_names']):raise ValueError('Balance coverage mismatch')
        value=abs(math.fsum(terms))/scale
    elif kind=='history':
        values=flatten(data['values']); times=flatten(data['times']); n=check['samples']
        if len(values)!=len(times) or len(values)<n or any(b<=a for a,b in zip(times,times[1:])):raise ValueError('Incomplete/nonchronological window')
        values=values[-n:]; value=(max(values)-min(values))/check['scale']
    elif kind=='field_delta':
        if data['before_ids']!=data['after_ids'] or not data['before_ids']:raise ValueError('Field topology correspondence required')
        a,b=flatten(data['before']),flatten(data['after'])
        if len(a)!=len(b) or not a or len(data['before'])!=len(data['before_ids']) or len(data['after'])!=len(data['after_ids']):raise ValueError('Field coverage mismatch')
        if len(set(data['before_ids']))!=len(data['before_ids']) or any(len(flatten(x))!=len(flatten(y)) for x,y in zip(data['before'],data['after'])):raise ValueError('Field topology/component mismatch')
        value=math.sqrt(math.fsum((x-y)**2 for x,y in zip(a,b))/len(a))/check['scale']
    elif kind=='envelope':
        expected=baseline['predictions'][check['baseline_id']]
        value=number(data)
        if check['units']!=expected['units']:raise ValueError('Envelope units mismatch')
        if expected['lower']<=value<=expected['upper']:return 'PASS',value,'Inside independent pre-run envelope; not proof of validation'
        return 'PASS_WITH_ANOMALY',value,'Outside analytical approximation: competing hypotheses and independent review required; real physics remains possible'
    elif kind=='correlation':
        if data['model_configuration_hash']!=data['test_configuration_hash'] or data['model_locations']!=data['sensor_locations'] or data['model_times']!=data['measurement_times']:
            return 'NOT_ESTABLISHED',None,'Model/test configuration or spatial/temporal alignment not established'
        predicted=flatten(data['predicted']); measured=flatten(data['measured']); uncertainty=flatten(data['combined_uncertainty'])
        if len(predicted)<check.get('minimum_observables',2) or not len(predicted)==len(measured)==len(uncertainty) or any(u<=0 for u in uncertainty):raise ValueError('Multiple matched observables with positive uncertainty required')
        value=max(abs(p-m)/u for p,m,u in zip(predicted,measured,uncertainty))
    elif kind=='mesh':
        # A JSON claim of per-grid eligibility is not verified qualification.
        # Existing backend mesh qualification remains authoritative; this generic
        # cross-campaign hook is deliberately unavailable pending a profile adapter.
        return 'NOT_ESTABLISHED',None,'Use existing qualified mesh-comparison workflow; generic per-grid eligibility is not established'
    else:raise ValueError('Unsupported calculation')
    return ('PASS' if value<=limit else 'FAIL'),value,'Deterministic '+kind+' against frozen limit'

def evaluate(contract,baseline,evidence,root,current_model,*,review_receipts=None):
    rows=[]; provenance=[]; review_receipts=review_receipts or {}
    for check in contract['checks']:
        row={'id':check['id'],'domain':check['domain'],'required':check['required'],
             'status':'NOT_ESTABLISHED','value':None,'units':check['units'],'requirement':check['requirement'],
             'definition':check,'provenance':'UNESTABLISHED'}
        record=evidence.get('records',{}).get(check['id'])
        if record:
            valid,reason=custody(record,root,evidence.get('run_id'))
            provenance.append(valid)
            row.update(sources=record.get('sources',[]),reason=reason)
            if valid and record.get('units')==check['units']:
                try:
                    data=record['value']
                    if check['kind']=='review':
                        data={} # Never trust a self-asserted review flag in solver evidence.
                        receipt=review_receipts.get(check['id'],{})
                        if receipt.get('evidence_sha256')==digest(evidence) and receipt.get('contract_sha256')==digest(contract):
                            data=dict(receipt,_verified_human_review=True)
                    status,value,reason=compute(check,data,baseline)
                    row.update(status=status,value=value,reason=reason,provenance='CALCULATED',
                        source_provenance=record['provenance'])
                except (KeyError,ValueError,TypeError,ZeroDivisionError,OverflowError):row['reason']='Required raw values or calculation semantics missing/invalid'
            elif valid:row['reason']='Units differ from frozen check definition'
        else:row['reason']='Required evidence not retained/extracted'
        rows.append(row)
    statuses={}
    for domain in DOMAINS:
        applicable=contract['domains'][domain]['applicable']
        statuses[domain]=aggregate([r['status'] for r in rows if r['domain']==domain and r['required']]) if applicable else 'NOT_APPLICABLE'
    drift=differences(contract['model'],current_model,'/model')
    physical=[r for r in drift if mutation_class(r['path'])=='C']
    statuses['requirement_alignment']='FAIL' if physical else 'PASS'
    statuses['assumption_drift_status']='FAIL' if physical else 'PASS'
    statuses['evidence_status']='PASS' if rows and all(r['status']!='NOT_ESTABLISHED' for r in rows if r['required']) and all(provenance) and provenance else 'NOT_ESTABLISHED'
    if evidence.get('model_sha256')!=digest(current_model) or baseline.get('contract_sha256')!=digest(contract):
        statuses['requirement_alignment']='FAIL'; statuses['evidence_status']='FAIL'
    if evidence.get('manifest_verification',{}).get('ok') is not True and statuses['evidence_status']!='FAIL':
        statuses['evidence_status']='NOT_ESTABLISHED'
    if evidence.get('execution_completed') is not True:
        statuses['numerical_status']='FAIL'
    blockers=evidence.get('existing_required_blockers',[])
    if blockers:
        existing_status='FAIL' if any(b.get('passed') is False for b in blockers) else 'NOT_ESTABLISHED'
        statuses['numerical_status']=aggregate([statuses['numerical_status'],existing_status])
    active=[s for s in statuses.values() if s!='NOT_APPLICABLE']
    disposition='FAIL' if 'FAIL' in active else 'INCONCLUSIVE' if any(s in ('NOT_ESTABLISHED','INCONCLUSIVE') for s in active) else 'PASS_WITH_ANOMALY' if 'PASS_WITH_ANOMALY' in active else 'PASS'
    action='ACCEPT' if disposition=='PASS' else 'HUMAN_REVIEW' if physical else 'RUN_DISCRIMINATING_TEST' if disposition in ('FAIL','PASS_WITH_ANOMALY') else 'COLLECT_MORE_EVIDENCE'
    if statuses['evidence_status']=='FAIL':action='BLOCK'
    return {'schema':'ENGINEERING_VALIDITY_GATE.v1','engineering_validity':statuses,
        'overall_disposition':disposition,'recommended_action':action,'checks':rows,
        'contract_sha256':digest(contract),'baseline_sha256':digest(baseline),'evidence_sha256':digest(evidence),
        'run_id':evidence.get('run_id'),'assumption_changes':drift,
        'existing_required_blockers':blockers,
        'qualification_override':False,'interpretation':'Numerical and physical axes are independent. An anomaly is not a physics violation or release approval.'}
