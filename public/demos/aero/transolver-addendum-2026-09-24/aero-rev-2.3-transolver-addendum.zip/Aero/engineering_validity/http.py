"""Private-only authenticated API. Human freeze/review share existing approval policy."""
import json
import threading
from pathlib import Path
from flask import Blueprint,jsonify,request
from jsonschema import ValidationError
from .contracts import CONTRACT_SCHEMA,GATE_SCHEMA
from Aero.core.approval_policy import human_approval_authorized

def install(app,profile,authorized,controller_factory):
    if profile!='lab':return
    bp=Blueprint('engineering_validity',__name__,url_prefix='/engineering-validity')
    runners={};mutex=threading.Lock()
    @bp.before_request
    def guard():
        denied,status=authorized()
        if denied is not None:return denied,status
        if (request.content_length or 0)>262144:return jsonify(error='bounded_payload_required'),413
        origin=request.headers.get('Origin')
        if origin and origin not in ('https://your-aero-host.example','http://127.0.0.1:5213','http://localhost:5213'):
            return jsonify(error='origin_not_allowed'),403
    @bp.after_request
    def no_cache(response):response.headers['Cache-Control']='no-store';return response
    @bp.errorhandler(ValueError)
    @bp.errorhandler(ValidationError)
    def invalid(exc):return jsonify(error='contract_rejected',reason=str(exc)[:500]),422
    @bp.errorhandler(FileNotFoundError)
    def missing(exc):return jsonify(error='campaign_not_found'),404
    @bp.errorhandler(RuntimeError)
    def blocked(exc):return jsonify(error='campaign_blocked',reason=str(exc)[:500]),409
    def body(keys):
        value=request.get_json(silent=True)
        if not isinstance(value,dict) or set(value)!=set(keys):raise ValueError('Exact payload fields required: '+','.join(keys))
        return value
    @bp.get('/status')
    def status():
        return jsonify(revision='2.2-local',gate='ENGINEERING_VALIDITY_GATE',
            campaigns=controller_factory().list(),human_approval_configured=human_approval_authorized_configuration(),
            authority='managed campaigns only; no historical rescoring; no flight/design release',
            automatic_hypothesis_generation=False)
    @bp.get('/schemas')
    def schemas():return jsonify(engineering_contract=CONTRACT_SCHEMA,engineering_validity_gate=GATE_SCHEMA)
    @bp.get('/report')
    def report():
        path=Path(__file__).resolve().parents[1]/'docs/ENGINEERING_VALIDITY_GATE.md'
        return jsonify(markdown=path.read_text(encoding='utf-8') if path.exists() else 'Implementation verification in progress.')
    @bp.post('/campaigns')
    def create():return jsonify(controller_factory().create(body(['contract'])['contract'])),201
    @bp.get('/campaigns/<cid>')
    def get(cid):return jsonify(controller_factory().get(cid))
    @bp.post('/campaigns/<cid>/freeze')
    def freeze(cid):
        if not human_approval_authorized(request.headers):return jsonify(error='separate_human_approval_required'),403
        return jsonify(controller_factory().freeze(cid,body(['fingerprint'])['fingerprint']))
    @bp.post('/campaigns/<cid>/diagnosis')
    def diagnosis(cid):return jsonify(controller_factory().diagnose(cid,body(['diagnosis'])['diagnosis']))
    @bp.post('/campaigns/<cid>/proposal')
    def proposal(cid):return jsonify(controller_factory().propose(cid,body(['proposal'])['proposal']))
    @bp.post('/campaigns/<cid>/review')
    def review(cid):
        if not human_approval_authorized(request.headers):return jsonify(error='separate_human_approval_required'),403
        value=body(['check_id','status','rationale','fingerprint'])
        return jsonify(controller_factory().review(cid,**value))
    @bp.post('/campaigns/<cid>/tick')
    def tick(cid):
        body([]);return jsonify(controller_factory().tick(cid))
    @bp.post('/campaigns/<cid>/run-bounded')
    def run_bounded(cid):
        body([]);controller=controller_factory();row=controller.get(cid)
        if row['state'] not in ('READY','READY_NEXT','RUNNING'):raise ValueError('A frozen authorized campaign and actionable state are required')
        with mutex:
            if cid in runners and runners[cid][0].is_alive():raise RuntimeError('Campaign loop already active')
            stop=threading.Event()
            def work():
                try:controller.run_bounded(cid,stop)
                except Exception as exc:
                    app.logger.exception('Engineering campaign control stopped: %s',cid)
                    controller.record_loop_failure(cid,type(exc).__name__)
            thread=threading.Thread(target=work,name='engineering-validity-'+cid,daemon=True)
            runners[cid]=(thread,stop);thread.start()
        return jsonify(campaign_id=cid,status='CONTROL_LOOP_STARTED'),202
    @bp.post('/campaigns/<cid>/stop-loop')
    def stop(cid):
        body([])
        with mutex:
            if cid in runners:runners[cid][1].set()
        return jsonify(state='NO_FURTHER_TICKS',note='Does not cancel an active solver; use its existing cancel control.')
    app.register_blueprint(bp)

def human_approval_authorized_configuration():
    import os
    return len(str(os.getenv('AERO_GUIDANCE_APPROVAL_TOKEN') or ''))>=32

_instance=None
_instance_lock=threading.Lock()
def controller():
    global _instance
    with _instance_lock:
        if _instance is None:
            import os
            from Aero.openfoam_pipeline import get_pipeline
            from Aero.fea.bounded.controller import Controller
            from .controller import CampaignController
            from .adapters import OpenFOAMAdapter,CalculixAdapter
            pipeline=get_pipeline()
            root=Path(os.getenv('AERO_ENGINEERING_VALIDITY_ROOT') or str(pipeline.root/'engineering_validity'))
            # Same bounded FEA directory as the private app integration.
            fea_root=Path(__file__).resolve().parents[1]/'outputs/bounded_fea'
            _instance=CampaignController(root,{'openfoam':OpenFOAMAdapter(pipeline),
                'calculix':CalculixAdapter(Controller(fea_root,os.getenv('AERO_FEA_WORKER_IMAGE_ID') or None))})
        return _instance
