"""Evidence-driven engineering control; no solver or model executes on import."""
