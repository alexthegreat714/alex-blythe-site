"""Aero's dependency-light first-principles engineering kernel.

The package is deliberately small and deterministic.  It is the numerical
authority for preliminary checks; language models may explain its output but
must not replace it with invented arithmetic.  Solver adapters (OpenFOAM,
CalculiX, Fluent, etc.) remain separate so a screening result cannot be
mistaken for a resolved or validated analysis.
"""

from .kernel import (
    TOOLKIT_VERSION,
    channel_pressure_loss,
    compare_scalar,
    nozzle_first_order,
    pressure_vessel_screen,
    study_plan,
    thermal_sensible_heat,
    toolkit_catalog,
)

__all__ = [
    "TOOLKIT_VERSION",
    "channel_pressure_loss",
    "compare_scalar",
    "nozzle_first_order",
    "pressure_vessel_screen",
    "study_plan",
    "thermal_sensible_heat",
    "toolkit_catalog",
]
