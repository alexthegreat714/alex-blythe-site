"""Deterministic, SI-unit first-principles checks for Aero.

This module intentionally has no network, filesystem, subprocess, solver, or
LLM dependency.  Every public function accepts a JSON-like mapping and returns
JSON-like data.  That makes it safe to expose through the local MCP registry
and portable to AeroLite on a work laptop.

These are preliminary screens, not certification analyses.  The result
payload says which assumptions and validity limits were used so an assistant
can teach from the calculation without over-claiming what it proves.
"""

from __future__ import annotations

import math
from typing import Any, Mapping


TOOLKIT_VERSION = "aero-engineering-toolkit-v1"
_RESULT_SCHEMA = "aero_engineering_result_v1"


class InputError(ValueError):
    """Raised internally for a malformed or physically invalid input."""


def _payload(payload: Mapping[str, Any] | None) -> dict[str, Any]:
    return dict(payload or {})


def _number(
    values: Mapping[str, Any],
    key: str,
    *,
    minimum: float | None = None,
    maximum: float | None = None,
    required: bool = True,
    default: float | None = None,
) -> float | None:
    raw = values.get(key, default)
    if raw is None and not required:
        return None
    if isinstance(raw, bool):
        raise InputError(f"{key} must be a finite number")
    try:
        value = float(raw)
    except (TypeError, ValueError) as exc:
        raise InputError(f"{key} must be a finite number") from exc
    if not math.isfinite(value):
        raise InputError(f"{key} must be finite")
    if minimum is not None and value < minimum:
        raise InputError(f"{key} must be >= {minimum:g}")
    if maximum is not None and value > maximum:
        raise InputError(f"{key} must be <= {maximum:g}")
    return value


def _base(tool: str, inputs: dict[str, Any], results: dict[str, Any], decision: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": True,
        "schema": _RESULT_SCHEMA,
        "tool": tool,
        "toolkit_version": TOOLKIT_VERSION,
        "authority": "deterministic_python_kernel",
        "inputs": inputs,
        "results": results,
        "decision": decision,
    }


def _invalid(tool: str, exc: Exception, payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return {
        "ok": False,
        "schema": _RESULT_SCHEMA,
        "tool": tool,
        "toolkit_version": TOOLKIT_VERSION,
        "authority": "deterministic_python_kernel",
        "inputs": dict(payload or {}),
        "error": "invalid_input",
        "detail": str(exc),
    }


def _safe_call(tool: str, payload: Mapping[str, Any] | None, function):
    try:
        return function(_payload(payload))
    except InputError as exc:
        return _invalid(tool, exc, payload)


def _solve_mach_from_area_ratio(area_ratio: float, gamma: float, branch: str) -> float:
    """Solve the isentropic area-Mach relation by bounded bisection."""
    if area_ratio < 1.0:
        raise InputError("exit_area_ratio must be >= 1")
    if math.isclose(area_ratio, 1.0, rel_tol=0.0, abs_tol=1e-12):
        return 1.0

    def area_mach(mach: float) -> float:
        term = (2.0 / (gamma + 1.0)) * (1.0 + (gamma - 1.0) * mach * mach / 2.0)
        return (term ** ((gamma + 1.0) / (2.0 * (gamma - 1.0)))) / mach

    branch = branch.strip().lower()
    if branch == "subsonic":
        lo, hi = 1e-8, 1.0
    elif branch == "supersonic":
        lo, hi = 1.0, 50.0
        while area_mach(hi) < area_ratio and hi < 1e5:
            hi *= 2.0
    else:
        raise InputError("branch must be 'subsonic' or 'supersonic'")

    increasing = branch == "supersonic"
    for _ in range(100):
        mid = (lo + hi) / 2.0
        value = area_mach(mid)
        if abs(value - area_ratio) <= 1e-11 * max(1.0, area_ratio):
            return mid
        if increasing:
            if value < area_ratio:
                lo = mid
            else:
                hi = mid
        else:
            if value > area_ratio:
                lo = mid
            else:
                hi = mid
    return (lo + hi) / 2.0


def _nozzle_first_order_impl(values: dict[str, Any]) -> dict[str, Any]:
    p0 = _number(values, "total_pressure_pa", minimum=1.0)
    t0 = _number(values, "total_temperature_k", minimum=1.0)
    throat_area = _number(values, "throat_area_m2", minimum=1e-16)
    gamma = _number(values, "gamma", minimum=1.01, maximum=2.0)
    gas_constant = _number(values, "gas_constant_j_kg_k", minimum=1.0)
    area_ratio = _number(values, "exit_area_ratio", minimum=1.0, default=1.0)
    back_pressure = _number(values, "back_pressure_pa", minimum=0.0, required=False)
    branch = str(values.get("branch") or "supersonic")
    exit_mach = _solve_mach_from_area_ratio(area_ratio, gamma, branch)
    critical_ratio = (2.0 / (gamma + 1.0)) ** (gamma / (gamma - 1.0))
    critical_pressure = p0 * critical_ratio
    choked_mass_flow = (
        p0
        * throat_area
        * math.sqrt(gamma / (gas_constant * t0))
        * (2.0 / (gamma + 1.0)) ** ((gamma + 1.0) / (2.0 * (gamma - 1.0)))
    )
    exit_static_pressure_ratio = (1.0 + (gamma - 1.0) * exit_mach**2 / 2.0) ** (-gamma / (gamma - 1.0))
    exit_static_temperature_ratio = (1.0 + (gamma - 1.0) * exit_mach**2 / 2.0) ** -1.0
    exit_pressure = p0 * exit_static_pressure_ratio
    exit_temperature = t0 * exit_static_temperature_ratio
    mach_choked = back_pressure is None or back_pressure <= critical_pressure
    pressure_disposition = "not_evaluated" if back_pressure is None else ("choking_expected" if mach_choked else "unchoked_or_not_choked")
    return _base(
        "aero.math.nozzle_first_order",
        {
            "total_pressure_pa": p0,
            "total_temperature_k": t0,
            "throat_area_m2": throat_area,
            "gamma": gamma,
            "gas_constant_j_kg_k": gas_constant,
            "exit_area_ratio": area_ratio,
            "branch": branch.strip().lower(),
            "back_pressure_pa": back_pressure,
        },
        {
            "critical_pressure_ratio_pstar_over_p0": critical_ratio,
            "critical_back_pressure_pa": critical_pressure,
            "choked_mass_flow_kg_s": choked_mass_flow,
            "exit_mach": exit_mach,
            "exit_static_pressure_pa": exit_pressure,
            "exit_static_temperature_k": exit_temperature,
            "exit_static_pressure_ratio": exit_static_pressure_ratio,
            "exit_static_temperature_ratio": exit_static_temperature_ratio,
        },
        {
            "status": "screening_only",
            "choking": pressure_disposition,
            "warnings": [
                "Isentropic, calorically perfect gas, quasi-one-dimensional estimate only.",
                "Does not establish thrust, boundary-condition correctness, shock structure, heat transfer, or design readiness.",
                "Use a compressible CFD solver and independent mass/energy checks for the next fidelity level.",
            ],
            "evidence_gates": ["input provenance", "solver comparison", "mesh/convergence evidence", "mass-flow and energy balance"],
        },
    )


def nozzle_first_order(payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return _safe_call("aero.math.nozzle_first_order", payload, _nozzle_first_order_impl)


def _channel_pressure_loss_impl(values: dict[str, Any]) -> dict[str, Any]:
    width = _number(values, "width_m", minimum=1e-9)
    height = _number(values, "height_m", minimum=1e-9)
    length = _number(values, "length_m", minimum=1e-9)
    mass_flow = _number(values, "mass_flow_kg_s", minimum=0.0)
    density = _number(values, "density_kg_m3", minimum=1e-12)
    viscosity = _number(values, "dynamic_viscosity_pa_s", minimum=1e-15)
    budget = _number(values, "pressure_budget_pa", minimum=0.0, required=False)
    area = width * height
    hydraulic_diameter = 2.0 * width * height / (width + height)
    velocity = mass_flow / (density * area)
    reynolds = density * velocity * hydraulic_diameter / viscosity
    if reynolds == 0.0:
        friction_factor = 0.0
        regime = "no_flow"
    elif reynolds < 2300.0:
        friction_factor = 64.0 / reynolds
        regime = "laminar"
    elif reynolds < 10000.0:
        friction_factor = 0.3164 / reynolds**0.25
        regime = "transitional"
    else:
        friction_factor = 0.3164 / reynolds**0.25
        regime = "turbulent_screen"
    pressure_drop = friction_factor * (length / hydraulic_diameter) * 0.5 * density * velocity**2
    budget_state = "not_evaluated" if budget is None else ("pass" if pressure_drop <= budget else "fail")
    warnings = [
        "Hydraulic-diameter friction estimate: laminar 64/Re is a circular-pipe surrogate, not the exact rectangular-duct correlation.",
        "Entrance effects, bends, manifolds, roughness, compressibility, and local losses are excluded.",
    ]
    if regime == "transitional":
        warnings.append("Transitional flow: treat this correlation as a sensitivity screen, not a validated prediction.")
    if regime == "turbulent_screen":
        warnings.append("Blasius is a smooth-wall screening correlation; use a roughness-aware model or CFD when needed.")
    return _base(
        "aero.math.channel_pressure_loss",
        {
            "width_m": width,
            "height_m": height,
            "length_m": length,
            "mass_flow_kg_s": mass_flow,
            "density_kg_m3": density,
            "dynamic_viscosity_pa_s": viscosity,
            "pressure_budget_pa": budget,
        },
        {
            "area_m2": area,
            "hydraulic_diameter_m": hydraulic_diameter,
            "velocity_m_s": velocity,
            "reynolds": reynolds,
            "regime": regime,
            "darcy_friction_factor": friction_factor,
            "pressure_drop_pa": pressure_drop,
            "pumping_power_w": pressure_drop * mass_flow / density,
        },
        {
            "status": "screening_only" if budget_state == "not_evaluated" else ("screening_pass" if budget_state == "pass" else "screening_review"),
            "pressure_budget": budget_state,
            "warnings": warnings,
            "evidence_gates": ["geometry and fluid-property provenance", "mesh study", "mass-flow/pressure balance", "reference or test comparison"],
        },
    )


def channel_pressure_loss(payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return _safe_call("aero.math.channel_pressure_loss", payload, _channel_pressure_loss_impl)


def _pressure_vessel_screen_impl(values: dict[str, Any]) -> dict[str, Any]:
    pressure = _number(values, "internal_pressure_pa", minimum=0.0)
    radius = _number(values, "internal_radius_m", minimum=1e-9)
    thickness = _number(values, "wall_thickness_m", minimum=1e-12)
    allowable = _number(values, "allowable_stress_pa", minimum=1e-12)
    safety_factor = _number(values, "safety_factor", minimum=1.0, default=1.0)
    joint_efficiency = _number(values, "joint_efficiency", minimum=1e-6, maximum=1.0, default=1.0)
    thin_wall = thickness <= radius / 10.0
    hoop = pressure * radius / thickness / joint_efficiency
    longitudinal = hoop / 2.0
    allowable_design = allowable / safety_factor
    hoop_margin = allowable_design / hoop - 1.0 if hoop else None
    longitudinal_margin = allowable_design / longitudinal - 1.0 if longitudinal else None
    status = "screening_pass" if thin_wall and hoop <= allowable_design else ("screening_review" if thin_wall else "needs_thick_wall_model")
    warnings = [
        "Thin-wall pressure-vessel membrane screen only; local discontinuities, bending, supports, fatigue, buckling, and thermal stress are excluded.",
        "The result is not a code compliance claim or a release authorization.",
    ]
    if not thin_wall:
        warnings.insert(0, "t/r exceeds 0.1; use a thick-wall solution or FEA before interpreting stress.")
    return _base(
        "aero.math.pressure_vessel_screen",
        {
            "internal_pressure_pa": pressure,
            "internal_radius_m": radius,
            "wall_thickness_m": thickness,
            "allowable_stress_pa": allowable,
            "safety_factor": safety_factor,
            "joint_efficiency": joint_efficiency,
        },
        {
            "thickness_to_radius": thickness / radius,
            "hoop_stress_pa": hoop,
            "longitudinal_stress_pa": longitudinal,
            "design_allowable_stress_pa": allowable_design,
            "hoop_margin": hoop_margin,
            "longitudinal_margin": longitudinal_margin,
        },
        {
            "status": status,
            "thin_wall_assumption_valid": thin_wall,
            "warnings": warnings,
            "evidence_gates": ["material allowables at temperature", "load-case completeness", "thick-wall/local FEA if required", "independent review"],
        },
    )


def pressure_vessel_screen(payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return _safe_call("aero.math.pressure_vessel_screen", payload, _pressure_vessel_screen_impl)


def _thermal_sensible_heat_impl(values: dict[str, Any]) -> dict[str, Any]:
    heat_load = _number(values, "heat_load_w", minimum=0.0)
    cp = _number(values, "cp_j_kg_k", minimum=1e-12)
    inlet_temperature = _number(values, "inlet_temperature_k", minimum=0.0)
    mass_flow = _number(values, "mass_flow_kg_s", minimum=1e-12, required=False)
    allowed_delta_t = _number(values, "allowed_delta_t_k", minimum=1e-12, required=False)
    max_outlet = _number(values, "max_outlet_temperature_k", minimum=0.0, required=False)
    if mass_flow is None and allowed_delta_t is None:
        raise InputError("provide mass_flow_kg_s or allowed_delta_t_k")
    required_mass_flow = heat_load / (cp * allowed_delta_t) if allowed_delta_t is not None else None
    delta_t = heat_load / (mass_flow * cp) if mass_flow is not None else None
    outlet = inlet_temperature + delta_t if delta_t is not None else None
    temperature_state = "not_evaluated"
    if max_outlet is not None and outlet is not None:
        temperature_state = "pass" if outlet <= max_outlet else "fail"
    elif allowed_delta_t is not None and mass_flow is not None:
        temperature_state = "pass" if delta_t <= allowed_delta_t else "fail"
    return _base(
        "aero.math.thermal_sensible_heat",
        {
            "heat_load_w": heat_load,
            "cp_j_kg_k": cp,
            "inlet_temperature_k": inlet_temperature,
            "mass_flow_kg_s": mass_flow,
            "allowed_delta_t_k": allowed_delta_t,
            "max_outlet_temperature_k": max_outlet,
        },
        {
            "required_mass_flow_kg_s": required_mass_flow,
            "temperature_rise_k": delta_t,
            "outlet_temperature_k": outlet,
        },
        {
            "status": "screening_only" if temperature_state == "not_evaluated" else ("screening_pass" if temperature_state == "pass" else "screening_review"),
            "temperature_limit": temperature_state,
            "warnings": [
                "Steady sensible heat balance Q = m_dot cp DeltaT; radiation, phase change, axial conduction, and conjugate resistance are excluded.",
                "Use a thermal network or CFD/FEA coupling when wall gradients or transient behavior matter.",
            ],
            "evidence_gates": ["heat-load provenance", "property validity over temperature", "energy balance", "thermal/structural follow-on if limits are approached"],
        },
    )


def thermal_sensible_heat(payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return _safe_call("aero.math.thermal_sensible_heat", payload, _thermal_sensible_heat_impl)


def _compare_scalar_impl(values: dict[str, Any]) -> dict[str, Any]:
    actual = _number(values, "actual")
    reference = _number(values, "reference")
    abs_tol = _number(values, "absolute_tolerance", minimum=0.0, default=0.0)
    rel_tol = _number(values, "relative_tolerance", minimum=0.0, default=0.0)
    scale = max(abs(reference), abs(actual), 1e-30)
    difference = actual - reference
    relative_error = abs(difference) / scale
    allowed = max(abs_tol, rel_tol * scale)
    passed = abs(difference) <= allowed
    return _base(
        "aero.verification.compare_scalar",
        {
            "actual": actual,
            "reference": reference,
            "absolute_tolerance": abs_tol,
            "relative_tolerance": rel_tol,
            "actual_label": str(values.get("actual_label") or "actual"),
            "reference_label": str(values.get("reference_label") or "reference"),
        },
        {"difference": difference, "absolute_error": abs(difference), "relative_error": relative_error, "allowed_error": allowed},
        {
            "status": "pass" if passed else "fail",
            "passed": passed,
            "warnings": ["Tolerance is a comparison rule supplied by the caller; it is not a validation standard."],
        },
    )


def compare_scalar(payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return _safe_call("aero.verification.compare_scalar", payload, _compare_scalar_impl)


_STUDY_PLANS: dict[str, dict[str, Any]] = {
    "channel_pressure_loss": {
        "title": "Internal channel pressure-loss study",
        "question": "Which geometry meets the pressure-drop budget at the declared flow?",
        "required_inputs": ["fluid properties", "width/height/length", "mass flow or volumetric flow", "pressure budget"],
        "first_principles": ["continuity", "hydraulic diameter", "Reynolds number", "Darcy pressure loss"],
        "solver": "OpenFOAM or Fluent for resolved flow and local losses",
        "outputs": ["pressure drop", "mass-flow balance", "velocity field", "mesh sensitivity"],
        "evidence_gates": ["analytical comparison", "mesh independence", "convergence", "reference/test comparison"],
        "teaching_steps": ["state assumptions", "calculate Re and a hand estimate", "build matched geometry branches", "run and inspect gates", "make a bounded disposition"],
        "trust_boundary": "Correlation is a screening estimate, not a resolved CFD result.",
    },
    "nozzle_first_order": {
        "title": "Compressible nozzle first-order study",
        "question": "Does the declared pressure ratio and area ratio support the intended choked/expanded-flow regime?",
        "required_inputs": ["total pressure/temperature", "gamma and gas constant", "throat area", "exit area ratio", "back pressure if choking is assessed"],
        "first_principles": ["isentropic area-Mach relation", "critical pressure ratio", "choked mass flow"],
        "solver": "rhoSimpleFoam/rhoCentralFoam or Fluent for compressible verification",
        "outputs": ["Mach and pressure distributions", "mass flow", "shock/expansion structure", "wall heat/pressure loads when modeled"],
        "evidence_gates": ["choking check", "mass-flow balance", "mesh/convergence", "boundary-condition review", "reference comparison"],
        "teaching_steps": ["check regime", "compute expected scales", "define fluid domain and patches", "run a bounded precursor", "separate solver evidence from design claims"],
        "trust_boundary": "Isentropic estimates do not establish thrust, heat transfer, or design readiness.",
    },
    "hot_gas_test_section": {
        "title": "Hot-gas test section / injector manifold screening",
        "question": "Which passage delivers the target flow within pressure-loss and preliminary wall-temperature limits?",
        "required_inputs": ["mass flow", "inlet pressure/temperature", "allowable pressure loss", "wall limit", "test duration", "material/property assumptions"],
        "first_principles": ["compressible flow regime", "pressure-loss scale", "sensible heat balance", "thin-wall stress screen"],
        "solver": "compressible CFD followed by thermal network/FEA; keep loads traceable",
        "outputs": ["pressure loss", "flow uniformity", "wall heat flux/temperature", "pressure and thermal load handoff"],
        "evidence_gates": ["property provenance", "mesh and timestep sensitivity", "energy balance", "thermal-structural handoff", "review disposition"],
        "teaching_steps": ["freeze requirements", "bound the physics with hand checks", "parameterize candidates", "run single-physics evidence", "couple only after each gate passes"],
        "trust_boundary": "This is generic ground-test hardware screening, not a flight or engine qualification analysis.",
    },
    "fea_bracket": {
        "title": "Analytical bracket / lug FEA benchmark",
        "question": "Does the linear-static model reproduce a simple closed-form load case?",
        "required_inputs": ["geometry", "material", "loads", "constraints", "allowable and displacement limits"],
        "first_principles": ["axial/bending stress", "deflection estimate", "load-path sanity check"],
        "solver": "CalculiX first; Code_Aster for advanced nonlinear/thermal cases",
        "outputs": ["displacement", "stress", "reaction balance", "mesh convergence"],
        "evidence_gates": ["analytical agreement", "reaction equilibrium", "mesh study", "boundary-condition review"],
        "teaching_steps": ["hand-check", "create mesh and physical groups", "solve", "compare scalar outputs", "record limitations"],
        "trust_boundary": "A benchmark validates a workflow path, not an arbitrary component or material allowables.",
    },
    "pressure_vessel": {
        "title": "Pressure-loaded tube/manifold screen",
        "question": "Does membrane stress remain below the preliminary design allowable?",
        "required_inputs": ["pressure", "radius/thickness", "material allowable", "temperature", "joint efficiency"],
        "first_principles": ["thin-wall hoop stress", "longitudinal stress", "margin"],
        "solver": "CalculiX/Code_Aster or Nastran adapter after the thin-wall check",
        "outputs": ["membrane stress", "local stress concentration", "deformation", "margin"],
        "evidence_gates": ["thin/thick-wall validity", "temperature-dependent properties", "mesh convergence", "independent review"],
        "teaching_steps": ["screen t/r", "calculate membrane stresses", "build an axisymmetric or 3D model", "compare reactions and stresses", "close blockers"],
        "trust_boundary": "Membrane equations do not cover local discontinuities, fatigue, buckling, or code compliance.",
    },
    "thermal_stress": {
        "title": "Thermally loaded constrained component",
        "question": "How do temperature gradients and restraint affect stress and displacement?",
        "required_inputs": ["temperature field or gradient", "thermal expansion", "elastic properties", "constraints", "mechanical loads"],
        "first_principles": ["free thermal expansion", "fully restrained thermal stress bound", "load-path check"],
        "solver": "CalculiX or Code_Aster thermal-to-structural coupling",
        "outputs": ["temperature", "displacement", "thermal/mechanical stress", "margin"],
        "evidence_gates": ["temperature-field provenance", "coupling consistency", "mesh convergence", "material validity"],
        "teaching_steps": ["bound free and restrained cases", "solve thermal field", "map loads", "inspect reactions", "separate screening from qualification"],
        "trust_boundary": "Linear thermoelastic screening is not creep, fatigue, contact, or life prediction.",
    },
}


def study_plan(payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    values = _payload(payload)
    kind = str(values.get("kind") or "").strip().lower()
    if kind not in _STUDY_PLANS:
        return {
            "ok": False,
            "schema": _RESULT_SCHEMA,
            "tool": "aero.study.plan",
            "toolkit_version": TOOLKIT_VERSION,
            "authority": "deterministic_python_kernel",
            "error": "unknown_study_kind",
            "available_kinds": sorted(_STUDY_PLANS),
        }
    plan = dict(_STUDY_PLANS[kind])
    plan["kind"] = kind
    plan["status"] = "planning_only"
    plan["authority"] = "deterministic_study_template"
    return {"ok": True, "schema": _RESULT_SCHEMA, "tool": "aero.study.plan", "toolkit_version": TOOLKIT_VERSION, "plan": plan}


def toolkit_catalog(payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    del payload
    return {
        "ok": True,
        "schema": "aero_engineering_toolkit_catalog_v1",
        "toolkit_version": TOOLKIT_VERSION,
        "authority": "deterministic_python_kernel",
        "purpose": "First-principles bounds and verification before solver execution",
        "tools": [
            {"name": "aero.math.channel_pressure_loss", "role": "continuity, Reynolds, Darcy pressure-loss screen"},
            {"name": "aero.math.nozzle_first_order", "role": "isentropic area-Mach, choking, mass-flow screen"},
            {"name": "aero.math.pressure_vessel_screen", "role": "thin-wall pressure membrane screen"},
            {"name": "aero.math.thermal_sensible_heat", "role": "sensible heat and coolant-flow balance"},
            {"name": "aero.verification.compare_scalar", "role": "compare solver output with declared reference/tolerance"},
            {"name": "aero.study.plan", "role": "structured requirements, equations, solver, and evidence plan"},
        ],
        "not_included": ["arbitrary code execution", "unbounded solver execution", "automatic design approval", "invented material properties"],
        "recommended_sequence": ["aero.study.plan", "aero.math.*", "existing Aero solver adapter", "aero.verification.compare_scalar", "human review"],
    }
