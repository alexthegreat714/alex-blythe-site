from __future__ import annotations

import copy
import hashlib
import json
import math
import os
import re
import shlex
import shutil
import struct
import subprocess
import tarfile
import threading
import time
import uuid
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Callable

from Aero.public_stack.engineering_readiness import audit_imported_cad, build_readiness_contract
from Aero.core.measurement_contract import measurement_audit, reference_audit


AERO_ROOT = Path(__file__).resolve().parent
DEFAULT_CASE = AERO_ROOT / "examples" / "openfoam" / "nozzle_throat_thermal"
STUDY_SUITE_ROOT = AERO_ROOT / "examples" / "openfoam" / "blue_origin_study_suite"
INTERNAL_FLOW_CASE = STUDY_SUITE_ROOT / "cryogenic_feed_surrogate"
EXTERNAL_AERO_CASE = STUDY_SUITE_ROOT / "launch_vehicle_airfoil"
ROTATING_FLOW_CASE = STUDY_SUITE_ROOT / "srf_turbomachinery"
CHT_CASE = STUDY_SUITE_ROOT / "cht_cooling_precursor"
STUDY_SUITE_MANIFEST = STUDY_SUITE_ROOT / "STUDY_SUITE.json"
SCHEMA_VERSION = "aero_openfoam_pipeline_v1"
SPEC_SCHEMA = "aero_openfoam_case_spec_v1"
RUN_SCHEMA = "aero_openfoam_run_v1"
TERMINAL_STATES = {"completed", "failed", "cancelled", "interrupted"}


def _is_blue_profile() -> bool:
    return str(os.getenv("AERO_PROFILE") or "").strip().lower() == "blue"


def _runtime_hooks():
    """Select the execution boundary before any personal integration is imported."""
    if _is_blue_profile():
        try:
            from Aero.core import portable_openfoam_runtime
        except Exception:
            from .core import portable_openfoam_runtime

        return portable_openfoam_runtime
    try:
        from Aero import engineering_hooks
    except Exception:
        from . import engineering_hooks

    return engineering_hooks


def _runtime_case_path_allowed(path: str) -> bool:
    prefix = "/tmp/aero/blue/openfoam/" if _is_blue_profile() else "/tmp/aero/hooks/openfoam/"
    return str(path or "").startswith(prefix)


def _spawn_runtime_process(runtime_hooks, container: str, command: str) -> subprocess.Popen[str]:
    portable_popen = getattr(runtime_hooks, "_popen", None)
    if callable(portable_popen):
        return portable_popen(container, command)
    return subprocess.Popen(
        [runtime_hooks._docker(), "exec", container, "bash", "-lc", command],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _slug(value: str, fallback: str = "case") -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip()).strip("._-")
    return (cleaned or fallback)[:80]


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}.tmp")
    temp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    # Windows can briefly deny replacement while another thread is opening the
    # destination for a status poll (and antivirus/indexers can do the same).
    # Keep the old complete file visible and retry the atomic rename instead of
    # falling back to an in-place write that readers could observe half-written.
    last_error: PermissionError | None = None
    for attempt in range(200):
        try:
            os.replace(temp, path)
            return
        except PermissionError as exc:
            last_error = exc
            time.sleep(min(0.005 * (attempt + 1), 0.05))
    temp.unlink(missing_ok=True)
    if last_error is not None:
        raise last_error


def _read_json(path: Path, default: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else copy.deepcopy(default or {})
    except Exception:
        return copy.deepcopy(default or {})


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _artifact(path: Path) -> dict[str, Any]:
    return {
        "path": str(path),
        "exists": path.exists(),
        "bytes": path.stat().st_size if path.exists() and path.is_file() else 0,
        "sha256": _sha256(path) if path.exists() and path.is_file() else "",
    }


def _json_sha256(payload: Any) -> str:
    rendered = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(rendered.encode("utf-8")).hexdigest()


def _finite_float(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def _stl_enclosed_volume(path: Path) -> float | None:
    """Compute signed-tetrahedra volume for a closed ASCII or binary STL."""
    data = Path(path).read_bytes()
    triangles: list[tuple[tuple[float, float, float], ...]] = []
    if len(data) >= 84:
        count = struct.unpack_from("<I", data, 80)[0]
        if 84 + count * 50 == len(data):
            for index in range(count):
                values = struct.unpack_from("<12fH", data, 84 + index * 50)
                triangles.append((tuple(values[3:6]), tuple(values[6:9]), tuple(values[9:12])))
    if not triangles:
        text = data.decode("utf-8", errors="replace")
        vertices = [tuple(float(value) for value in match) for match in re.findall(
            r"(?im)^\s*vertex\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s*$", text
        )]
        if not vertices or len(vertices) % 3:
            return None
        triangles = [tuple(vertices[index : index + 3]) for index in range(0, len(vertices), 3)]
    signed = 0.0
    for a, b, c in triangles:
        cross = (
            b[1] * c[2] - b[2] * c[1],
            b[2] * c[0] - b[0] * c[2],
            b[0] * c[1] - b[1] * c[0],
        )
        signed += a[0] * cross[0] + a[1] * cross[1] + a[2] * cross[2]
    volume = abs(signed) / 6.0
    return volume if math.isfinite(volume) and volume > 0 else None


def _study_invariant_payload(spec: dict[str, Any]) -> dict[str, Any]:
    """Return the physics/case contract that must match across a mesh study."""
    payload = copy.deepcopy(spec)
    for key in (
        "spec_id",
        "name",
        "created_at",
        "updated_at",
        "spec_validation",
        "parent_spec_id",
        "parent_run_id",
        "validation_study_id",
    ):
        payload.pop(key, None)
    mesh = payload.get("mesh") if isinstance(payload.get("mesh"), dict) else {}
    mesh.pop("refinement_passes", None)
    numerics = payload.get("numerics") if isinstance(payload.get("numerics"), dict) else {}
    # These controls may legitimately grow for a refined mesh without changing
    # the physical or discretization contract being compared.
    numerics.pop("end_time", None)
    numerics.pop("timeout_sec", None)
    validation = payload.get("validation") if isinstance(payload.get("validation"), dict) else {}
    validation.pop("mesh_independence_evidence", None)
    return payload


def _study_invariant_sha256(spec: dict[str, Any]) -> str:
    return _json_sha256(_study_invariant_payload(spec))


def _spec_synchronized(method: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(method)
    def wrapped(self, *args: Any, **kwargs: Any) -> Any:
        with self._spec_lock:
            return method(self, *args, **kwargs)

    return wrapped


def _default_root() -> Path:
    configured = str(os.getenv("AERO_OPENFOAM_PIPELINE_ROOT") or "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    d_root = Path("D:/AeroRuntime/openfoam_pipeline")
    if Path("D:/").exists():
        return d_root
    return (AERO_ROOT / "data" / "openfoam_pipeline").resolve()


def template_catalog() -> dict[str, dict[str, Any]]:
    """Describe supported CFD families without pretending every family has a validated seed case."""
    return {
        "compressible_nozzle": {
            "label": "Compressible nozzle gas dynamics",
            "mode": "validated_seed",
            "default_solver": "rhoSimpleFoam",
            "seed_case": str(DEFAULT_CASE),
            "supports": ["steady", "compressible", "mass_flow_sweep", "back_pressure_sweep"],
        },
        "existing_case": {
            "label": "Reviewed existing OpenFOAM case",
            "mode": "generic_copy",
            "default_solver": "",
            "seed_case": "",
            "supports": ["incompressible_internal", "external_aero", "compressible", "transient", "cht"],
        },
        "incompressible_internal": {
            "label": "Single-phase cryogenic feed-line loss surrogate",
            "mode": "validated_seed",
            "default_solver": "simpleFoam",
            "seed_case": str(INTERNAL_FLOW_CASE),
            "supports": ["steady", "pressure_drop", "mass_flow", "parameter_sweep"],
        },
        "external_aerodynamics": {
            "label": "Launch-vehicle external-aerodynamics precursor",
            "mode": "validated_seed",
            "default_solver": "simpleFoam",
            "seed_case": str(EXTERNAL_AERO_CASE),
            "supports": ["steady", "forces", "parameter_sweep"],
        },
        "conjugate_heat_transfer": {
            "label": "Conjugate cooling-channel precursor",
            "mode": "validated_seed",
            "default_solver": "chtMultiRegionFoam",
            "seed_case": str(CHT_CASE),
            "supports": ["steady", "transient", "thermal_balance"],
        },
        "transient_flow": {
            "label": "Transient flow",
            "mode": "spec_ready_seed_required",
            "default_solver": "pimpleFoam",
            "seed_case": "",
            "supports": ["transient", "courant_control", "time_series"],
        },
        "rotating_turbomachinery": {
            "label": "Single-rotating-frame turbomachinery precursor",
            "mode": "validated_seed",
            "default_solver": "SRFSimpleFoam",
            "seed_case": str(ROTATING_FLOW_CASE),
            "supports": ["steady", "rotating_reference_frame", "pressure_change", "speed_sweep"],
        },
    }


def template_runtime_plan(template: str) -> dict[str, Any]:
    """Return fixed, reviewed meshing steps; arbitrary shell commands never enter a spec."""
    plans = {
        "compressible_nozzle": {
            "preserve_poly_mesh": False,
            "mesh_steps": [("blockMesh", "blockMesh"), ("checkMesh", "checkMesh")],
        },
        "incompressible_internal": {
            "preserve_poly_mesh": False,
            "mesh_steps": [("blockMesh", "blockMesh"), ("checkMesh", "checkMesh")],
        },
        "external_aerodynamics": {
            "preserve_poly_mesh": True,
            "mesh_steps": [("renumberMesh", "renumberMesh -overwrite"), ("checkMesh", "checkMesh")],
        },
        "rotating_turbomachinery": {
            "preserve_poly_mesh": False,
            "mesh_steps": [("blockMesh", "blockMesh"), ("checkMesh", "checkMesh")],
        },
        "conjugate_heat_transfer": {
            "preserve_poly_mesh": False,
            "mesh_steps": [
                ("blockMesh", "blockMesh"),
                ("topoSet", "topoSet"),
                ("splitMeshRegions", "splitMeshRegions -cellZones -defaultRegionName fluid -overwrite"),
                ("checkMesh_fluid", "checkMesh -region fluid"),
                ("checkMesh_solid", "checkMesh -region solid"),
            ],
        },
    }
    return copy.deepcopy(plans.get(template) or plans["compressible_nozzle"])


def default_nozzle_spec(name: str = "Aero compressible nozzle") -> dict[str, Any]:
    return {
        "schema": SPEC_SCHEMA,
        "name": name,
        "template": "compressible_nozzle",
        "case_source": str(DEFAULT_CASE),
        "purpose": "training",
        "status": "draft",
        "mesh": {"refinement_passes": 0},
        "physics": {
            "dimensions": 3,
            "flow_regime": "compressible_steady",
            "fluid": "perfectGas",
            "energy": True,
            "turbulence_model": "laminar",
            "wall_thermal_model": "adiabatic",
            "specific_heat_j_kg_k": 1005.0,
        },
        "boundaries": {
            "required_patches": ["inlet", "outlet", "hotWall", "centerline", "sidePlanes"],
            "inlet": {"kind": "mass_flow_inlet", "mass_flow_kg_s": 0.01, "temperature_k": 300.0},
            "outlet": {"kind": "pressure_outlet", "pressure_pa": 101325.0},
            "hotWall": {"kind": "wall", "thermal": "adiabatic"},
        },
        "numerics": {
            "solver": "rhoSimpleFoam",
            "end_time": 1500.0,
            "delta_t": 1.0,
            "adjust_time_step": False,
            "max_courant": 1.0,
            "max_delta_t": 1.0,
            "write_interval": 100,
            "timeout_sec": 420,
        },
        "monitoring": {
            "residual_fields": ["rho", "p", "U", "h", "T"],
            "engineering_monitors": ["courant", "mass_flow", "pressure_ratio", "temperature", "mach"],
            "sample_interval_sec": 0.5,
        },
        "objectives": [
            {"name": "solver_stability", "kind": "steady_monitor_stability"},
            {"name": "mass_conservation", "kind": "relative_mass_imbalance", "maximum": 0.01},
        ],
        "validation": {
            "mesh": {"max_aspect_ratio": 5.0, "max_non_orthogonality": 20.0, "max_skewness": 1.0},
            "residual_thresholds": {"Ux": 1.0e-4, "Uy": 1.0e-4, "h": 1.0e-4, "p": 1.0e-4},
            "monitor_stability": {"window": 10, "relative_band": 0.01},
            "maximum_mass_imbalance": 0.01,
            "maximum_energy_imbalance": 0.02,
            "courant_required": False,
            "mesh_independence_required": True,
            "validation_reference": "",
            "design_model_ready": False,
            "model_limitations": "Simplified steady air nozzle precursor with a prescribed mass-flow inlet, fixed outlet pressure, unvalidated geometry, and no reacting-flow or real-gas physics. It is not yet a choked rocket-nozzle model.",
        },
        "automation": {
            "auto_adjust": False,
            "max_interventions": 3,
            "cooldown_sec": 5.0,
            "courant_hard_limit": 2.0,
            "delta_t_reduction_factor": 0.5,
            "minimum_delta_t": 1.0e-10,
        },
        "teaching": {
            "enabled": True,
            "level": "intermediate",
            "pause_on_intervention": False,
            "explain_each_gate": True,
        },
    }


def default_template_spec(template: str, name: str = "") -> dict[str, Any]:
    template = str(template or "compressible_nozzle").strip()
    if template == "compressible_nozzle":
        return default_nozzle_spec(name or "Aero compressible nozzle")

    profiles: dict[str, dict[str, Any]] = {
        "incompressible_internal": {
            "name": name or "Aero cryogenic feed-line loss surrogate",
            "case_source": str(INTERNAL_FLOW_CASE),
            "purpose": "training",
            "physics": {
                "dimensions": 2,
                "flow_regime": "incompressible_turbulent_steady",
                "fluid": "single_phase_cryogenic_surrogate",
                "energy": False,
                "turbulence_model": "case_defined_RAS",
                "wall_treatment": "case_defined_wall_functions",
                "target_y_plus": 30.0,
                "density_kg_m3": 422.0,
                "kinematic_viscosity_m2_s": 3.0e-7,
                "property_basis": "constant-property liquid-methane-like teaching surrogate; not real-fluid or two-phase evidence",
            },
            "boundaries": {
                "required_patches": ["inlet", "outlet", "upperWall", "lowerWall", "frontAndBack"],
                "inlet": {"kind": "velocity_inlet", "case_value_m_s": 10.0},
                "outlet": {"kind": "pressure_outlet", "kinematic_pressure_m2_s2": 0.0},
                "walls": {"kind": "no_slip"},
            },
            "numerics": {
                "solver": "simpleFoam",
                "end_time": 2500.0,
                "delta_t": 1.0,
                "adjust_time_step": False,
                "max_courant": 1.0,
                "max_delta_t": 1.0,
                "write_interval": 50,
                "timeout_sec": 600,
                "relaxation_factor": 0.95,
            },
            "monitoring": {
                "residual_fields": ["Ux", "Uy", "p", "k", "omega", "epsilon"],
                "engineering_monitors": ["mass_flow", "total_pressure_loss"],
                "sample_interval_sec": 0.5,
            },
            "objectives": [
                {"name": "pressure_loss", "kind": "total_pressure_loss_pa", "direction": "minimize"},
                {"name": "mass_conservation", "kind": "relative_mass_imbalance", "maximum": 0.02},
            ],
            "validation": {
                "mesh": {"max_aspect_ratio": 100.0, "max_non_orthogonality": 70.0, "max_skewness": 4.0},
                "residual_thresholds": {"Ux": 1.0e-3, "Uy": 1.0e-3, "p": 1.0e-2},
                "convergence_basis": "pitzDaily seed residual controls plus stable total-pressure-loss/mass-flow monitors and mass conservation",
                "monitor_stability": {"window": 5, "relative_band": 0.02},
                "maximum_mass_imbalance": 0.02,
                "maximum_energy_imbalance": 0.02,
                "courant_required": False,
                "mesh_independence_required": True,
                "validation_reference": "",
            },
        },
        "external_aerodynamics": {
            "name": name or "Aero launch-vehicle external-aerodynamics precursor",
            "case_source": str(EXTERNAL_AERO_CASE),
            "purpose": "training",
            "physics": {
                "dimensions": 2,
                "flow_regime": "incompressible_turbulent_steady_external",
                "fluid": "air_constant_properties",
                "energy": False,
                "turbulence_model": "SpalartAllmaras",
                "wall_treatment": "wall_resolved",
                "target_y_plus": 1.0,
                "density_kg_m3": 1.225,
                "reference_length_m": 35.0492,
                "reference_area_m2": 1.75246,
                "reference_center_m": [-8.7869, 0.22986, 0.025],
            },
            "boundaries": {
                "required_patches": ["inlet", "outlet", "walls", "frontAndBack"],
                "farfield": {"kind": "freestream", "case_velocity_m_s": [25.75, 3.62, 0.0]},
                "walls": {"kind": "no_slip_airfoil"},
            },
            "numerics": {
                "solver": "simpleFoam",
                "end_time": 500.0,
                "delta_t": 1.0,
                "adjust_time_step": False,
                "max_courant": 1.0,
                "max_delta_t": 1.0,
                "write_interval": 50,
                "timeout_sec": 120,
            },
            "monitoring": {
                "residual_fields": ["Ux", "Uy", "p", "nuTilda"],
                "engineering_monitors": ["lift_coefficient", "drag_coefficient"],
                "sample_interval_sec": 0.5,
            },
            "objectives": [
                {"name": "drag", "kind": "drag_coefficient", "direction": "minimize"},
                {"name": "lift", "kind": "lift_coefficient", "direction": "observe"},
            ],
            "validation": {
                "mesh": {"max_aspect_ratio": 2000.0, "max_non_orthogonality": 75.0, "max_skewness": 6.0},
                "residual_thresholds": {"Ux": 1.0e-4, "Uy": 1.0e-4, "p": 1.0e-4, "nuTilda": 1.0e-4},
                "monitor_stability": {"window": 5, "relative_band": 0.02},
                "maximum_mass_imbalance": 0.02,
                "maximum_energy_imbalance": 0.02,
                "courant_required": False,
                "mesh_independence_required": True,
                "validation_reference": "",
            },
        },
        "rotating_turbomachinery": {
            "name": name or "Aero SRF turbomachinery precursor",
            "case_source": str(ROTATING_FLOW_CASE),
            "purpose": "training",
            "physics": {
                "dimensions": 3,
                "flow_regime": "incompressible_turbulent_steady_rotating_frame",
                "fluid": "air_constant_properties",
                "energy": False,
                "turbulence_model": "case_defined_RAS",
                "wall_treatment": "case_defined_wall_functions",
                "target_y_plus": 30.0,
                "rotational_speed_rpm": 1000.0,
                "density_kg_m3": 1.225,
            },
            "boundaries": {
                "required_patches": ["inlet", "outlet", "innerWall", "outerWall", "cyclic_half0", "cyclic_half1"],
                "inlet": {"kind": "absolute_velocity_inlet", "case_velocity_m_s": [0.0, 0.0, -10.0]},
                "outlet": {"kind": "pressure_outlet"},
            },
            "numerics": {
                "solver": "SRFSimpleFoam",
                "end_time": 50.0,
                "delta_t": 1.0,
                "adjust_time_step": False,
                "max_courant": 1.0,
                "max_delta_t": 1.0,
                "write_interval": 10,
                "timeout_sec": 120,
            },
            "monitoring": {
                "residual_fields": ["Urelx", "Urely", "Urelz", "p", "k", "omega"],
                "engineering_monitors": ["mass_flow", "relative_total_pressure_change"],
                "sample_interval_sec": 0.5,
            },
            "objectives": [
                {"name": "pressure_change", "kind": "relative_total_pressure_change_pa", "direction": "observe"},
                {"name": "mass_conservation", "kind": "relative_mass_imbalance", "maximum": 0.02},
            ],
            "validation": {
                "mesh": {"max_aspect_ratio": 20.0, "max_non_orthogonality": 70.0, "max_skewness": 4.0},
                "residual_thresholds": {"Urelx": 1.0e-3, "Urely": 1.0e-3, "Urelz": 1.0e-3, "p": 1.0e-3},
                "monitor_stability": {"window": 5, "relative_band": 0.05},
                "maximum_mass_imbalance": 0.02,
                "maximum_energy_imbalance": 0.02,
                "courant_required": False,
                "mesh_independence_required": True,
                "validation_reference": "",
            },
        },
        "conjugate_heat_transfer": {
            "name": name or "Aero conjugate cooling-channel precursor",
            "case_source": str(CHT_CASE),
            "purpose": "training",
            "physics": {
                "dimensions": 2,
                "flow_regime": "buoyant_turbulent_transient_multi_region",
                "fluid": "case_defined_gas",
                "solid": "case_defined_solid",
                "energy": True,
                "turbulence_model": "case_defined_RAS",
                "wall_treatment": "case_defined_wall_functions",
                "target_y_plus": 30.0,
                "wall_thermal_model": "coupled_fluid_solid",
            },
            "boundaries": {
                "required_patches": ["inlet", "outlet", "topAndBottom", "wall"],
                "inlet": {"kind": "temperature_velocity_inlet", "case_temperature_k": 297.0},
                "interface": {"kind": "coupled_temperature_baffle", "seed_patch": "wall"},
            },
            "numerics": {
                "solver": "chtMultiRegionFoam",
                "end_time": 20.0,
                "delta_t": 0.005,
                "adjust_time_step": True,
                "max_courant": 5.0,
                "max_delta_t": 0.005,
                "write_interval": 1,
                "timeout_sec": 180,
            },
            "monitoring": {
                "residual_fields": ["Ux", "Uy", "p_rgh", "e", "T", "k", "omega"],
                "engineering_monitors": ["wall_temperature"],
                "sample_interval_sec": 0.5,
            },
            "objectives": [
                {"name": "wall_temperature", "kind": "coupled_interface_average_temperature", "direction": "minimize"},
                {"name": "energy_balance", "kind": "relative_energy_imbalance", "maximum": 0.02},
            ],
            "validation": {
                "mesh": {"max_aspect_ratio": 20.0, "max_non_orthogonality": 70.0, "max_skewness": 4.0},
                "residual_thresholds": {"Ux": 1.0e-4, "Uy": 1.0e-4, "p_rgh": 1.0e-4, "e": 1.0e-4},
                "monitor_stability": {"window": 5, "relative_band": 0.02},
                "maximum_mass_imbalance": 0.02,
                "maximum_energy_imbalance": 0.02,
                "courant_required": True,
                "mesh_independence_required": True,
                "validation_reference": "",
            },
        },
    }
    profile = copy.deepcopy(profiles.get(template) or profiles["incompressible_internal"])
    profile["schema"] = SPEC_SCHEMA
    profile["template"] = template
    profile["status"] = "draft"
    profile["mesh"] = {"refinement_passes": 0}
    profile["automation"] = {
        "auto_adjust": template == "conjugate_heat_transfer",
        "max_interventions": 3,
        "cooldown_sec": 5.0,
        "courant_hard_limit": 10.0 if template == "conjugate_heat_transfer" else 1.0e9,
        "delta_t_reduction_factor": 0.5,
        "minimum_delta_t": 1.0e-10,
    }
    profile["teaching"] = {
        "enabled": True,
        "level": "intermediate",
        "pause_on_intervention": False,
        "explain_each_gate": True,
        "industry_context": "Blue Origin-oriented public study precursor; no proprietary data",
    }
    profile.setdefault("validation", {})["design_model_ready"] = False
    profile["validation"]["model_limitations"] = {
        "incompressible_internal": "Constant-property liquid-methane-like backward-step surrogate; no real-fluid, cavitation, flashing, or two-phase physics.",
        "external_aerodynamics": "Public incompressible airfoil regression, not launch-vehicle geometry or compressible flight-regime evidence.",
        "rotating_turbomachinery": "Steady SRF mixer precursor, not blade-resolved turbopump or pump-map evidence.",
        "conjugate_heat_transfer": "Generic cooling-cylinder CHT precursor, not regenerative-channel geometry or material/property evidence.",
    }.get(template, "Teaching precursor requires a reviewed fidelity upgrade before design use.")
    return profile


def validate_spec(spec: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    template = str(spec.get("template") or "")
    catalog = template_catalog()
    if template not in catalog:
        errors.append(f"unsupported_template:{template or 'missing'}")
    for field in ("name", "physics", "boundaries", "numerics", "monitoring", "validation", "automation"):
        if not spec.get(field):
            errors.append(f"missing:{field}")
    numerics = spec.get("numerics") if isinstance(spec.get("numerics"), dict) else {}
    solver = str(numerics.get("solver") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.+-]+", solver):
        errors.append("invalid:numerics.solver")
    numeric_ranges = {
        "end_time": (0.0, 1.0e12),
        "delta_t": (0.0, 1.0e9),
        "max_courant": (0.0, 100.0),
        "max_delta_t": (0.0, 1.0e9),
        "timeout_sec": (1.0, 86400.0 * 7),
        "relaxation_factor": (0.0, 1.0),
    }
    for key, (lower, upper) in numeric_ranges.items():
        try:
            if key == "relaxation_factor" and numerics.get(key) is None:
                continue
            value = float(numerics.get(key))
            if not lower < value <= upper:
                errors.append(f"out_of_range:numerics.{key}")
        except Exception:
            errors.append(f"invalid:numerics.{key}")
    boundaries = spec.get("boundaries") if isinstance(spec.get("boundaries"), dict) else {}
    required = boundaries.get("required_patches")
    if not isinstance(required, list) or not all(str(row).strip() for row in required):
        errors.append("invalid:boundaries.required_patches")
    mesh_controls = spec.get("mesh") if isinstance(spec.get("mesh"), dict) else {}
    try:
        refinement_passes = int(mesh_controls.get("refinement_passes") or 0)
        if refinement_passes < 0 or refinement_passes > 2:
            errors.append("out_of_range:mesh.refinement_passes")
    except Exception:
        errors.append("invalid:mesh.refinement_passes")
    validation = spec.get("validation") if isinstance(spec.get("validation"), dict) else {}
    measurements = measurement_audit(spec)
    references = reference_audit(spec)
    errors.extend(measurements["errors"])
    if measurements["status"] == "unscoped":
        warnings.append("requested_output_contract_missing:review_before_claiming_a_result")
    if validation.get("design_model_ready") is False:
        warnings.append("model_fidelity_not_ready_for_design_use")
    if references["status"] == "missing":
        warnings.append("validation_reference_missing:design_use_will_remain_blocked")
    elif references["status"] != "matched_independent_comparison":
        warnings.append("validation_reference_" + references["status"] + ":design_use_will_remain_blocked")
    mesh_evidence = validation.get("mesh_independence_evidence") if isinstance(validation.get("mesh_independence_evidence"), dict) else {}
    if bool(validation.get("mesh_independence_required", True)) and not bool(mesh_evidence.get("passed")):
        warnings.append("mesh_independence_evidence_required")
    readiness = build_readiness_contract(spec)
    boundary_audit = readiness.get("boundary_turbulence_audit") or {}
    if boundary_audit.get("status") != "pass":
        warnings.append("boundary_turbulence_wall_review_required")
    if (readiness.get("cad_import_audit") or {}).get("status") == "blocked":
        warnings.append("imported_cad_quality_gate_blocked")
    if any(row.get("id") == "uncertainty_margin_risk_report" and row.get("status") != "pass" for row in readiness.get("items") or []):
        warnings.append("uncertainty_budget_required_for_design_use")
    entry = catalog.get(template, {})
    if entry.get("mode") == "spec_ready_seed_required" and not str(spec.get("case_source") or "").strip():
        errors.append(f"case_source_required_for_template:{template}")
    return {
        "ok": not errors,
        "schema": SPEC_SCHEMA,
        "errors": errors,
        "warnings": warnings,
        "measurement_audit": measurements,
        "reference_audit": references,
        "design_use_allowed": not errors and not warnings,
    }


def _replace_dict_entry(text: str, entry: str, value: str) -> str:
    pattern = re.compile(rf"(?m)^(\s*{re.escape(entry)}\s+)[^;]+(;.*)$")
    if pattern.search(text):
        return pattern.sub(rf"\g<1>{value}\g<2>", text, count=1)
    return text.rstrip() + f"\n{entry:<16}{value};\n"


def _sync_residual_control(case_root: Path, spec: dict[str, Any]) -> None:
    """Keep SIMPLE termination consistent with Aero's declared residual gates.

    Several public regression seeds stop at 1e-2/1e-3 while Aero's evidence
    contract requires 1e-4.  A refinement study cannot be admissible if the
    solver is configured to stop before its own declared evidence threshold.
    Only existing keys inside the seed's residualControl dictionary are changed.
    """
    path = case_root / "system" / "fvSolution"
    if not path.is_file():
        return
    thresholds = ((spec.get("validation") or {}).get("residual_thresholds") or {})
    if not isinstance(thresholds, dict) or not thresholds:
        return
    replacements: dict[str, float] = {}
    for scalar in ("p", "p_rgh", "h", "e", "T"):
        if scalar in thresholds:
            replacements[scalar] = float(thresholds[scalar])
    velocity_values = [float(value) for key, value in thresholds.items() if str(key).startswith("U") and not str(key).startswith("Urel")]
    relative_velocity_values = [float(value) for key, value in thresholds.items() if str(key).startswith("Urel")]
    if velocity_values:
        replacements["U"] = min(velocity_values)
    if relative_velocity_values:
        replacements["Urel"] = min(relative_velocity_values)
    text = path.read_text(encoding="utf-8", errors="replace")
    marker = re.search(r"\bresidualControl\s*\{", text)
    if not marker:
        return
    open_brace = text.find("{", marker.start())
    depth = 0
    close_brace = -1
    for index in range(open_brace, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                close_brace = index
                break
    if close_brace < 0:
        return
    block = text[open_brace + 1 : close_brace]
    for field, threshold in replacements.items():
        block = re.sub(
            rf"(?m)^(\s*{re.escape(field)}\s+)[^;]+(;.*)$",
            rf"\g<1>{threshold:.12g}\g<2>",
            block,
            count=1,
        )
    path.write_text(text[: open_brace + 1] + block + text[close_brace:], encoding="utf-8")


def _sync_relaxation_factors(case_root: Path, spec: dict[str, Any]) -> None:
    factor = (spec.get("numerics") or {}).get("relaxation_factor")
    if factor is None:
        return
    factor = float(factor)
    if not 0.05 <= factor <= 1.0:
        raise ValueError("numerics.relaxation_factor_out_of_range")
    path = case_root / "system" / "fvSolution"
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8", errors="replace")
    marker = re.search(r"\brelaxationFactors\s*\{", text)
    if not marker:
        return
    open_brace = text.find("{", marker.start())
    depth = 0
    close_brace = -1
    for index in range(open_brace, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                close_brace = index
                break
    if close_brace < 0:
        return
    block = text[open_brace + 1 : close_brace]
    block = re.sub(r'(?m)^(\s*U\s+)[^;]+(;.*)$', rf'\g<1>{factor:.12g}\g<2>', block, count=1)
    block = re.sub(r'(?m)^(\s*"\.\*"\s+)[^;]+(;.*)$', rf'\g<1>{factor:.12g}\g<2>', block, count=1)
    path.write_text(text[: open_brace + 1] + block + text[close_brace:], encoding="utf-8")


def _scale_nozzle_block_mesh(case_root: Path, refinement_passes: int) -> None:
    """Regenerate reviewed nozzle levels without recursive refineMesh passes."""
    level = max(0, min(int(refinement_passes or 0), 2))
    if level == 0:
        return
    factor = {1: 1.5, 2: 2.0}[level]
    path = case_root / "system" / "blockMeshDict"
    if not path.is_file():
        raise ValueError("compressible_nozzle_blockMeshDict_missing")
    text = path.read_text(encoding="utf-8", errors="replace")

    def scaled(match: re.Match[str]) -> str:
        axial = max(1, int(round(int(match.group(1)) * factor)))
        normal = max(1, int(round(int(match.group(2)) * factor)))
        span = int(match.group(3))
        return f"({axial} {normal} {span})"

    rendered, count = re.subn(r"\((\d+)\s+(\d+)\s+(\d+)\)(?=\s+simpleGrading)", scaled, text)
    if count < 1:
        raise ValueError("compressible_nozzle_block_counts_not_found")
    path.write_text(rendered, encoding="utf-8")


def _apply_nozzle_geometry_variant(case_root: Path, spec: dict[str, Any]) -> None:
    """Regenerate the reviewed structured precursor from SI geometry parameters."""
    geometry = spec.get("geometry") if isinstance(spec.get("geometry"), dict) else {}
    raw = geometry.get("variant_parameters") if isinstance(geometry.get("variant_parameters"), dict) else {}
    if not raw:
        return
    defaults = {
        "inlet_radius_m": 0.032, "throat_radius_m": 0.012, "exit_radius_m": 0.052,
        "converging_length_m": 0.12, "diverging_length_m": 0.18, "span_m": 0.012,
    }
    values = {name: float(raw.get(name, default)) for name, default in defaults.items()}
    if not all(math.isfinite(value) and value > 0 for value in values.values()):
        raise ValueError("nozzle_geometry_parameters_must_be_positive_and_finite")
    if not (0.003 <= values["throat_radius_m"] < min(values["inlet_radius_m"], values["exit_radius_m"])):
        raise ValueError("nozzle_geometry_requires_throat_smaller_than_inlet_and_exit")
    if not (0.02 <= values["converging_length_m"] <= 0.20 and 0.04 <= values["diverging_length_m"] <= 0.35):
        raise ValueError("nozzle_geometry_lengths_outside_reviewed_precursor_bounds")
    ri, rt, rexit = values["inlet_radius_m"], values["throat_radius_m"], values["exit_radius_m"]
    lc, ld, span = values["converging_length_m"], values["diverging_length_m"], values["span_m"]
    stations = [
        (0.0, ri), (0.5 * lc, 0.5 * (ri + rt)), (lc, rt),
        (lc + 0.55 * ld, rt + 0.55 * (rexit - rt)), (lc + ld, rexit),
    ]
    vertices = []
    for x, radius in stations:
        vertices.extend([(x, 0.0, 0.0), (x, radius, 0.0), (x, 0.0, span), (x, radius, span)])
    rendered_vertices = "vertices\n(\n" + "\n".join(
        f"    ({x:.12g} {y:.12g} {z:.12g})" for x, y, z in vertices
    ) + "\n);"
    path = case_root / "system" / "blockMeshDict"
    text = path.read_text(encoding="utf-8", errors="replace")
    rendered, count = re.subn(r"\bvertices\s*\(.*?\n\s*\);", rendered_vertices, text, count=1, flags=re.DOTALL)
    if count != 1:
        raise ValueError("nozzle_geometry_vertices_block_not_found")
    path.write_text(rendered, encoding="utf-8")


def _nozzle_monitor_functions() -> str:
    return r'''

functions
{
    inletMassFlow
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            inlet;
        operation       sum;
        fields          (phi);
    }
    outletMassFlow
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            outlet;
        operation       sum;
        fields          (phi);
    }
    inletPressure
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            inlet;
        operation       areaAverage;
        fields          (p);
    }
    outletPressure
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            outlet;
        operation       areaAverage;
        fields          (p);
    }
    outletTemperature
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            outlet;
        operation       areaAverage;
        fields          (T);
    }
    inletTemperature
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            inlet;
        operation       areaAverage;
        fields          (T);
    }
    inletVelocity
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            inlet;
        operation       areaAverage;
        fields          (U);
    }
    outletVelocity
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            outlet;
        operation       areaAverage;
        fields          (U);
    }
    machNumber
    {
        type            MachNo;
        libs            ("libfieldFunctionObjects.so");
        U               U;
        field           U;
        executeControl  timeStep;
        executeInterval 1;
        // Keep Ma resident for the downstream monitor every iteration, but do
        // not serialize a full volume field into the bounded runtime tmpfs on
        // every SIMPLE iteration.
        writeControl    timeStep;
        writeInterval   50;
    }
    maxMach
    {
        type            volFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      all;
        operation       max;
        fields          (Ma);
    }
}
'''


def _incompressible_monitor_functions(density_kg_m3: float = 1.0, velocity_field: str = "U") -> str:
    return r'''

functions
{
    totalPressureField
    {
        type            pressure;
        libs            ("libfieldFunctionObjects.so");
        field           p;
        U               __AERO_VELOCITY_FIELD__;
        rho             rhoInf;
        rhoInf          __AERO_DENSITY__;
        result          pTotal;
        calcTotal       yes;
        pRef            0;
        calcCoeff       no;
        objects         ();
        executeControl  timeStep;
        executeInterval 1;
        // pTotal is executed every iteration so the inlet/outlet reductions
        // remain live. Persisting the complete field every iteration scales as
        // O(cells * iterations) and exhausted the portable runtime tmpfs during
        // refinement studies, so retain it only at bounded output intervals.
        writeControl    timeStep;
        writeInterval   50;
    }
    inletMassFlow
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            inlet;
        operation       sum;
        fields          (phi);
    }
    outletMassFlow
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            outlet;
        operation       sum;
        fields          (phi);
    }
    inletPressure
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            inlet;
        operation       areaAverage;
        fields          (p);
    }
    outletPressure
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            outlet;
        operation       areaAverage;
        fields          (p);
    }
    inletTotalPressure
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            inlet;
        operation       areaAverage;
        fields          (pTotal);
    }
    outletTotalPressure
    {
        type            surfaceFieldValue;
        libs            ("libfieldFunctionObjects.so");
        writeControl    timeStep;
        writeInterval   1;
        writeFields     false;
        regionType      patch;
        name            outlet;
        operation       areaAverage;
        fields          (pTotal);
    }
}
'''.replace("__AERO_DENSITY__", f"{float(density_kg_m3):.12g}").replace("__AERO_VELOCITY_FIELD__", str(velocity_field))


def _external_force_functions(spec: dict[str, Any]) -> str:
    physics = spec.get("physics") if isinstance(spec.get("physics"), dict) else {}
    farfield = ((spec.get("boundaries") or {}).get("farfield") or {}).get("case_velocity_m_s") or [25.75, 3.62, 0.0]
    velocity = [float(row) for row in farfield]
    magnitude = max(math.sqrt(sum(row * row for row in velocity)), 1.0e-30)
    drag = [velocity[0] / magnitude, velocity[1] / magnitude, velocity[2] / magnitude]
    lift = [-drag[1], drag[0], 0.0]
    center = [float(row) for row in physics.get("reference_center_m") or [-8.7869, 0.22986, 0.025]]
    rendered = r'''

functions
{
    aeroForceCoeffs
    {
        type            forceCoeffs;
        libs            ("libforces.so");
        writeControl    timeStep;
        writeInterval   1;
        log             yes;
        patches         (walls);
        rho             rhoInf;
        rhoInf          __RHO__;
        liftDir         (__LIFT__);
        dragDir         (__DRAG__);
        CofR            (__COFR__);
        pitchAxis       (0 0 1);
        magUInf         __MAG_U__;
        lRef            __L_REF__;
        Aref            __A_REF__;
    }
}
'''
    replacements = {
        "__RHO__": f"{float(physics.get('density_kg_m3') or 1.225):.12g}",
        "__LIFT__": " ".join(f"{row:.12g}" for row in lift),
        "__DRAG__": " ".join(f"{row:.12g}" for row in drag),
        "__COFR__": " ".join(f"{row:.12g}" for row in center),
        "__MAG_U__": f"{magnitude:.12g}",
        "__L_REF__": f"{float(physics.get('reference_length_m') or 1.0):.12g}",
        "__A_REF__": f"{float(physics.get('reference_area_m2') or 1.0):.12g}",
    }
    for marker, value in replacements.items():
        rendered = rendered.replace(marker, value)
    return rendered


def _cht_monitor_functions() -> str:
    return r'''

functions
{
    fluidInterfaceHeatFlux
    {
        type            wallHeatFlux;
        libs            ("libfieldFunctionObjects.so");
        region          fluid;
        patches         (fluid_to_solid);
        objects         ();
        executeControl  timeStep;
        executeInterval 10;
        writeControl    timeStep;
        writeInterval   10;
    }
    solidInterfaceHeatFlux
    {
        type            wallHeatFlux;
        libs            ("libfieldFunctionObjects.so");
        region          solid;
        patches         (solid_to_fluid);
        objects         ();
        executeControl  timeStep;
        executeInterval 10;
        writeControl    timeStep;
        writeInterval   10;
    }
}
'''


def _function_entries(rendered: str) -> str:
    """Return the entries inside a rendered OpenFOAM ``functions`` dictionary."""
    start = rendered.find("{")
    end = rendered.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("invalid_function_dictionary")
    return rendered[start + 1 : end].strip() + "\n"


def _install_aero_functions(case_root: Path, control: str, rendered: str) -> str:
    """Merge Aero monitors without replacing tutorial-supplied function objects.

    OpenFOAM permits includes inside the functions dictionary.  Using an include
    avoids duplicate top-level ``functions`` keys and keeps the imported tutorial
    instrumentation visible for teaching and provenance.
    """
    include_name = "aeroFunctions"
    include_line = f'#include "{include_name}"'
    (case_root / "system" / include_name).write_text(
        _function_entries(rendered), encoding="utf-8"
    )
    if include_line in control:
        return control
    pattern = re.compile(r"(?m)^(\s*functions\s*\{\s*)$")
    if pattern.search(control):
        return pattern.sub(rf'\g<1>\n    {include_line}', control, count=1)
    return control.rstrip() + f"\n\nfunctions\n{{\n    {include_line}\n}}\n"


def _resolve_case_source(spec: dict[str, Any]) -> Path:
    template = str(spec.get("template") or "")
    raw = str(spec.get("case_source") or "").strip()
    if not raw:
        seed = str((template_catalog().get(template) or {}).get("seed_case") or "").strip()
        if seed:
            return Path(seed).resolve()
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = AERO_ROOT / path
    resolved = path.resolve()
    allowed_roots = [AERO_ROOT.resolve(), _default_root().resolve()]
    if not any(resolved == root or root in resolved.parents for root in allowed_roots):
        raise ValueError(f"case_source_outside_allowed_roots:{resolved}")
    return resolved


def build_case(spec: dict[str, Any], destination: Path) -> dict[str, Any]:
    validation = validate_spec(spec)
    if not validation["ok"]:
        return {"ok": False, "error": "invalid_spec", "validation": validation}
    try:
        source = _resolve_case_source(spec)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if not source.is_dir():
        return {"ok": False, "error": "case_source_missing", "path": str(source)}
    if destination.exists():
        shutil.rmtree(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, destination)
    control_path = destination / "system" / "controlDict"
    if not control_path.exists():
        return {"ok": False, "error": "controlDict_missing", "path": str(control_path)}
    numerics = spec["numerics"]
    control = control_path.read_text(encoding="utf-8", errors="replace")
    entries = {
        "application": str(numerics["solver"]),
        "endTime": f"{float(numerics['end_time']):.12g}",
        "deltaT": f"{float(numerics['delta_t']):.12g}",
        "adjustTimeStep": "yes" if bool(numerics.get("adjust_time_step", True)) else "no",
        "maxCo": f"{float(numerics['max_courant']):.12g}",
        "maxDeltaT": f"{float(numerics['max_delta_t']):.12g}",
        "writeInterval": str(int(numerics.get("write_interval") or 1)),
        "purgeWrite": str(max(0, int(numerics.get("purge_write", 3)))),
        "runTimeModifiable": "true",
    }
    for key, value in entries.items():
        control = _replace_dict_entry(control, key, value)
    if spec.get("template") == "compressible_nozzle":
        control = _install_aero_functions(destination, control, _nozzle_monitor_functions())
    elif spec.get("template") in {"incompressible_internal", "rotating_turbomachinery"}:
        density = float((spec.get("physics") or {}).get("density_kg_m3") or 1.0)
        velocity_field = "Urel" if spec.get("template") == "rotating_turbomachinery" else "U"
        control = _install_aero_functions(destination, control, _incompressible_monitor_functions(density, velocity_field))
    elif spec.get("template") == "external_aerodynamics":
        control = _install_aero_functions(destination, control, _external_force_functions(spec))
    elif spec.get("template") == "conjugate_heat_transfer":
        control = _install_aero_functions(destination, control, _cht_monitor_functions())
    control_path.write_text(control, encoding="utf-8")
    _sync_residual_control(destination, spec)
    _sync_relaxation_factors(destination, spec)
    if spec.get("template") == "compressible_nozzle":
        _apply_nozzle_geometry_variant(destination, spec)
        _scale_nozzle_block_mesh(destination, int((spec.get("mesh") or {}).get("refinement_passes") or 0))
    physical_path = destination / "constant" / "physicalProperties"
    viscosity = (spec.get("physics") or {}).get("kinematic_viscosity_m2_s")
    if viscosity is not None and physical_path.is_file():
        physical = physical_path.read_text(encoding="utf-8", errors="replace")
        physical = _replace_dict_entry(physical, "nu", f"{float(viscosity):.12g}")
        physical_path.write_text(physical, encoding="utf-8")
    srf_path = destination / "constant" / "SRFProperties"
    rpm = (spec.get("physics") or {}).get("rotational_speed_rpm")
    if rpm is not None and srf_path.is_file():
        srf = srf_path.read_text(encoding="utf-8", errors="replace")
        srf = _replace_dict_entry(srf, "rpm", f"{float(rpm):.12g}")
        srf_path.write_text(srf, encoding="utf-8")
    manifest = {
        "schema": SCHEMA_VERSION,
        "generated_at": _utc_now(),
        "source": str(source),
        "destination": str(destination),
        "spec_id": spec.get("spec_id"),
        "entries": entries,
        "files": [],
    }
    for path in sorted(destination.rglob("*")):
        if path.is_file():
            manifest["files"].append({"relative_path": str(path.relative_to(destination)).replace("\\", "/"), "sha256": _sha256(path)})
    _atomic_json(destination / "aero_case_manifest.json", manifest)
    return {"ok": True, "case_path": str(destination), "source": str(source), "manifest": manifest}


def parse_openfoam_line(line: str, stage: str = "solver") -> list[dict[str, Any]]:
    text = str(line or "").strip()
    if not text:
        return []
    now = _utc_now()
    rows: list[dict[str, Any]] = []
    patterns: list[tuple[str, str, Callable[[re.Match[str]], dict[str, Any]]]] = [
        ("time", r"^Time\s*=\s*([0-9.eE+-]+)", lambda m: {"value": float(m.group(1))}),
        ("delta_t", r"^deltaT\s*=\s*([0-9.eE+-]+)", lambda m: {"value": float(m.group(1))}),
        (
            "courant",
            r"Courant Number mean:\s*([0-9.eE+-]+)\s+max:\s*([0-9.eE+-]+)",
            lambda m: {"mean": float(m.group(1)), "max": float(m.group(2))},
        ),
        (
            "courant",
            r"Mean and max Courant Numbers\s*=\s*([0-9.eE+-]+)\s+([0-9.eE+-]+)",
            lambda m: {"mean": float(m.group(1)), "max": float(m.group(2))},
        ),
        (
            "residual",
            r"Solving for\s+([^,]+),\s+Initial residual\s*=\s*([0-9.eE+-]+),\s+Final residual\s*=\s*([0-9.eE+-]+),\s+No Iterations\s+([0-9]+)",
            lambda m: {"field": m.group(1).strip(), "initial": float(m.group(2)), "final": float(m.group(3)), "iterations": int(m.group(4))},
        ),
        (
            "continuity",
            r"time step continuity errors\s*:\s*sum local\s*=\s*([0-9.eE+-]+),\s*global\s*=\s*([0-9.eE+-]+),\s*cumulative\s*=\s*([0-9.eE+-]+)",
            lambda m: {"local": float(m.group(1)), "global": float(m.group(2)), "cumulative": float(m.group(3))},
        ),
        (
            "execution",
            r"ExecutionTime\s*=\s*([0-9.eE+-]+)\s*s\s+ClockTime\s*=\s*([0-9.eE+-]+)",
            lambda m: {"execution_sec": float(m.group(1)), "clock_sec": float(m.group(2))},
        ),
    ]
    for kind, pattern, convert in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            try:
                rows.append({"at": now, "kind": kind, "stage": stage, **convert(match), "raw": text[:1000]})
            except (TypeError, ValueError):
                pass
    mesh_patterns = {
        "max_aspect_ratio": r"Max aspect ratio\s*=\s*([0-9.eE+-]+)",
        "max_non_orthogonality": r"Mesh non-orthogonality Max:\s*([0-9.eE+-]+)",
        "max_skewness": r"Max skewness\s*=\s*([0-9.eE+-]+)",
        "cell_count": r"^\s*cells:\s*([0-9]+)\s*$",
    }
    for metric, pattern in mesh_patterns.items():
        match = re.search(pattern, text, re.I)
        if match:
            rows.append({"at": now, "kind": "mesh_metric", "stage": stage, "metric": metric, "value": float(match.group(1)), "raw": text[:1000]})
    if "Mesh OK" in text:
        rows.append({"at": now, "kind": "mesh_ok", "stage": stage, "value": True, "raw": text[:1000]})
    if re.search(
        r"FOAM FATAL ERROR|(?<!Enabling )\bFloating point exception(?:timeout|\s|$)|^\s*Segmentation fault(?:\s|$)",
        text,
        re.I | re.M,
    ):
        rows.append({"at": now, "kind": "fatal", "stage": stage, "message": text[:1000]})
    if text == "End" or text.endswith(" End"):
        rows.append({"at": now, "kind": "end", "stage": stage, "value": True, "raw": text[:1000]})
    monitor = re.search(r"AERO_MONITOR\s+([A-Za-z0-9_.-]+)\s*=\s*([0-9.eE+-]+)", text)
    if monitor:
        rows.append({"at": now, "kind": "monitor", "stage": stage, "name": monitor.group(1), "value": float(monitor.group(2)), "raw": text[:1000]})
    coefficient = re.search(r"^\s*(Cd|Cl|Cm)\s*=\s*([0-9.eE+-]+)", text)
    if coefficient:
        coefficient_names = {"Cd": "drag_coefficient", "Cl": "lift_coefficient", "Cm": "moment_coefficient"}
        rows.append(
            {
                "at": now,
                "kind": "monitor",
                "stage": stage,
                "name": coefficient_names[coefficient.group(1)],
                "value": float(coefficient.group(2)),
                "raw": text[:1000],
            }
        )
    temperature_range = re.search(r"Min/max T:\s*([0-9.eE+-]+)\s+([0-9.eE+-]+)", text)
    if temperature_range:
        rows.extend(
            [
                {"at": now, "kind": "monitor", "stage": stage, "name": "temperature_min", "value": float(temperature_range.group(1)), "raw": text[:1000]},
                {"at": now, "kind": "monitor", "stage": stage, "name": "temperature_max", "value": float(temperature_range.group(2)), "raw": text[:1000]},
            ]
        )
    surface_monitor = re.search(
        r"(?:surfaceFieldValue|volFieldValue)\s+([A-Za-z0-9_.-]+)\s+write:\s*(?:sum|areaAverage|max)\([^)]*\)\s+of\s+[A-Za-z0-9_.-]+\s*=\s*([0-9.eE+-]+)",
        text,
        re.I,
    )
    if surface_monitor:
        name_map = {
            "inletmassflow": "mass_flow_inlet",
            "outletmassflow": "mass_flow_outlet",
            "inletpressure": "pressure_inlet",
            "outletpressure": "pressure_outlet",
            "inlettotalpressure": "total_pressure_inlet",
            "outlettotalpressure": "total_pressure_outlet",
            "inlettemperature": "temperature_inlet",
            "outlettemperature": "temperature_outlet",
            "maxmach": "mach",
        }
        raw_name = surface_monitor.group(1)
        rows.append(
            {
                "at": now,
                "kind": "monitor",
                "stage": stage,
                "name": name_map.get(raw_name.lower(), raw_name),
                "value": float(surface_monitor.group(2)),
                "raw": text[:1000],
            }
        )
    vector_monitor = re.search(
        r"(?:surfaceFieldValue\s+([A-Za-z0-9_.-]+)\s+write:\s*)?areaAverage\((inlet|outlet)\)\s+of\s+U\s*=\s*\(\s*([0-9.eE+-]+)\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\s*\)",
        text,
        re.I,
    )
    if vector_monitor:
        object_name, region, ux, uy, uz = vector_monitor.groups()
        raw_name = (object_name or f"{region}Velocity").lower()
        name_map = {"inletvelocity": "velocity_inlet", "outletvelocity": "velocity_outlet"}
        monitor_name = name_map.get(raw_name)
        if monitor_name:
            magnitude = math.sqrt(float(ux) ** 2 + float(uy) ** 2 + float(uz) ** 2)
            rows.append(
                {
                    "at": now,
                    "kind": "monitor",
                    "stage": stage,
                    "name": monitor_name,
                    "value": magnitude,
                    "components": [float(ux), float(uy), float(uz)],
                    "raw": text[:1000],
                }
            )
    value_monitor = re.search(
        r"\b(sum|areaAverage|max)\(([^)]+)\)\s+of\s+([A-Za-z0-9_.-]+)\s*=\s*([0-9.eE+-]+)",
        text,
        re.I,
    )
    if value_monitor and not surface_monitor:
        operation, region, field, value = value_monitor.groups()
        key = (operation.lower(), region.lower(), field.lower())
        name_map = {
            ("sum", "inlet", "phi"): "mass_flow_inlet",
            ("sum", "outlet", "phi"): "mass_flow_outlet",
            ("areaaverage", "inlet", "p"): "pressure_inlet",
            ("areaaverage", "outlet", "p"): "pressure_outlet",
            ("areaaverage", "inlet", "ptotal"): "total_pressure_inlet",
            ("areaaverage", "outlet", "ptotal"): "total_pressure_outlet",
            ("areaaverage", "outlet", "t"): "temperature",
            ("max", "all", "ma"): "mach",
        }
        monitor_name = name_map.get(key)
        if monitor_name:
            rows.append({"at": now, "kind": "monitor", "stage": stage, "name": monitor_name, "value": float(value), "raw": text[:1000]})
    return rows


def _initial_metrics() -> dict[str, Any]:
    return {
        "mesh_ok": False,
        "mesh": {},
        "mesh_regions": {},
        "latest_time": None,
        "latest_delta_t": None,
        "max_courant_observed": None,
        "latest_courant": None,
        "residuals": {},
        "continuity": {},
        "monitors": {},
        "solver_end": False,
        "fatal_errors": [],
        "telemetry_count": 0,
        "flux_basis": "mass",
        "reference_density_kg_m3": 1.0,
        "case_template": "compressible_nozzle",
    }


def _metrics_for_spec(spec: dict[str, Any]) -> dict[str, Any]:
    metrics = _initial_metrics()
    template = str(spec.get("template") or "compressible_nozzle")
    metrics["flux_basis"] = "mass" if template == "compressible_nozzle" else "volumetric"
    metrics["reference_density_kg_m3"] = float((spec.get("physics") or {}).get("density_kg_m3") or 1.0)
    metrics["case_template"] = template
    metrics["specific_heat_j_kg_k"] = float((spec.get("physics") or {}).get("specific_heat_j_kg_k") or 1005.0)
    return metrics


def _merge_telemetry(metrics: dict[str, Any], event: dict[str, Any]) -> None:
    kind = event.get("kind")
    metrics["telemetry_count"] = int(metrics.get("telemetry_count") or 0) + 1
    if kind == "mesh_ok":
        metrics["mesh_ok"] = True
    elif kind == "mesh_metric":
        metric_name = str(event.get("metric"))
        metric_value = float(event.get("value") or 0.0)
        stage = str(event.get("stage") or "")
        if stage.startswith("checkMesh_"):
            region = stage.removeprefix("checkMesh_")
            metrics.setdefault("mesh_regions", {}).setdefault(region, {})[metric_name] = metric_value
            if metric_name == "cell_count":
                metrics.setdefault("mesh", {})[metric_name] = sum(
                    float(row.get("cell_count") or 0.0)
                    for row in metrics["mesh_regions"].values()
                    if isinstance(row, dict)
                )
            else:
                metrics.setdefault("mesh", {})[metric_name] = max(
                    float(row.get(metric_name) or 0.0)
                    for row in metrics["mesh_regions"].values()
                    if isinstance(row, dict)
                )
        else:
            metrics.setdefault("mesh", {})[metric_name] = metric_value
    elif kind == "time":
        metrics["latest_time"] = event.get("value")
    elif kind == "delta_t":
        metrics["latest_delta_t"] = event.get("value")
    elif kind == "courant":
        maximum = float(event.get("max") or 0.0)
        metrics["latest_courant"] = maximum
        prior = metrics.get("max_courant_observed")
        metrics["max_courant_observed"] = maximum if prior is None else max(float(prior), maximum)
    elif kind == "residual":
        metrics.setdefault("residuals", {})[str(event.get("field"))] = {
            "initial": event.get("initial"),
            "final": event.get("final"),
            "iterations": event.get("iterations"),
            "at": event.get("at"),
        }
    elif kind == "continuity":
        metrics["continuity"] = {key: event.get(key) for key in ("local", "global", "cumulative")}
    elif kind == "monitor":
        event_name = str(event.get("name"))
        metrics.setdefault("monitors", {}).setdefault(event_name, []).append(event.get("value"))
        metrics["monitors"][event_name] = metrics["monitors"][event_name][-100:]
        monitors = metrics["monitors"]
        if event_name == "temperature_outlet":
            monitors.setdefault("temperature", []).append(float(event.get("value")))
            monitors["temperature"] = monitors["temperature"][-100:]
        if event_name == "pressure_outlet" and monitors.get("pressure_inlet") and monitors.get("pressure_outlet") and float(monitors["pressure_outlet"][-1]) != 0.0:
            monitors.setdefault("pressure_ratio", []).append(float(monitors["pressure_inlet"][-1]) / float(monitors["pressure_outlet"][-1]))
            monitors["pressure_ratio"] = monitors["pressure_ratio"][-100:]
        if event_name == "pressure_outlet" and monitors.get("pressure_inlet") and monitors.get("pressure_outlet"):
            monitors.setdefault("pressure_drop", []).append(float(monitors["pressure_inlet"][-1]) - float(monitors["pressure_outlet"][-1]))
            monitors["pressure_drop"] = monitors["pressure_drop"][-100:]
        if event_name == "total_pressure_outlet" and monitors.get("total_pressure_inlet") and monitors.get("total_pressure_outlet"):
            inlet_total = float(monitors["total_pressure_inlet"][-1])
            outlet_total = float(monitors["total_pressure_outlet"][-1])
            monitors.setdefault("total_pressure_loss", []).append(inlet_total - outlet_total)
            monitors["total_pressure_loss"] = monitors["total_pressure_loss"][-100:]
            monitors.setdefault("total_pressure_change", []).append(outlet_total - inlet_total)
            monitors["total_pressure_change"] = monitors["total_pressure_change"][-100:]
            if metrics.get("case_template") == "rotating_turbomachinery":
                monitors.setdefault("relative_total_pressure_change", []).append(outlet_total - inlet_total)
                monitors["relative_total_pressure_change"] = monitors["relative_total_pressure_change"][-100:]
        if event_name == "mass_flow_outlet" and monitors.get("mass_flow_inlet") and monitors.get("mass_flow_outlet"):
            inlet = abs(float(monitors["mass_flow_inlet"][-1]))
            outlet = abs(float(monitors["mass_flow_outlet"][-1]))
            denominator = max(inlet, outlet, 1.0e-30)
            monitors.setdefault("mass_imbalance", []).append(abs(inlet - outlet) / denominator)
            monitors["mass_imbalance"] = monitors["mass_imbalance"][-100:]
            monitors.setdefault("volumetric_flow", []).append(outlet)
            monitors["volumetric_flow"] = monitors["volumetric_flow"][-100:]
            mass_flow = outlet
            if metrics.get("flux_basis") == "volumetric":
                mass_flow *= float(metrics.get("reference_density_kg_m3") or 1.0)
            monitors.setdefault("mass_flow", []).append(mass_flow)
            monitors["mass_flow"] = monitors["mass_flow"][-100:]
        if event_name == "velocity_outlet" and all(
            monitors.get(name)
            for name in ("temperature_inlet", "temperature_outlet", "velocity_inlet", "velocity_outlet")
        ):
            cp = float(metrics.get("specific_heat_j_kg_k") or 1005.0)
            inlet_energy = cp * float(monitors["temperature_inlet"][-1]) + 0.5 * float(monitors["velocity_inlet"][-1]) ** 2
            outlet_energy = cp * float(monitors["temperature_outlet"][-1]) + 0.5 * float(monitors["velocity_outlet"][-1]) ** 2
            denominator = max(abs(inlet_energy), abs(outlet_energy), 1.0e-30)
            monitors.setdefault("energy_imbalance", []).append(abs(inlet_energy - outlet_energy) / denominator)
            monitors["energy_imbalance"] = monitors["energy_imbalance"][-100:]
    elif kind == "fatal":
        metrics.setdefault("fatal_errors", []).append(str(event.get("message") or "")[:1000])
    elif kind == "end" and event.get("stage") == "solver":
        metrics["solver_end"] = True


def evaluate_gates(spec: dict[str, Any], metrics: dict[str, Any]) -> dict[str, Any]:
    validation = spec.get("validation") if isinstance(spec.get("validation"), dict) else {}
    gates: list[dict[str, Any]] = []

    def add(name: str, passed: bool | None, evidence: Any, required: bool = True) -> None:
        gates.append({"name": name, "passed": passed, "required": required, "evidence": evidence})

    add("solver_reached_end", bool(metrics.get("solver_end")), metrics.get("solver_end"))
    add("no_fatal_error", not bool(metrics.get("fatal_errors")), metrics.get("fatal_errors") or [])
    add("mesh_ok", bool(metrics.get("mesh_ok")), metrics.get("mesh"))
    mesh_limits = validation.get("mesh") if isinstance(validation.get("mesh"), dict) else {}
    for metric, maximum in mesh_limits.items():
        observed = (metrics.get("mesh") or {}).get(metric)
        add(f"mesh_{metric}", None if observed is None else float(observed) <= float(maximum), {"observed": observed, "maximum": maximum})
    max_co = metrics.get("max_courant_observed")
    co_limit = float((spec.get("numerics") or {}).get("max_courant") or 1.0)
    courant_required = bool(validation.get("courant_required", True))
    add(
        "courant_bounded",
        None if max_co is None else float(max_co) <= co_limit * 1.05,
        {"observed": max_co, "maximum": co_limit},
        courant_required,
    )
    thresholds = validation.get("residual_thresholds") if isinstance(validation.get("residual_thresholds"), dict) else {}
    residuals = metrics.get("residuals") if isinstance(metrics.get("residuals"), dict) else {}
    for field, threshold in thresholds.items():
        sample = residuals.get(field)
        observed = sample.get("initial") if isinstance(sample, dict) else None
        add(
            f"residual_{field}",
            None if observed is None else float(observed) <= float(threshold),
            {
                "observed": observed,
                "maximum": threshold,
                "basis": "initial_residual_at_latest_outer_iteration",
                "linear_solver_final_residual": sample.get("final") if isinstance(sample, dict) else None,
            },
        )
    continuity = metrics.get("continuity") if isinstance(metrics.get("continuity"), dict) else {}
    monitor_values = metrics.get("monitors") if isinstance(metrics.get("monitors"), dict) else {}
    mass_samples = monitor_values.get("mass_imbalance") or []
    global_error = mass_samples[-1] if mass_samples else continuity.get("global")
    mass_limit = float(validation.get("maximum_mass_imbalance") or 0.01)
    add("mass_conservation", None if global_error is None else abs(float(global_error)) <= mass_limit, {"observed": global_error, "maximum": mass_limit})
    required_monitors = [str(row) for row in (spec.get("monitoring") or {}).get("engineering_monitors", [])]
    missing_monitors = [name for name in required_monitors if name not in {"courant"} and not monitor_values.get(name)]
    add("engineering_monitors_present", not missing_monitors, {"missing": missing_monitors})
    stability = validation.get("monitor_stability") if isinstance(validation.get("monitor_stability"), dict) else {}
    window = max(2, int(stability.get("window") or 10))
    relative_band = float(stability.get("relative_band") or 0.01)
    stability_rows: dict[str, Any] = {}
    stable: bool | None = True
    for name in required_monitors:
        if name == "courant":
            continue
        samples = [float(row) for row in (monitor_values.get(name) or [])[-window:]]
        if len(samples) < window:
            stability_rows[name] = {"samples": len(samples), "required": window, "relative_band": None}
            stable = None
            continue
        mean_abs = max(abs(sum(samples) / len(samples)), 1.0e-30)
        observed_band = (max(samples) - min(samples)) / mean_abs
        stability_rows[name] = {"samples": len(samples), "required": window, "relative_band": observed_band, "maximum": relative_band}
        if observed_band > relative_band:
            stable = False
    add("monitor_stability", stable, stability_rows)
    if bool((spec.get("physics") or {}).get("energy")):
        energy_samples = monitor_values.get("energy_imbalance") or []
        energy_error = energy_samples[-1] if energy_samples else None
        energy_limit = float(validation.get("maximum_energy_imbalance") or 0.02)
        add("energy_conservation", None if energy_error is None else abs(float(energy_error)) <= energy_limit, {"observed": energy_error, "maximum": energy_limit})
    reference = reference_audit(spec)
    requested_measurements = measurement_audit(spec)
    add("requested_measurements", requested_measurements["status"] == "supported", requested_measurements)
    add("validation_reference", reference["comparison_passed"], reference)
    if "design_model_ready" in validation:
        add(
            "model_fidelity_for_declared_use",
            bool(validation.get("design_model_ready")),
            validation.get("model_limitations") or "model fidelity review required",
        )
    mesh_independence_required = bool(validation.get("mesh_independence_required", True))
    mesh_evidence = validation.get("mesh_independence_evidence") if isinstance(validation.get("mesh_independence_evidence"), dict) else {}
    mesh_independence_passed = bool(mesh_evidence.get("passed")) if mesh_evidence else (False if mesh_independence_required else None)
    add("mesh_independence", mesh_independence_passed, mesh_evidence or "separate multi-mesh evidence required", mesh_independence_required)
    smoke_passed = all(row["passed"] is True for row in gates if row["name"] in {"solver_reached_end", "no_fatal_error", "mesh_ok"})
    design_required = [row for row in gates if row["required"]]
    design_ready = bool(design_required) and all(row["passed"] is True for row in design_required)
    numerical_exclusions = {"requested_measurements", "validation_reference", "model_fidelity_for_declared_use", "mesh_independence"}
    numerical_required = [row for row in design_required if row["name"] not in numerical_exclusions]
    numerically_converged = bool(numerical_required) and all(row["passed"] is True for row in numerical_required)
    if design_ready:
        classification = "validated_for_declared_use"
    elif numerically_converged and mesh_independence_passed:
        classification = "mesh_independent"
    elif numerically_converged:
        classification = "numerically_converged"
    elif smoke_passed:
        classification = "bounded_solver_smoke"
    else:
        classification = "incomplete_or_failed"
    return {
        "smoke_passed": smoke_passed,
        "numerically_converged": numerically_converged,
        "design_ready": design_ready,
        "classification": classification,
        "gates": gates,
        "blocking_gates": [row["name"] for row in design_required if row["passed"] is not True],
    }


def _render_mesh_shell(template: str, refinement_passes: int = 0) -> str:
    plan = template_runtime_plan(template)
    refinement_passes = max(0, min(int(refinement_passes or 0), 2))
    if template == "compressible_nozzle":
        # The generated blockMeshDict already carries the reviewed 1.0/1.5/2.0
        # directional resolution. Do not recursively refine it again.
        refinement_passes = 0
    cleanup = "rm -f log.blockMesh log.checkMesh log.solver; "
    if not bool(plan.get("preserve_poly_mesh")):
        cleanup += "rm -rf constant/polyMesh; "
    commands = [cleanup]
    refinement_inserted = False
    for label, command in plan.get("mesh_steps") or []:
        insertion_point = label == "topoSet" if template == "conjugate_heat_transfer" else label.startswith("checkMesh")
        if refinement_passes and insertion_point and not refinement_inserted:
            for index in range(refinement_passes):
                commands.append(
                    f"printf '%s\\n' 'AERO_STAGE refineMesh_{index + 1}'; refineMesh -all -overwrite 2>&1; rc=$?; [ $rc -eq 0 ] || exit $rc; "
                )
            refinement_inserted = True
        commands.append(
            f"printf '%s\\n' 'AERO_STAGE {label}'; {command} 2>&1; rc=$?; [ $rc -eq 0 ] || exit $rc; "
        )
    return "".join(commands)


def _live_template_mesh_preflight(case_path: Path, spec: dict[str, Any]) -> dict[str, Any]:
    engineering_hooks = _runtime_hooks()
    _, vm_case, staged = engineering_hooks._stage_case_to_openfoam_runtime(
        case_path,
        f"pipeline_preflight_{_slug(str(spec.get('spec_id') or spec.get('template') or 'case'))}",
    )
    if not staged.get("ok"):
        return staged
    runtime = staged["runtime"]
    container = str(runtime["container"])
    source_cmd = str(runtime["source_cmd"])
    template = str(spec.get("template") or "compressible_nozzle")
    refinement_passes = int((spec.get("mesh") or {}).get("refinement_passes") or 0)
    command = f"cd {vm_case!r} && {source_cmd} >/tmp/aero_openfoam_source.log 2>&1; {_render_mesh_shell(template, refinement_passes)}"
    result = engineering_hooks._docker_exec(container, command, timeout=300)
    stdout = str(result.get("stdout") or "")
    metrics = _initial_metrics()
    for line in stdout.splitlines():
        for event in parse_openfoam_line(line, "mesh_preflight"):
            _merge_telemetry(metrics, event)
    expected = 2 if template == "conjugate_heat_transfer" else 1
    mesh_ok_count = stdout.count("Mesh OK")
    return {
        "ok": bool(result.get("ok")) and mesh_ok_count >= expected,
        "template": template,
        "runtime": runtime,
        "vm_case": vm_case,
        "returncode": result.get("returncode"),
        "duration_sec": result.get("duration_sec"),
        "mesh_ok_count": mesh_ok_count,
        "expected_mesh_ok_count": expected,
        "metrics": metrics.get("mesh") or {},
        "stdout_tail": stdout[-12000:],
        "stderr_tail": str(result.get("stderr") or "")[-4000:],
    }


class OpenFOAMPipeline:
    def __init__(self, root: Path | None = None):
        self.root = (root or _default_root()).resolve()
        self.specs_dir = self.root / "specs"
        self.cases_dir = self.root / "cases"
        self.runs_dir = self.root / "runs"
        self.studies_dir = self.root / "studies"
        self.exports_dir = self.root / "exports"
        self.imports_dir = self.root / "cad_imports"
        for path in (self.specs_dir, self.cases_dir, self.runs_dir, self.studies_dir, self.exports_dir, self.imports_dir):
            path.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._spec_lock = threading.RLock()
        self._processes: dict[str, subprocess.Popen[str]] = {}
        self._threads: dict[str, threading.Thread] = {}
        self._recover_interrupted_runs()

    def _recover_interrupted_runs(self) -> None:
        for state_path in self.runs_dir.glob("*/state.json"):
            state = _read_json(state_path)
            if state.get("status") in {"queued", "preflighting", "staging", "running", "cancelling"}:
                state["status"] = "interrupted"
                state["ended_at"] = _utc_now()
                state["error"] = "aero_process_restarted_run_requires_explicit_resume_or_branch"
                _atomic_json(state_path, state)
        for state_path in self.runs_dir.glob("*/state.json"):
            state = _read_json(state_path)
            if state.get("status") in TERMINAL_STATES:
                self._ensure_evidence_manifest(str(state.get("run_id") or state_path.parent.name))

    def status(self) -> dict[str, Any]:
        runs = [self._load_state(path.parent.name) for path in self.runs_dir.glob("*/state.json")]
        counts: dict[str, int] = {}
        for run in runs:
            counts[str(run.get("status") or "unknown")] = counts.get(str(run.get("status") or "unknown"), 0) + 1
        capabilities = [
            "typed_case_spec",
            "requested_measurement_admission",
            "independent_reference_provenance_admission",
            "case_generation",
            "static_and_live_preflight",
            "durable_background_runs",
            "streaming_telemetry",
            "cancel",
            "bounded_runtime_adjustment",
            "run_branching",
            "mesh_independence_studies",
            "convergence_and_validation_gates",
            "teaching_report",
            "first_principles_and_correlation_screening",
            "fidelity_ladders",
            "boundary_turbulence_yplus_review",
            "imported_cad_quality_gates",
            "audited_cad_import_registration",
            "uncertainty_margin_risk_reporting",
            "sandboxed_unit_aware_notebooks",
            "opencascade_step_iges_import_and_repair",
            "tolerance_stack_worst_case_rss_monte_carlo",
            "cad_interface_and_dimension_extraction",
            "tolerance_geometry_variants",
            "tolerance_variant_cfd_studies",
            "tolerance_sensitivity_uncertainty_margin_reporting",
            "pmi_gdt_human_confirmation",
        ]
        if not _is_blue_profile():
            capabilities.extend(["fluent_mesh_export", "evidence_gated_fluent_comparison"])
        study_suite = _read_json(STUDY_SUITE_MANIFEST)
        if _is_blue_profile() and isinstance(study_suite.get("modules"), list):
            study_suite["modules"] = [
                row for row in study_suite["modules"]
                if str(row.get("id") or row.get("name") or "").lower() != "fluent_nozzle_mirror"
                and "fluent" not in str(row.get("id") or row.get("name") or "").lower()
            ]
            study_suite["runtime_root"] = str(self.root)
        runtime = _runtime_hooks().runtime_status() if _is_blue_profile() else None
        return {
            "ok": True,
            "schema": SCHEMA_VERSION,
            "root": str(self.root),
            "templates": template_catalog(),
            "study_suite": study_suite,
            "runtime": runtime,
            "run_counts": counts,
            "active_runs": [row for row in runs if row.get("status") not in TERMINAL_STATES],
            "capabilities": capabilities,
        }

    @_spec_synchronized
    def create_spec(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        incoming = copy.deepcopy(payload or {})
        incoming_validation = incoming.get("validation") if isinstance(incoming.get("validation"), dict) else {}
        # Mesh-independence is derived evidence. It may only be attached by a
        # successful compare_runs provenance check, never asserted by a caller.
        incoming_validation.pop("mesh_independence_evidence", None)
        template = str(incoming.get("template") or "compressible_nozzle").strip()
        base = default_template_spec(template, str(incoming.get("name") or ""))

        def merge(target: dict[str, Any], source: dict[str, Any]) -> None:
            for key, value in source.items():
                if isinstance(value, dict) and isinstance(target.get(key), dict):
                    merge(target[key], value)
                else:
                    target[key] = copy.deepcopy(value)

        merge(base, incoming)
        spec_id = _slug(str(base.get("spec_id") or f"spec_{int(time.time())}_{uuid.uuid4().hex[:8]}"), "spec")
        base["spec_id"] = spec_id
        base["schema"] = SPEC_SCHEMA
        base["created_at"] = str(base.get("created_at") or _utc_now())
        base["updated_at"] = _utc_now()
        base["engineering_readiness"] = build_readiness_contract(base)
        validation = validate_spec(base)
        base["spec_validation"] = validation
        _atomic_json(self.specs_dir / f"{spec_id}.json", base)
        return {"ok": validation["ok"], "spec": base, "validation": validation}

    def export_fluent_mesh(self, spec_id: str) -> dict[str, Any]:
        """Build a reviewed single-region mesh and convert it for Fluent import."""
        if _is_blue_profile():
            return {"ok": False, "error": "fluent_disabled_in_aero_blue", "profile": "blue"}
        spec_result = self.get_spec(spec_id)
        if not spec_result.get("ok"):
            return spec_result
        spec = spec_result["spec"]
        template = str(spec.get("template") or "")
        if template == "conjugate_heat_transfer":
            return {
                "ok": False,
                "error": "multiregion_fluent_export_requires_reviewed_region_merge",
                "template": template,
            }
        preflight = self.preflight(spec_id, live_mesh=True)
        if not preflight.get("run_allowed"):
            return {"ok": False, "error": "preflight_failed", "preflight": preflight}
        engineering_hooks = _runtime_hooks()
        local_case = Path(str(preflight["case_path"]))
        _, vm_case, staged = engineering_hooks._stage_case_to_openfoam_runtime(
            local_case, f"fluent_export_{spec_id}"
        )
        if not staged.get("ok"):
            return {"ok": False, "error": "openfoam_stage_failed", "detail": staged}
        runtime = staged["runtime"]
        container = str(runtime["container"])
        source_cmd = str(runtime["source_cmd"])
        command = (
            f"cd {vm_case!r} && {source_cmd} >/tmp/aero_openfoam_source.log 2>&1; "
            f"{_render_mesh_shell(template, int((spec.get('mesh') or {}).get('refinement_passes') or 0))}"
            "printf '%s\\n' 'AERO_STAGE foamMeshToFluent'; "
            "foamMeshToFluent -noFunctionObjects 2>&1; "
            "find fluentInterface -type f -name '*.msh' -print | sort | tail -n 1"
        )
        converted = engineering_hooks._docker_exec(container, command, timeout=300)
        if not converted.get("ok"):
            return {
                "ok": False,
                "error": "foam_mesh_to_fluent_failed",
                "detail": str(converted.get("stderr") or converted.get("stdout") or "")[-4000:],
            }
        candidates = [line.strip() for line in str(converted.get("stdout") or "").splitlines() if line.strip().endswith(".msh")]
        if not candidates:
            return {"ok": False, "error": "fluent_mesh_output_missing", "detail": str(converted.get("stdout") or "")[-4000:]}
        relative_mesh = candidates[-1].replace("\\", "/")
        if relative_mesh.startswith("/") or ".." in Path(relative_mesh).parts:
            return {"ok": False, "error": "unsafe_fluent_mesh_output", "path": relative_mesh}
        destination_dir = self.exports_dir / _slug(spec_id) / "fluent"
        if destination_dir.exists():
            shutil.rmtree(destination_dir)
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination = destination_dir / Path(relative_mesh).name
        copied = engineering_hooks._run(
            [engineering_hooks._docker(), "cp", f"{container}:{vm_case}/{relative_mesh}", str(destination)],
            timeout=300,
        )
        if not copied.get("ok") or not destination.is_file():
            return {"ok": False, "error": "fluent_mesh_copy_failed", "detail": str(copied.get("stderr") or "")[-1000:]}
        manifest = {
            "schema": "aero_fluent_mesh_export_v1",
            "generated_at": _utc_now(),
            "spec_id": spec_id,
            "template": template,
            "source_case": str(local_case),
            "converter": "OpenFOAM Foundation v10 foamMeshToFluent",
            "mesh_preflight": preflight.get("live_mesh"),
            "fluent_mesh": _artifact(destination),
            "trust_boundary": "Import-ready mesh conversion; Fluent physics, units, boundaries, convergence, and validation still require review.",
        }
        manifest_path = destination_dir / "manifest.json"
        _atomic_json(manifest_path, manifest)
        return {"ok": True, "spec_id": spec_id, "template": template, "mesh": str(destination), "manifest": str(manifest_path), "preflight": preflight}

    @_spec_synchronized
    def update_spec(self, spec_id: str, patch: dict[str, Any]) -> dict[str, Any]:
        patch_validation = patch.get("validation") if isinstance(patch.get("validation"), dict) else {}
        if "mesh_independence_evidence" in patch_validation:
            return {
                "ok": False,
                "error": "mesh_independence_evidence_is_derived",
                "required_operation": "compare_runs",
            }
        loaded = self.get_spec(spec_id)
        if not loaded.get("ok"):
            return loaded
        spec = copy.deepcopy(loaded["spec"])

        def merge(target: dict[str, Any], source: dict[str, Any]) -> None:
            for key, value in source.items():
                if key in {"spec_id", "schema", "created_at"}:
                    continue
                if isinstance(value, dict) and isinstance(target.get(key), dict):
                    merge(target[key], value)
                else:
                    target[key] = copy.deepcopy(value)

        merge(spec, patch)
        spec["spec_id"] = spec_id
        spec["schema"] = SPEC_SCHEMA
        spec["updated_at"] = _utc_now()
        spec["engineering_readiness"] = build_readiness_contract(spec)
        validation = validate_spec(spec)
        spec["spec_validation"] = validation
        _atomic_json(self.specs_dir / f"{_slug(spec_id)}.json", spec)
        return {"ok": validation["ok"], "spec": spec, "validation": validation}

    def get_spec(self, spec_id: str) -> dict[str, Any]:
        safe = _slug(spec_id, "")
        path = self.specs_dir / f"{safe}.json"
        if not safe or not path.exists():
            return {"ok": False, "error": "spec_not_found", "spec_id": spec_id}
        return {"ok": True, "spec": _read_json(path)}

    def readiness(self, spec_id: str, run_id: str | None = None) -> dict[str, Any]:
        loaded = self.get_spec(spec_id)
        if not loaded.get("ok"):
            return loaded
        metrics: dict[str, Any] = {}
        if run_id:
            state = self.get_run(run_id)
            if not state.get("run_id") or state.get("spec_id") != spec_id:
                return {
                    "ok": False,
                    "error": "run_not_found_or_spec_mismatch",
                    "spec_id": spec_id,
                    "run_id": run_id,
                }
            metrics = state.get("metrics") or {}
        return {
            "ok": True,
            "spec_id": spec_id,
            "run_id": run_id,
            "readiness": build_readiness_contract(loaded["spec"], metrics),
        }

    def register_imported_cad(self, source: Path, metadata: dict[str, Any]) -> dict[str, Any]:
        """Validate and immutably register imported CAD without attempting repair."""
        source = Path(source).resolve()
        suffix = source.suffix.lower()
        if not source.is_file() or suffix not in {".stl", ".step", ".stp", ".iges", ".igs"}:
            return {"ok": False, "error": "supported_cad_file_required"}
        size = source.stat().st_size
        if size <= 0 or size > 512 * 1024 * 1024:
            return {"ok": False, "error": "cad_file_size_out_of_range", "bytes": size}
        manifest: dict[str, Any] = {
            "schema": "aero_imported_cad_manifest_v1",
            "provenance": "IMPORTED",
            "source_name": source.name,
            "source_sha256": _sha256(source),
            "bytes": size,
            "format": suffix.lstrip("."),
            "units": str(metadata.get("units") or "").strip(),
            "named_boundaries": metadata.get("named_boundaries") if isinstance(metadata.get("named_boundaries"), list) else [],
            "repairs": metadata.get("repairs") if isinstance(metadata.get("repairs"), list) else [],
            "watertight": False,
            "manifold": False,
            "volume_m3": None,
        }
        tool_evidence: dict[str, Any] = {}
        if suffix == ".stl":
            runtime = _runtime_hooks()
            checked = runtime._docker_exec(
                str((runtime.runtime_status() or {}).get("container") or ""),
                f"{(runtime.runtime_status() or {}).get('source_cmd')} >/dev/null 2>&1; surfaceCheck {shlex.quote(str(source))}",
                timeout=120,
            )
            output = str(checked.get("stdout") or "") + "\n" + str(checked.get("stderr") or "")
            closed = bool(re.search(r"surface is closed", output, re.IGNORECASE)) and not bool(re.search(r"not closed", output, re.IGNORECASE))
            illegal = re.search(r"illegal triangles\s*[:=]\s*(\d+)", output, re.IGNORECASE)
            manifest["watertight"] = closed
            manifest["manifold"] = closed and (illegal is None or int(illegal.group(1)) == 0)
            raw_volume = _stl_enclosed_volume(source)
            declared_scale = {"m": 1.0, "mm": 1.0e-3, "cm": 1.0e-2}.get(manifest["units"])
            if raw_volume is not None and declared_scale:
                manifest["volume_m3"] = raw_volume * declared_scale**3
            tool_evidence = {
                "tool": "OpenFOAM surfaceCheck",
                "ok": bool(checked.get("ok")),
                "output_tail": output[-4000:],
            }
        else:
            tool_evidence = {
                "tool": None,
                "ok": False,
                "reason": "STEP/IGES topology requires a reviewed CAD-kernel adapter before registration",
            }
        audit = audit_imported_cad(manifest)
        result = {"ok": audit.get("status") == "pass", "manifest": manifest, "audit": audit, "tool_evidence": tool_evidence}
        if not result["ok"]:
            result["error"] = "cad_import_quality_gate_blocked"
            return result
        import_id = f"cad_{manifest['source_sha256'][:16]}"
        destination = self.imports_dir / import_id
        destination.mkdir(parents=True, exist_ok=True)
        retained = destination / ("source" + suffix)
        shutil.copy2(source, retained)
        manifest["retained_path"] = str(retained)
        manifest["registered_at"] = _utc_now()
        _atomic_json(destination / "manifest.json", manifest)
        _atomic_json(destination / "audit.json", audit)
        return {**result, "import_id": import_id, "retained_path": str(retained)}

    def list_specs(self) -> dict[str, Any]:
        specs = [_read_json(path) for path in sorted(self.specs_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)]
        return {"ok": True, "specs": specs}

    @_spec_synchronized
    def generate_case(self, spec_id: str) -> dict[str, Any]:
        loaded = self.get_spec(spec_id)
        if not loaded.get("ok"):
            return loaded
        spec = loaded["spec"]
        destination = self.cases_dir / _slug(spec_id) / "current"
        result = build_case(spec, destination)
        if result.get("ok"):
            result["spec_id"] = spec_id
        return result

    @_spec_synchronized
    def preflight(self, spec_id: str, live_mesh: bool = False) -> dict[str, Any]:
        loaded = self.get_spec(spec_id)
        if not loaded.get("ok"):
            return loaded
        spec = loaded["spec"]
        spec_validation = validate_spec(spec)
        generated = self.generate_case(spec_id) if spec_validation["ok"] else {"ok": False, "error": "invalid_spec"}
        checks: list[dict[str, Any]] = []

        def check(name: str, ok: bool, evidence: Any, severity: str = "error") -> None:
            checks.append({"name": name, "ok": bool(ok), "severity": severity, "evidence": evidence})

        check("spec_valid", spec_validation["ok"], spec_validation)
        check("case_generated", bool(generated.get("ok")), generated.get("case_path") or generated.get("error"))
        dynamic: dict[str, Any] = {}
        if generated.get("ok"):
            case_path = Path(str(generated["case_path"]))
            required_files = ["system/controlDict", "system/fvSchemes", "system/fvSolution"]
            physics = spec.get("physics") if isinstance(spec.get("physics"), dict) else {}
            template = str(spec.get("template") or "")
            flow_regime = str(physics.get("flow_regime") or "").lower()
            is_compressible = "compressible" in flow_regime and "incompressible" not in flow_regime
            if template == "conjugate_heat_transfer":
                required_files.extend(
                    [
                        "constant/regionProperties",
                        "constant/fluid/physicalProperties",
                        "constant/solid/physicalProperties",
                        "system/fluid/fvSchemes",
                        "system/fluid/fvSolution",
                        "system/solid/fvSchemes",
                        "system/solid/fvSolution",
                        "0/fluid/T",
                        "0/solid/T",
                    ]
                )
            elif bool(physics.get("energy")) or is_compressible:
                required_files.append("constant/thermophysicalProperties")
            for relative in required_files:
                check(f"file_{relative.replace('/', '_')}", (case_path / relative).is_file(), relative)
            if template not in {"compressible_nozzle", "conjugate_heat_transfer"}:
                property_candidates = [case_path / "constant" / "physicalProperties", case_path / "constant" / "transportProperties"]
                check(
                    "file_constant_fluid_properties",
                    any(path.is_file() for path in property_candidates),
                    [str(path.relative_to(case_path)).replace("\\", "/") for path in property_candidates],
                )
            control = (case_path / "system" / "controlDict").read_text(encoding="utf-8", errors="replace")
            check("runtime_modifiable", bool(re.search(r"\brunTimeModifiable\s+true\s*;", control)), "controlDict")
            solver = str(spec["numerics"]["solver"])
            check("solver_matches_spec", bool(re.search(rf"\bapplication\s+{re.escape(solver)}\s*;", control)), solver)
            patch_sources = []
            for candidate in (case_path / "system" / "blockMeshDict", case_path / "constant" / "polyMesh" / "boundary"):
                if candidate.exists():
                    patch_sources.append(candidate.read_text(encoding="utf-8", errors="replace"))
            for field_path in sorted((case_path / "0").rglob("*")) if (case_path / "0").exists() else []:
                if field_path.is_file():
                    patch_sources.append(field_path.read_text(encoding="utf-8", errors="replace"))
            declared_patch_text = "\n".join(patch_sources)
            missing_patches = [name for name in spec["boundaries"]["required_patches"] if not re.search(rf"\b{re.escape(str(name))}\b", declared_patch_text)]
            check("required_patches_declared", not missing_patches, {"missing": missing_patches})
            if live_mesh:
                dynamic = _live_template_mesh_preflight(case_path, spec)
                check("live_blockMesh_checkMesh", bool(dynamic.get("ok")), dynamic.get("metrics") or dynamic.get("error"))
        errors = [row for row in checks if not row["ok"] and row["severity"] == "error"]
        warnings = list(spec_validation.get("warnings") or [])
        result = {
            "ok": not errors,
            "schema": SCHEMA_VERSION,
            "spec_id": spec_id,
            "case_path": generated.get("case_path"),
            "checks": checks,
            "errors": errors,
            "warnings": warnings,
            "live_mesh": dynamic,
            "run_allowed": not errors,
            "design_use_allowed": not errors and not warnings,
        }
        preflight_path = self.cases_dir / _slug(spec_id) / "preflight.json"
        _atomic_json(preflight_path, result)
        return result

    def _run_dir(self, run_id: str) -> Path:
        return self.runs_dir / _slug(run_id, "invalid")

    def _evidence_manifest_path(self, run_id: str) -> Path:
        return self._run_dir(run_id) / "evidence_manifest.json"

    def _evidence_candidates(self, run_id: str) -> list[Path]:
        run_dir = self._run_dir(run_id)
        return [
            run_dir / "state.json",
            run_dir / "spec.json",
            run_dir / "preflight.json",
            run_dir / "solver.log",
            run_dir / "telemetry.jsonl",
            run_dir / "events.jsonl",
            run_dir / "report.md",
            run_dir / "engineering-readiness.json",
            run_dir / "case_input" / "aero_case_manifest.json",
            run_dir / "case_result" / "aero_result_manifest.json",
        ]

    def _write_evidence_manifest(self, run_id: str) -> dict[str, Any]:
        run_dir = self._run_dir(run_id)
        files = []
        for path in self._evidence_candidates(run_id):
            if path.is_file():
                files.append(
                    {
                        "relative_path": str(path.relative_to(run_dir)).replace("\\", "/"),
                        "bytes": path.stat().st_size,
                        "sha256": _sha256(path),
                    }
                )
        manifest = {
            "schema": "aero_openfoam_evidence_manifest_v1",
            "generated_at": _utc_now(),
            "run_id": run_id,
            "hash_algorithm": "sha256",
            "files": files,
            "self_hash_excluded": True,
        }
        _atomic_json(self._evidence_manifest_path(run_id), manifest)
        return manifest

    def verify_evidence_manifest(self, run_id: str) -> dict[str, Any]:
        path = self._evidence_manifest_path(run_id)
        manifest = _read_json(path)
        if not manifest:
            return {"ok": False, "error": "evidence_manifest_missing", "run_id": run_id}
        run_dir = self._run_dir(run_id)
        mismatches = []
        for row in manifest.get("files") or []:
            relative = str(row.get("relative_path") or "")
            candidate = (run_dir / relative).resolve()
            if run_dir.resolve() not in candidate.parents or not candidate.is_file():
                mismatches.append({"relative_path": relative, "error": "missing_or_unsafe"})
                continue
            actual = _sha256(candidate)
            if actual != row.get("sha256") or candidate.stat().st_size != int(row.get("bytes") or -1):
                mismatches.append(
                    {
                        "relative_path": relative,
                        "expected_sha256": row.get("sha256"),
                        "actual_sha256": actual,
                    }
                )
        return {
            "ok": not mismatches,
            "run_id": run_id,
            "manifest_path": str(path),
            "file_count": len(manifest.get("files") or []),
            "mismatches": mismatches,
        }

    def _ensure_evidence_manifest(self, run_id: str) -> dict[str, Any]:
        verified = self.verify_evidence_manifest(run_id)
        if verified.get("ok"):
            return verified
        state = self._load_state(run_id)
        if not state.get("run_id"):
            return state
        artifacts = state.get("artifacts") if isinstance(state.get("artifacts"), dict) else {}
        artifacts.pop("state", None)
        artifacts.pop("events", None)
        state["artifacts"] = artifacts
        state["evidence_manifest"] = str(self._evidence_manifest_path(run_id))
        self._save_state(state)
        self._event(run_id, "evidence_manifest_rebuilt", reason=verified.get("error") or "hash_mismatch")
        self._write_evidence_manifest(run_id)
        return self.verify_evidence_manifest(run_id)

    def _load_state(self, run_id: str) -> dict[str, Any]:
        return _read_json(self._run_dir(run_id) / "state.json", {"ok": False, "error": "run_not_found", "run_id": run_id})

    def _save_state(self, state: dict[str, Any]) -> None:
        state["updated_at"] = _utc_now()
        _atomic_json(self._run_dir(str(state["run_id"])) / "state.json", state)

    def _append_jsonl(self, path: Path, payload: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, sort_keys=True) + "\n")

    def _event(self, run_id: str, kind: str, **payload: Any) -> None:
        self._append_jsonl(self._run_dir(run_id) / "events.jsonl", {"at": _utc_now(), "kind": kind, **payload})

    @_spec_synchronized
    def start_run(self, spec_id: str, *, live_mesh_preflight: bool = True, _engineering_permit=None) -> dict[str, Any]:
        candidate = self.get_spec(spec_id).get("spec", {})
        if candidate.get("engineering_control"):
            from Aero.engineering_validity.adapters import ENGINEERING_DISPATCH_PERMIT
            if _engineering_permit is not ENGINEERING_DISPATCH_PERMIT:
                return {"ok": False, "error": "engineering_campaign_admission_required"}
        preflight = self.preflight(spec_id, live_mesh=live_mesh_preflight)
        if not preflight.get("run_allowed"):
            return {"ok": False, "error": "preflight_failed", "preflight": preflight}
        spec = self.get_spec(spec_id)["spec"]
        run_id = _slug(f"run_{int(time.time())}_{uuid.uuid4().hex[:8]}", "run")
        run_dir = self._run_dir(run_id)
        run_dir.mkdir(parents=True, exist_ok=False)
        snapshot = copy.deepcopy(spec)
        _atomic_json(run_dir / "spec.json", snapshot)
        _atomic_json(run_dir / "preflight.json", preflight)
        run_case = build_case(snapshot, run_dir / "case_input")
        if not run_case.get("ok"):
            shutil.rmtree(run_dir)
            return {"ok": False, "error": "run_case_snapshot_failed", "detail": run_case}
        initial_metrics = _metrics_for_spec(snapshot)
        state = {
            "ok": True,
            "schema": RUN_SCHEMA,
            "run_id": run_id,
            "spec_id": spec_id,
            "status": "queued",
            "stage": "queued",
            "created_at": _utc_now(),
            "started_at": None,
            "ended_at": None,
            "case_path": run_case.get("case_path"),
            "input_spec_sha256": _json_sha256(snapshot),
            "input_case_manifest_sha256": _sha256(run_dir / "case_input" / "aero_case_manifest.json"),
            "vm_case": None,
            "runtime": None,
            "pid": None,
            "returncode": None,
            "error": None,
            "metrics": initial_metrics,
            "interventions": [],
            "gate_evaluation": evaluate_gates(snapshot, initial_metrics),
            "artifacts": {},
        }
        self._save_state(state)
        self._event(run_id, "queued", spec_id=spec_id)
        thread = threading.Thread(target=self._execute_run, args=(run_id,), name=f"openfoam-{run_id}", daemon=True)
        with self._lock:
            self._threads[run_id] = thread
        thread.start()
        return {"ok": True, "run_id": run_id, "status": "queued", "state_url": f"/tools/cfd/openfoam/runs/{run_id}"}

    def _finalize_prelaunch_cancel(self, state: dict[str, Any], spec: dict[str, Any]) -> None:
        state["ended_at"] = _utc_now()
        state["status"] = "finalizing"
        state["stage"] = "collecting_artifacts"
        state["provisional_status"] = "cancelled"
        self._save_state(state)
        state["artifact_collection"] = self._collect_runtime_case(state)
        state["postprocessing_ingest"] = self._ingest_postprocessing(state)
        state["runtime_scratch_cleanup"] = self._cleanup_runtime_case(state)
        state["status"] = "cancelled"
        state["stage"] = "finished"
        state.pop("provisional_status", None)
        self._finalize_run(state, spec)

    def _execute_run(self, run_id: str) -> None:
        run_dir = self._run_dir(run_id)
        state = self._load_state(run_id)
        spec = _read_json(run_dir / "spec.json")
        try:
            engineering_hooks = _runtime_hooks()
            with self._lock:
                state = self._load_state(run_id)
                cancel_before_staging = state.get("status") == "cancelling"
                if not cancel_before_staging:
                    state["status"] = "staging"
                    state["stage"] = "staging"
                    state["started_at"] = _utc_now()
                    self._save_state(state)
            if cancel_before_staging:
                self._finalize_prelaunch_cancel(state, spec)
                return
            local_case = Path(str(state["case_path"]))
            _, vm_case, staged = engineering_hooks._stage_case_to_openfoam_runtime(local_case, f"pipeline_{run_id}")
            if not staged.get("ok"):
                raise RuntimeError(str(staged.get("error") or "openfoam_stage_failed"))
            runtime = staged["runtime"]
            container = str(runtime["container"])
            source_cmd = str(runtime["source_cmd"])
            solver = str(spec["numerics"]["solver"])
            timeout_sec = int(spec["numerics"].get("timeout_sec") or 180)
            template = str(spec.get("template") or "compressible_nozzle")
            first_stage = str((template_runtime_plan(template).get("mesh_steps") or [["mesh"]])[0][0])
            with self._lock:
                state.update({"stage": first_stage, "vm_case": vm_case, "runtime": runtime})
                self._sync_external_run_controls(state)
                cancel_after_staging = state.get("status") == "cancelling"
                if not cancel_after_staging:
                    state["status"] = "running"
                self._save_state(state)
            if cancel_after_staging:
                self._finalize_prelaunch_cancel(state, spec)
                return
            command = (
                f"cd {vm_case!r} && {source_cmd} >/tmp/aero_openfoam_source.log 2>&1; "
                f"{_render_mesh_shell(template, int((spec.get('mesh') or {}).get('refinement_passes') or 0))}"
                f"setsid timeout {timeout_sec}s {solver} 2>&1 & "
                "solver_pgid=$!; printf '%s' \"$solver_pgid\" > .aero_solver.pgid; "
                "actual_pgid=''; for attempt in $(seq 1 100); do "
                "actual_pgid=$(ps -o pgid= -p \"$solver_pgid\" 2>/dev/null | tr -d ' '); "
                "[ \"$actual_pgid\" = \"$solver_pgid\" ] && break; sleep 0.01; done; "
                "[ \"$actual_pgid\" = \"$solver_pgid\" ] || exit 125; "
                "printf '%s\\n' 'AERO_STAGE solver'; wait $solver_pgid"
            )
            with self._lock:
                self._sync_external_run_controls(state)
                cancel_before_launch = state.get("status") == "cancelling"
                if cancel_before_launch:
                    proc = None
                else:
                    proc = _spawn_runtime_process(engineering_hooks, container, command)
                    self._processes[run_id] = proc
                    state["pid"] = proc.pid
                    self._save_state(state)
            if cancel_before_launch or proc is None:
                self._finalize_prelaunch_cancel(state, spec)
                return
            log_path = run_dir / "solver.log"
            last_save = 0.0
            current_stage = "blockMesh"
            with log_path.open("a", encoding="utf-8") as log_handle:
                for raw_line in iter(proc.stdout.readline, "") if proc.stdout else []:
                    line = raw_line.rstrip("\r\n")
                    log_handle.write(raw_line)
                    log_handle.flush()
                    stage_match = re.match(r"AERO_STAGE\s+(\S+)", line)
                    if stage_match:
                        current_stage = stage_match.group(1)
                        state["stage"] = current_stage
                        self._event(run_id, "stage", stage=current_stage)
                    for telemetry in parse_openfoam_line(line, current_stage):
                        self._append_jsonl(run_dir / "telemetry.jsonl", telemetry)
                        _merge_telemetry(state["metrics"], telemetry)
                        self._auto_adjust_if_needed(run_id, state, spec, telemetry)
                    if time.monotonic() - last_save >= 0.5:
                        self._sync_external_run_controls(state)
                        state["gate_evaluation"] = evaluate_gates(spec, state["metrics"])
                        self._save_state(state)
                        last_save = time.monotonic()
            returncode = proc.wait()
            self._sync_external_run_controls(state)
            state["returncode"] = returncode
            state["ended_at"] = _utc_now()
            state["gate_evaluation"] = evaluate_gates(spec, state["metrics"])
            if state.get("status") == "cancelling":
                final_status = "cancelled"
            elif returncode == 0 and state["gate_evaluation"]["smoke_passed"]:
                final_status = "completed"
            else:
                final_status = "failed"
                state["error"] = state.get("error") or f"solver_exit_{returncode}"
            # Publish a non-controllable finalization phase before artifact copying.
            # Otherwise a late pause/cancel request can be accepted after the solver
            # has already exited and then be overwritten by the finishing worker.
            state["status"] = "finalizing"
            state["stage"] = "collecting_artifacts"
            state["provisional_status"] = final_status
            self._save_state(state)
            state["artifact_collection"] = self._collect_runtime_case(state)
            state["postprocessing_ingest"] = self._ingest_postprocessing(state)
            state["runtime_scratch_cleanup"] = self._cleanup_runtime_case(state)
            state["status"] = final_status
            state["stage"] = "finished"
            state.pop("provisional_status", None)
            self._finalize_run(state, spec)
        except Exception as exc:
            state["ended_at"] = _utc_now()
            state["error"] = f"{type(exc).__name__}:{exc}"
            self._event(run_id, "error", error=state["error"])
            state["status"] = "finalizing"
            state["stage"] = "collecting_artifacts"
            state["provisional_status"] = "failed"
            self._save_state(state)
            state["artifact_collection"] = self._collect_runtime_case(state)
            state["postprocessing_ingest"] = self._ingest_postprocessing(state)
            state["runtime_scratch_cleanup"] = self._cleanup_runtime_case(state)
            state["status"] = "failed"
            state["stage"] = "finished"
            state.pop("provisional_status", None)
            self._finalize_run(state, spec)
        finally:
            with self._lock:
                self._processes.pop(run_id, None)
                self._threads.pop(run_id, None)

    def _cleanup_runtime_case(self, state: dict[str, Any]) -> dict[str, Any]:
        """Delete only the staged scratch copy after retained artifacts exist."""
        vm_case = str(state.get("vm_case") or "").strip()
        if not vm_case:
            return {"ok": True, "skipped": "runtime_case_not_staged"}
        if not _runtime_case_path_allowed(vm_case):
            return {"ok": False, "error": "runtime_case_cleanup_path_denied", "path": vm_case}
        runtime = state.get("runtime") if isinstance(state.get("runtime"), dict) else {}
        container = str(runtime.get("container") or "")
        cleaned = _runtime_hooks()._docker_exec(
            container,
            f"rm -rf -- {shlex.quote(vm_case)}",
            timeout=120,
        )
        return {
            "ok": bool(cleaned.get("ok")),
            "path": vm_case,
            "error": cleaned.get("error") or (str(cleaned.get("stderr") or "")[-1000:] if not cleaned.get("ok") else None),
        }

    def _sync_external_run_controls(self, state: dict[str, Any]) -> None:
        """Merge control-plane writes without replacing live solver telemetry.

        The solver worker owns metrics while HTTP/chat control requests own pause,
        resume, cancellation, and the intervention ledger. Both persist through the
        same state file, so the worker must reconcile those fields before saving its
        in-memory snapshot or it can erase a just-issued control action.
        """
        run_id = str(state.get("run_id") or "")
        if not run_id:
            return
        persisted = self._load_state(run_id)
        if not persisted.get("run_id"):
            return
        persisted_status = str(persisted.get("status") or "")
        current_status = str(state.get("status") or "")
        if persisted_status == "cancelling":
            state["status"] = "cancelling"
        elif persisted_status == "paused":
            state["status"] = "paused"
        elif current_status == "paused" and persisted_status == "running":
            state["status"] = "running"

        combined: dict[str, dict[str, Any]] = {}
        for row in list(state.get("interventions") or []) + list(persisted.get("interventions") or []):
            if not isinstance(row, dict):
                continue
            key = "|".join(
                (
                    str(row.get("at") or ""),
                    str(row.get("actor") or ""),
                    str(row.get("action") or ""),
                    str(row.get("entry") or ""),
                    str(row.get("value") or ""),
                )
            )
            combined[key] = copy.deepcopy(row)
        state["interventions"] = sorted(
            combined.values(),
            key=lambda row: (float(row.get("epoch") or 0.0), str(row.get("at") or "")),
        )

    def _auto_adjust_if_needed(self, run_id: str, state: dict[str, Any], spec: dict[str, Any], event: dict[str, Any]) -> None:
        if event.get("kind") != "courant":
            return
        policy = spec.get("automation") if isinstance(spec.get("automation"), dict) else {}
        if not bool(policy.get("auto_adjust")):
            return
        maximum = float(event.get("max") or 0.0)
        hard_limit = float(policy.get("courant_hard_limit") or 1.0)
        if maximum <= hard_limit:
            return
        interventions = state.setdefault("interventions", [])
        if len(interventions) >= int(policy.get("max_interventions") or 0):
            return
        cooldown = float(policy.get("cooldown_sec") or 5.0)
        if interventions and time.time() - float(interventions[-1].get("epoch") or 0.0) < cooldown:
            return
        current = float(state["metrics"].get("latest_delta_t") or spec["numerics"].get("delta_t") or 0.0)
        factor = float(policy.get("delta_t_reduction_factor") or 0.5)
        minimum = float(policy.get("minimum_delta_t") or 1.0e-12)
        target = max(minimum, current * factor)
        self._save_state(state)
        result = self._apply_adjustment(run_id, "set_delta_t", target, actor="auto_courant_policy")
        if result.get("ok"):
            state.update(self._load_state(run_id))

    def _apply_adjustment(self, run_id: str, action: str, value: Any, *, actor: str = "user") -> dict[str, Any]:
        state = self._load_state(run_id)
        frozen = _read_json(self._run_dir(run_id) / "spec.json")
        if frozen.get("engineering_control"):
            return {"ok": False, "error": "engineering_diagnosis_and_new_experiment_required"}
        if state.get("status") not in {"running", "paused"}:
            return {"ok": False, "error": "run_not_running", "status": state.get("status")}
        allowed = {
            "set_delta_t": ("deltaT", 1.0e-12, 1.0e6),
            "set_max_courant": ("maxCo", 1.0e-4, 10.0),
            "set_max_delta_t": ("maxDeltaT", 1.0e-12, 1.0e6),
            "set_write_interval": ("writeInterval", 1.0, 1000000000.0),
        }
        if action not in allowed:
            return {"ok": False, "error": "unsafe_or_unknown_adjustment", "allowed": sorted(allowed)}
        entry, lower, upper = allowed[action]
        try:
            number = float(value)
        except Exception:
            return {"ok": False, "error": "adjustment_value_not_numeric"}
        if not lower <= number <= upper:
            return {"ok": False, "error": "adjustment_out_of_range", "range": [lower, upper]}
        runtime = state.get("runtime") if isinstance(state.get("runtime"), dict) else {}
        container = str(runtime.get("container") or "")
        vm_case = str(state.get("vm_case") or "")
        if not container or not _runtime_case_path_allowed(vm_case):
            return {"ok": False, "error": "runtime_case_unavailable"}
        engineering_hooks = _runtime_hooks()
        rendered = str(int(number)) if entry == "writeInterval" else f"{number:.12g}"
        command = f"cd {vm_case!r} && foamDictionary system/controlDict -entry {entry} -set {rendered}"
        changed = engineering_hooks._docker_exec(container, command, timeout=20)
        if not changed.get("ok"):
            return {"ok": False, "error": "runtime_adjustment_failed", "detail": str(changed.get("stderr") or changed.get("stdout") or "")[-1000:]}
        local_control = Path(str(state.get("case_path") or "")) / "system" / "controlDict"
        if local_control.exists():
            text = local_control.read_text(encoding="utf-8", errors="replace")
            local_control.write_text(_replace_dict_entry(text, entry, rendered), encoding="utf-8")
        intervention = {
            "at": _utc_now(),
            "epoch": time.time(),
            "actor": actor,
            "action": action,
            "entry": entry,
            "value": number,
            "reason": "bounded runtime adjustment",
            "runtime_acknowledged": True,
        }
        state.setdefault("interventions", []).append(intervention)
        self._save_state(state)
        self._event(run_id, "intervention", **intervention)
        return {"ok": True, "run_id": run_id, "intervention": intervention}

    def control_run(self, run_id: str, action: str, value: Any = None) -> dict[str, Any]:
        action = str(action or "").strip().lower()
        if action in {"set_delta_t", "set_max_courant", "set_max_delta_t", "set_write_interval"}:
            return self._apply_adjustment(run_id, action, value)
        state = self._load_state(run_id)
        if action in {"pause", "resume"}:
            expected = "running" if action == "pause" else "paused"
            if state.get("status") != expected:
                return {"ok": False, "error": f"run_not_{expected}", "status": state.get("status")}
            runtime = state.get("runtime") if isinstance(state.get("runtime"), dict) else {}
            container = str(runtime.get("container") or "")
            vm_case = str(state.get("vm_case") or "")
            if not container or not _runtime_case_path_allowed(vm_case):
                return {"ok": False, "error": "runtime_case_unavailable"}
            engineering_hooks = _runtime_hooks()
            signal = "STOP" if action == "pause" else "CONT"
            changed = engineering_hooks._docker_exec(
                container,
                (
                    f"cd {vm_case!r} && test -f .aero_solver.pgid && "
                    "read -r supervisor < .aero_solver.pgid && "
                    "case \"$supervisor\" in (*[!0-9]*|'') exit 2;; esac; "
                    "for attempt in $(seq 1 20); do "
                    "actual_pgid=$(ps -o pgid= -p \"$supervisor\" 2>/dev/null | tr -d ' '); "
                    "pgid=${actual_pgid:-$supervisor}; "
                    "if [ -n \"$pgid\" ]; then "
                    f"kill -{signal} -- -\"$pgid\" 2>/dev/null && exit 0; "
                    "pids=$(ps -eo pid=,pgid= | awk -v pg=\"$pgid\" '$2 == pg {print $1}'); "
                    f"[ -n \"$pids\" ] && kill -{signal} $pids 2>/dev/null && exit 0; "
                    "fi; sleep 0.05; done; exit 1"
                ),
                timeout=20,
            )
            if not changed.get("ok"):
                return {
                    "ok": False,
                    "error": f"run_{action}_failed",
                    "detail": str(changed.get("stderr") or changed.get("stdout") or changed.get("error") or "")[-1000:],
                }
            state["status"] = "paused" if action == "pause" else "running"
            self._save_state(state)
            self._event(run_id, action)
            return {"ok": True, "run_id": run_id, "status": state["status"]}
        if action != "cancel":
            return {"ok": False, "error": "unsupported_control_action"}
        with self._lock:
            state = self._load_state(run_id)
            if state.get("status") not in {"queued", "staging", "running", "paused"}:
                return {"ok": False, "error": "run_not_active", "status": state.get("status")}
            state["status"] = "cancelling"
            self._save_state(state)
            process = self._processes.get(run_id)
        runtime = state.get("runtime") if isinstance(state.get("runtime"), dict) else {}
        container = str(runtime.get("container") or "")
        vm_case = str(state.get("vm_case") or "")
        if container and _runtime_case_path_allowed(vm_case):
            engineering_hooks = _runtime_hooks()
            engineering_hooks._docker_exec(
                container,
                (
                    f"cd {vm_case!r} && test -f .aero_solver.pgid && "
                    "read -r supervisor < .aero_solver.pgid && "
                    "case \"$supervisor\" in (*[!0-9]*|'') exit 2;; esac; "
                    "actual_pgid=$(ps -o pgid= -p \"$supervisor\" 2>/dev/null | tr -d ' '); "
                    "pgid=${actual_pgid:-$supervisor}; "
                    "if [ -n \"$pgid\" ]; then "
                    "kill -TERM -- -\"$pgid\" 2>/dev/null || true; "
                    "for attempt in $(seq 1 50); do "
                    "kill -0 -- -\"$pgid\" 2>/dev/null || exit 0; sleep 0.1; done; "
                    "kill -KILL -- -\"$pgid\" 2>/dev/null || true; "
                    "fi; exit 0"
                ),
                timeout=20,
            )
        if process and process.poll() is None:
            process.terminate()
        self._event(run_id, "cancel_requested")
        return {"ok": True, "run_id": run_id, "status": "cancelling"}

    def _collect_runtime_case(self, state: dict[str, Any]) -> dict[str, Any]:
        runtime = state.get("runtime") if isinstance(state.get("runtime"), dict) else {}
        container = str(runtime.get("container") or "")
        vm_case = str(state.get("vm_case") or "")
        run_id = str(state.get("run_id") or "")
        if not container or not _runtime_case_path_allowed(vm_case) or not run_id:
            return {"ok": False, "error": "runtime_case_unavailable"}
        destination = self._run_dir(run_id) / "case_result"
        if destination.exists():
            shutil.rmtree(destination)
        destination.mkdir(parents=True, exist_ok=True)
        engineering_hooks = _runtime_hooks()
        # OpenFOAM can leave relaxation scratch fields such as
        # ``tmp<kEpsilon:G>`` in a written time directory.  They are not result
        # fields and contain characters Windows cannot represent.  Remove only
        # these transient scratch files before copying the evidence bundle.
        sanitized = engineering_hooks._docker_exec(
            container,
            f"find {vm_case!r} -type f -name 'tmp<*' -print -delete",
            timeout=60,
        )
        if not sanitized.get("ok"):
            return {
                "ok": False,
                "error": "runtime_artifact_sanitize_failed",
                "detail": str(sanitized.get("stderr") or "")[-1000:],
            }
        excluded = [line for line in str(sanitized.get("stdout") or "").splitlines() if line.strip()]
        # Retain restartable initial/final fields and the complete scalar
        # postProcessing history.  Intermediate field snapshots are large and
        # redundant for the default teaching evidence bundle.
        trimmed = engineering_hooks._docker_exec(
            container,
            (
                f"cd {vm_case!r} && "
                "times=$(find . -mindepth 1 -maxdepth 1 -type d -printf '%f\\n' "
                "| awk '$0 ~ /^[0-9]+([.][0-9]+)?$/ {print}' | sort -g); "
                "latest=$(printf '%s\\n' \"$times\" | tail -n 1); "
                "for d in $times; do "
                "if [ \"$d\" != 0 ] && [ \"$d\" != \"$latest\" ]; then "
                "printf '%s\\n' \"$d\"; rm -rf -- \"$d\"; fi; done"
            ),
            timeout=120,
        )
        if not trimmed.get("ok"):
            return {"ok": False, "error": "runtime_artifact_trim_failed", "detail": str(trimmed.get("stderr") or "")[-1000:]}
        excluded_time_directories = [line for line in str(trimmed.get("stdout") or "").splitlines() if line.strip()]
        # Keep the transfer archive beside the staged case.  The portable Blue
        # runtime deliberately permits copies only from its isolated runtime
        # root; a global /tmp archive would cross that boundary and discard the
        # solved field files even after a successful solver exit.
        runtime_parent = vm_case.rsplit("/", 1)[0]
        archive_vm = f"{runtime_parent}/.aero_result_{_slug(run_id)}.tar"
        packed = engineering_hooks._docker_exec(
            container,
            f"rm -f {archive_vm!r} && tar -cf {archive_vm!r} -C {vm_case!r} .",
            timeout=300,
        )
        if not packed.get("ok"):
            return {"ok": False, "error": "runtime_artifact_pack_failed", "detail": str(packed.get("stderr") or "")[-1000:]}
        local_archive = self._run_dir(run_id) / "case_result.tar"
        copied = engineering_hooks._run(
            [engineering_hooks._docker(), "cp", f"{container}:{archive_vm}", str(local_archive)],
            timeout=300,
        )
        engineering_hooks._docker_exec(container, f"rm -f {archive_vm!r}", timeout=30)
        if not copied.get("ok"):
            return {"ok": False, "error": "runtime_artifact_copy_failed", "detail": str(copied.get("stderr") or "")[-1000:]}
        try:
            with tarfile.open(local_archive, "r:") as archive:
                archive.extractall(destination, filter="data")
        except Exception as exc:
            return {"ok": False, "error": "runtime_artifact_extract_failed", "detail": f"{type(exc).__name__}:{exc}"}
        finally:
            local_archive.unlink(missing_ok=True)
        files = []
        for path in sorted(destination.rglob("*")):
            if path.is_file():
                files.append({"relative_path": str(path.relative_to(destination)).replace("\\", "/"), "bytes": path.stat().st_size, "sha256": _sha256(path)})
        manifest = {
            "schema": SCHEMA_VERSION,
            "collected_at": _utc_now(),
            "container": container,
            "vm_case": vm_case,
            "excluded_transient_scratch_files": excluded,
            "excluded_intermediate_time_directories": excluded_time_directories,
            "retention_policy": "initial_and_final_fields_plus_complete_postprocessing",
            "files": files,
        }
        _atomic_json(destination / "aero_result_manifest.json", manifest)
        return {
            "ok": True,
            "path": str(destination),
            "file_count": len(files),
            "excluded_transient_scratch_count": len(excluded),
            "excluded_intermediate_time_directory_count": len(excluded_time_directories),
            "manifest": str(destination / "aero_result_manifest.json"),
        }

    def _ingest_postprocessing(self, state: dict[str, Any]) -> dict[str, Any]:
        run_id = str(state.get("run_id") or "")
        root = self._run_dir(run_id) / "case_result" / "postProcessing"
        if not root.exists():
            return {"ok": False, "error": "postprocessing_missing"}
        directory_map = {
            "inletMassFlow": "mass_flow_inlet",
            "outletMassFlow": "mass_flow_outlet",
            "inletPressure": "pressure_inlet",
            "outletPressure": "pressure_outlet",
            "inletTotalPressure": "total_pressure_inlet",
            "outletTotalPressure": "total_pressure_outlet",
            "inletTemperature": "temperature_inlet",
            "outletTemperature": "temperature_outlet",
            "maxMach": "mach",
            "cylinderT": "wall_temperature",
        }
        series: dict[str, dict[float, float]] = {}
        sources: dict[str, str] = {}
        for directory, monitor_name in directory_map.items():
            files = sorted(
                path
                for path in root.rglob("*.dat")
                if directory in path.relative_to(root).parts
            )
            if not files:
                continue
            source = files[-1]
            values: dict[float, float] = {}
            for line in source.read_text(encoding="utf-8", errors="replace").splitlines():
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                columns = line.split()
                if len(columns) < 2:
                    continue
                try:
                    values[float(columns[0])] = float(columns[-1])
                except Exception:
                    continue
            if values:
                series[monitor_name] = values
                sources[monitor_name] = str(source)
        if series.get("temperature_outlet"):
            series["temperature"] = dict(series["temperature_outlet"])
            sources["temperature"] = sources["temperature_outlet"]
        velocity_series: dict[str, dict[float, float]] = {}
        for directory, monitor_name in {
            "inletVelocity": "velocity_inlet",
            "outletVelocity": "velocity_outlet",
        }.items():
            files = sorted(
                path
                for path in root.rglob("*.dat")
                if directory in path.relative_to(root).parts
            )
            if not files:
                continue
            source = files[-1]
            values: dict[float, float] = {}
            for line in source.read_text(encoding="utf-8", errors="replace").splitlines():
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                match = re.match(
                    r"\s*([0-9.eE+-]+)\s+\(\s*([0-9.eE+-]+)\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\s*\)",
                    line,
                )
                if not match:
                    continue
                sample_time, ux, uy, uz = (float(value) for value in match.groups())
                values[sample_time] = math.sqrt(ux * ux + uy * uy + uz * uz)
            if values:
                velocity_series[monitor_name] = values
                series[monitor_name] = values
                sources[monitor_name] = str(source)
        energy_inputs = {
            name: series.get(name) or {}
            for name in ("temperature_inlet", "temperature_outlet", "velocity_inlet", "velocity_outlet")
        }
        common_energy_times = sorted(set.intersection(*(set(values) for values in energy_inputs.values()))) if all(energy_inputs.values()) else []
        if common_energy_times:
            cp = float((state.get("metrics") or {}).get("specific_heat_j_kg_k") or 1005.0)
            energy_imbalance: dict[float, float] = {}
            for sample_time in common_energy_times:
                inlet_energy = cp * energy_inputs["temperature_inlet"][sample_time] + 0.5 * energy_inputs["velocity_inlet"][sample_time] ** 2
                outlet_energy = cp * energy_inputs["temperature_outlet"][sample_time] + 0.5 * energy_inputs["velocity_outlet"][sample_time] ** 2
                energy_imbalance[sample_time] = abs(inlet_energy - outlet_energy) / max(abs(inlet_energy), abs(outlet_energy), 1.0e-30)
            series["energy_imbalance"] = energy_imbalance
            sources["energy_imbalance"] = "derived:patch_average_stagnation_energy"
        force_root = root / "aeroForceCoeffs"
        force_files = sorted(
            [*force_root.rglob("forceCoeffs.dat"), *force_root.rglob("coefficient.dat")]
        ) if force_root.exists() else []
        if force_files:
            source = force_files[-1]
            coefficient_series = {
                "moment_coefficient": {},
                "drag_coefficient": {},
                "lift_coefficient": {},
            }
            for line in source.read_text(encoding="utf-8", errors="replace").splitlines():
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                columns = line.split()
                if len(columns) < 4:
                    continue
                try:
                    sample_time = float(columns[0])
                    coefficient_series["moment_coefficient"][sample_time] = float(columns[1])
                    coefficient_series["drag_coefficient"][sample_time] = float(columns[2])
                    coefficient_series["lift_coefficient"][sample_time] = float(columns[3])
                except Exception:
                    continue
            for monitor_name, values in coefficient_series.items():
                if values:
                    series[monitor_name] = values
                    sources[monitor_name] = str(source)
        heat_flux_series: dict[str, dict[float, float]] = {}
        for directory, monitor_name in {
            "fluidInterfaceHeatFlux": "heat_flux_fluid",
            "solidInterfaceHeatFlux": "heat_flux_solid",
        }.items():
            files = sorted(
                path
                for path in root.rglob("wallHeatFlux.dat")
                if directory in path.relative_to(root).parts
            )
            if not files:
                continue
            source = files[-1]
            values: dict[float, float] = {}
            for line in source.read_text(encoding="utf-8", errors="replace").splitlines():
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                columns = line.split()
                if len(columns) < 6:
                    continue
                try:
                    values[float(columns[0])] = float(columns[4])
                except Exception:
                    continue
            if values:
                heat_flux_series[monitor_name] = values
                series[monitor_name] = values
                sources[monitor_name] = str(source)
        fluid_flux = heat_flux_series.get("heat_flux_fluid") or {}
        solid_flux = heat_flux_series.get("heat_flux_solid") or {}
        common_flux_times = sorted(set(fluid_flux) & set(solid_flux))
        if common_flux_times:
            imbalance: dict[float, float] = {}
            for sample_time in common_flux_times:
                fluid_value = float(fluid_flux[sample_time])
                solid_value = float(solid_flux[sample_time])
                denominator = max(abs(fluid_value), abs(solid_value), 1.0e-30)
                imbalance[sample_time] = abs(fluid_value + solid_value) / denominator
            series["energy_imbalance"] = imbalance
            sources["energy_imbalance"] = "derived:fluidInterfaceHeatFlux+solidInterfaceHeatFlux"
        if not series:
            return {"ok": False, "error": "postprocessing_monitor_data_missing"}
        telemetry_path = self._run_dir(run_id) / "telemetry.jsonl"
        all_times = sorted({sample_time for values in series.values() for sample_time in values})
        ingested = 0
        for sample_time in all_times:
            for monitor_name in sorted(series):
                if sample_time not in series.get(monitor_name, {}):
                    continue
                event = {
                    "at": _utc_now(),
                    "kind": "monitor",
                    "stage": "postprocessing",
                    "name": monitor_name,
                    "value": series[monitor_name][sample_time],
                    "simulation_time": sample_time,
                    "source": sources[monitor_name],
                }
                self._append_jsonl(telemetry_path, event)
                _merge_telemetry(state["metrics"], event)
                ingested += 1
        return {"ok": True, "series": {name: len(values) for name, values in series.items()}, "events_ingested": ingested, "sources": sources}

    def branch_run(self, run_id: str, adjustments: dict[str, Any], *, start: bool = False) -> dict[str, Any]:
        state = self._load_state(run_id)
        if not state.get("run_id"):
            return state
        source_spec = _read_json(self._run_dir(run_id) / "spec.json")
        allowed = {
            "end_time",
            "delta_t",
            "max_courant",
            "max_delta_t",
            "write_interval",
            "timeout_sec",
            "solver",
        }
        unknown = sorted(set(adjustments) - allowed)
        if unknown:
            return {"ok": False, "error": "branch_adjustment_requires_manual_review", "unsupported": unknown, "allowed": sorted(allowed)}
        source_spec.setdefault("numerics", {}).update(copy.deepcopy(adjustments))
        source_spec.pop("spec_id", None)
        source_spec.pop("created_at", None)
        source_spec["name"] = f"{source_spec.get('name', 'CFD case')} branch from {run_id}"
        source_spec["parent_run_id"] = run_id
        created = self.create_spec(source_spec)
        if not created.get("ok") or not start:
            return {"ok": created.get("ok", False), "parent_run_id": run_id, "branch": created}
        launched = self.start_run(created["spec"]["spec_id"])
        return {"ok": launched.get("ok", False), "parent_run_id": run_id, "branch_spec": created["spec"], "run": launched}

    def plan_validation_study(
        self,
        spec_id: str,
        study_type: str,
        values: list[Any] | None = None,
    ) -> dict[str, Any]:
        loaded = self.get_spec(spec_id)
        if not loaded.get("ok"):
            return loaded
        source = loaded["spec"]
        template = str(source.get("template") or "")
        kind = str(study_type or "").strip().lower().replace("-", "_").replace(" ", "_")
        study_id = _slug(f"study_{kind}_{int(time.time())}_{uuid.uuid4().hex[:8]}", "study")
        monitor_by_template = {
            "compressible_nozzle": "pressure_ratio",
            "incompressible_internal": "total_pressure_loss",
            "external_aerodynamics": "drag_coefficient",
            "rotating_turbomachinery": "relative_total_pressure_change",
            "conjugate_heat_transfer": "wall_temperature",
        }
        plan: dict[str, Any] = {
            "ok": True,
            "schema": "aero_openfoam_validation_study_plan_v1",
            "study_id": study_id,
            "created_at": _utc_now(),
            "source_spec_id": spec_id,
            "template": template,
            "study_type": kind,
            "comparison_monitor": monitor_by_template.get(template, "mass_flow"),
            "variants": [],
            "executable": True,
            "status": "planned",
            "trust_boundary": "A study plan creates controlled numerical variants; completed runs and comparison evidence are still required.",
        }

        def create_variant(label: str, patch: dict[str, Any]) -> dict[str, Any]:
            variant = copy.deepcopy(source)
            for key in ("spec_id", "created_at", "updated_at", "spec_validation"):
                variant.pop(key, None)
            variant["name"] = f"{source.get('name', template)} [{label}]"
            variant["parent_spec_id"] = spec_id
            variant["validation_study_id"] = study_id
            variant.setdefault("validation", {}).pop("mesh_independence_evidence", None)

            def merge(target: dict[str, Any], incoming: dict[str, Any]) -> None:
                for key, value in incoming.items():
                    if isinstance(value, dict) and isinstance(target.get(key), dict):
                        merge(target[key], value)
                    else:
                        target[key] = copy.deepcopy(value)

            merge(variant, patch)
            created = self.create_spec(variant)
            return {
                "label": label,
                "ok": created.get("ok", False),
                "spec_id": (created.get("spec") or {}).get("spec_id"),
                "controls": patch,
                "validation": created.get("validation"),
            }

        if kind in {"mesh", "mesh_independence"}:
            requested = values if values is not None else [0, 1]
            passes = sorted({int(value) for value in requested})
            if len(passes) < 2 or any(value < 0 or value > 2 for value in passes):
                return {"ok": False, "error": "mesh_study_requires_two_or_more_refinement_passes_between_0_and_2"}
            plan["study_type"] = "mesh_independence"
            for value in passes:
                patch: dict[str, Any] = {"mesh": {"refinement_passes": value}}
                if template in {"compressible_nozzle", "incompressible_internal", "external_aerodynamics", "rotating_turbomachinery"} and value > 0:
                    base_end = float((source.get("numerics") or {}).get("end_time") or 1.0)
                    base_timeout = int((source.get("numerics") or {}).get("timeout_sec") or 120)
                    patch["numerics"] = {
                        "end_time": base_end * (2**value),
                        "timeout_sec": min(base_timeout * (2**value), 86400),
                    }
                plan["variants"].append(create_variant(f"refinement_passes={value}", patch))
        elif kind in {"timestep", "time_step", "time_step_sensitivity"}:
            if "transient" not in str((source.get("physics") or {}).get("flow_regime") or "") and template != "conjugate_heat_transfer":
                return {"ok": False, "error": "timestep_study_requires_transient_template", "template": template}
            base = float((source.get("numerics") or {}).get("delta_t") or 0.0)
            requested = values if values is not None else [base, base * 0.5]
            steps = sorted({float(value) for value in requested}, reverse=True)
            if len(steps) < 2 or any(value <= 0 for value in steps):
                return {"ok": False, "error": "timestep_study_requires_two_or_more_positive_values"}
            plan["study_type"] = "time_step_sensitivity"
            for value in steps:
                plan["variants"].append(
                    create_variant(
                        f"delta_t={value:.6g}",
                        {"numerics": {"delta_t": value, "max_delta_t": min(value, float((source.get('numerics') or {}).get('max_delta_t') or value))}},
                    )
                )
        elif kind in {"turbulence", "turbulence_model"}:
            plan.update(
                {
                    "executable": False,
                    "status": "blocked_pending_reviewed_model_seeds",
                    "variants": [],
                    "required_assets": [
                        "model-specific initial fields and wall boundary conditions",
                        "near-wall mesh/y-plus plan",
                        "matched discretization and convergence criteria",
                        "declared experimental or published validation reference",
                    ],
                    "reason": "Changing only a turbulence-model name would create an invalid or misleading case.",
                }
            )
        elif kind in {"validation", "validation_ladder"}:
            plan.update(
                {
                    "executable": False,
                    "status": "evidence_collection_plan",
                    "required_evidence": [
                        "analytical or correlation check",
                        "published or experimental reference with uncertainty",
                        "mesh-independence result",
                        "time-step sensitivity for transient cases",
                        "conservation and stable engineering monitors",
                        "cross-solver comparison where applicable",
                    ],
                }
            )
        else:
            return {"ok": False, "error": "unsupported_validation_study_type", "supported": ["mesh_independence", "time_step_sensitivity", "turbulence_model", "validation_ladder"]}
        _atomic_json(self.studies_dir / f"{study_id}.json", plan)
        return plan

    @_spec_synchronized
    def _attach_mesh_independence_evidence(self, spec_id: str, evidence: dict[str, Any]) -> dict[str, Any]:
        loaded = self.get_spec(spec_id)
        if not loaded.get("ok"):
            return loaded
        spec = copy.deepcopy(loaded["spec"])
        if evidence.get("study_invariant_sha256") != _study_invariant_sha256(spec):
            return {"ok": False, "error": "study_target_provenance_mismatch"}
        spec.setdefault("validation", {})["mesh_independence_evidence"] = copy.deepcopy(evidence)
        spec["updated_at"] = _utc_now()
        spec["engineering_readiness"] = build_readiness_contract(spec)
        validation = validate_spec(spec)
        spec["spec_validation"] = validation
        _atomic_json(self.specs_dir / f"{_slug(spec_id)}.json", spec)
        return {"ok": validation["ok"], "spec": spec, "validation": validation}

    def compare_runs(
        self,
        run_ids: list[str],
        *,
        monitor: str,
        additional_monitors: list[str] | None = None,
        tolerance: float = 0.02,
        attach_to_spec_id: str | None = None,
    ) -> dict[str, Any]:
        unique_ids = list(dict.fromkeys(_slug(row, "") for row in run_ids if _slug(row, "")))
        if len(unique_ids) < 2:
            return {"ok": False, "error": "at_least_two_runs_required"}
        monitor_names = list(
            dict.fromkeys(
                [str(monitor or "").strip()]
                + [str(row or "").strip() for row in (additional_monitors or [])]
            )
        )
        if not monitor_names or any(not re.fullmatch(r"[A-Za-z0-9_.-]+", name) for name in monitor_names):
            return {"ok": False, "error": "invalid_monitor_name"}
        tolerance = float(tolerance)
        if not 0.0 < tolerance <= 1.0:
            return {"ok": False, "error": "invalid_tolerance"}
        samples: list[dict[str, Any]] = []
        missing: list[dict[str, Any]] = []
        for run_id in unique_ids:
            state = self.get_run(run_id)
            run_spec = _read_json(self._run_dir(run_id) / "spec.json")
            monitors = (state.get("metrics") or {}).get("monitors") or {}
            monitor_series = {name: monitors.get(name) or [] for name in monitor_names}
            missing_monitor_names = [name for name, values in monitor_series.items() if not values]
            cells = ((state.get("metrics") or {}).get("mesh") or {}).get("cell_count")
            evaluation = state.get("gate_evaluation") if isinstance(state.get("gate_evaluation"), dict) else {}
            gate_rows = evaluation.get("gates") if isinstance(evaluation.get("gates"), list) else []
            comparison_gate_names = {
                "solver_reached_end",
                "no_fatal_error",
                "mesh_ok",
                "mass_conservation",
                "engineering_monitors_present",
                "monitor_stability",
                "energy_conservation",
            }
            failed_comparison_gates = [
                str(row.get("name"))
                for row in gate_rows
                if (
                    row.get("name") in comparison_gate_names
                    or str(row.get("name") or "").startswith("residual_")
                )
                and row.get("passed") is not True
            ]
            if not run_spec:
                failed_comparison_gates.append("run_spec_snapshot_missing")
            if state.get("status") != "completed" or cells is None or missing_monitor_names or failed_comparison_gates:
                missing.append(
                    {
                        "run_id": run_id,
                        "status": state.get("status"),
                        "cell_count": cells,
                        "monitor_samples": {name: len(values) for name, values in monitor_series.items()},
                        "missing_monitors": missing_monitor_names,
                        "failed_comparison_gates": failed_comparison_gates,
                    }
                )
                continue
            values = {name: float(series[-1]) for name, series in monitor_series.items()}
            samples.append(
                {
                    "run_id": run_id,
                    "cell_count": int(cells),
                    "value": values[monitor_names[0]],
                    "values": values,
                    "classification": (state.get("gate_evaluation") or {}).get("classification"),
                    "spec_id": run_spec.get("spec_id"),
                    "template": run_spec.get("template"),
                    "refinement_passes": int((run_spec.get("mesh") or {}).get("refinement_passes") or 0),
                    "study_invariant_sha256": _study_invariant_sha256(run_spec),
                    "input_spec_sha256": state.get("input_spec_sha256") or _json_sha256(run_spec),
                }
            )
        if missing or len(samples) < 2:
            return {"ok": False, "error": "comparison_evidence_missing", "missing": missing, "samples": samples}
        invariant_hashes = {row["study_invariant_sha256"] for row in samples}
        if len(invariant_hashes) != 1:
            return {
                "ok": False,
                "error": "incompatible_run_provenance",
                "required_invariant": "template_case_source_physics_boundaries_and_numerics_except_runtime_horizon",
                "samples": samples,
            }
        samples.sort(key=lambda row: row["cell_count"])
        if len({row["cell_count"] for row in samples}) < 2:
            return {"ok": False, "error": "distinct_mesh_cell_counts_required", "samples": samples}
        comparisons = []
        for coarse, fine in zip(samples, samples[1:]):
            for monitor_name in monitor_names:
                coarse_value = float(coarse["values"][monitor_name])
                fine_value = float(fine["values"][monitor_name])
                denominator = max(abs(fine_value), 1.0e-30)
                relative_change = abs(fine_value - coarse_value) / denominator
                comparisons.append(
                    {
                        "monitor": monitor_name,
                        "coarse_run_id": coarse["run_id"],
                        "fine_run_id": fine["run_id"],
                        "coarse_cells": coarse["cell_count"],
                        "fine_cells": fine["cell_count"],
                        "coarse_value": coarse_value,
                        "fine_value": fine_value,
                        "relative_change": relative_change,
                        "passed": relative_change <= tolerance,
                    }
                )
        passed = all(row["passed"] for row in comparisons)
        study_id = _slug(f"mesh_study_{int(time.time())}_{uuid.uuid4().hex[:8]}", "mesh_study")
        result = {
            "ok": True,
            "schema": "aero_openfoam_mesh_study_v1",
            "study_id": study_id,
            "created_at": _utc_now(),
            "monitor": monitor_names[0],
            "monitors": monitor_names,
            "tolerance": tolerance,
            "study_invariant_sha256": next(iter(invariant_hashes)),
            "samples": samples,
            "comparisons": comparisons,
            "passed": passed,
            "attached_to_spec_id": None,
        }
        _atomic_json(self.studies_dir / f"{study_id}.json", result)
        if attach_to_spec_id:
            target = self.get_spec(attach_to_spec_id)
            if not target.get("ok"):
                return {**result, "ok": False, "error": "study_created_target_spec_missing", "target": target}
            target_invariant = _study_invariant_sha256(target["spec"])
            study_invariant = next(iter(invariant_hashes))
            if target_invariant != study_invariant:
                return {
                    **result,
                    "ok": False,
                    "error": "study_target_provenance_mismatch",
                    "study_invariant_sha256": study_invariant,
                    "target_invariant_sha256": target_invariant,
                }
            evidence = {
                "passed": passed,
                "study_id": study_id,
                "monitor": monitor_names[0],
                "monitors": monitor_names,
                "tolerance": tolerance,
                "maximum_relative_change": max(row["relative_change"] for row in comparisons),
                # Retain the three provenance-bound grid samples in the spec-level
                # evidence.  The readiness contract must be able to distinguish a
                # real three-level study from a bare boolean copied onto a spec.
                "samples": copy.deepcopy(samples),
                "comparisons": copy.deepcopy(comparisons),
                "run_ids": unique_ids,
                "study_invariant_sha256": study_invariant,
                "input_spec_sha256": {row["run_id"]: row["input_spec_sha256"] for row in samples},
            }
            updated = self._attach_mesh_independence_evidence(attach_to_spec_id, evidence)
            if not updated.get("ok"):
                return {**result, "ok": False, "error": "study_created_spec_attach_failed", "attach_result": updated}
            result["attached_to_spec_id"] = attach_to_spec_id
            _atomic_json(self.studies_dir / f"{study_id}.json", result)
        return result

    def compare_fluent_result(
        self,
        run_id: str,
        fluent_result: dict[str, Any],
        *,
        tolerance: float = 0.05,
    ) -> dict[str, Any]:
        """Record an evidence-gated Fluent/OpenFOAM nozzle comparison."""
        if _is_blue_profile():
            return {"ok": False, "error": "fluent_disabled_in_aero_blue", "profile": "blue"}
        state = self.get_run(run_id)
        if not state.get("run_id"):
            return state
        tolerance = float(tolerance)
        if not 0.0 < tolerance <= 1.0:
            return {"ok": False, "error": "invalid_tolerance"}
        if not isinstance(fluent_result, dict):
            return {"ok": False, "error": "fluent_result_required"}
        source_spec = _read_json(self._run_dir(run_id) / "spec.json")
        if str(source_spec.get("template") or "") != "compressible_nozzle":
            return {
                "ok": False,
                "error": "fluent_nozzle_comparison_requires_compressible_nozzle_run",
                "template": source_spec.get("template"),
            }

        evidence = fluent_result.get("evidence") if isinstance(fluent_result.get("evidence"), dict) else {}
        required_evidence = {
            "mesh_check_passed": bool(evidence.get("mesh_check_passed")),
            "units_confirmed": bool(evidence.get("units_confirmed")),
            "converged": bool(evidence.get("converged")),
            "case_data_saved": bool(evidence.get("case_data_saved")),
            "monitor_histories_saved": bool(evidence.get("monitor_histories_saved")),
        }
        evidence_blockers = [name for name, passed in required_evidence.items() if not passed]

        evaluation = state.get("gate_evaluation") if isinstance(state.get("gate_evaluation"), dict) else {}
        gate_rows = evaluation.get("gates") if isinstance(evaluation.get("gates"), list) else []
        required_openfoam_gates = {
            "solver_reached_end",
            "no_fatal_error",
            "mesh_ok",
            "mass_conservation",
            "engineering_monitors_present",
            "monitor_stability",
            "energy_conservation",
        }
        residual_thresholds = (
            source_spec.get("validation", {}).get("residual_thresholds", {})
            if isinstance(source_spec.get("validation"), dict)
            else {}
        )
        required_openfoam_gates.update(
            f"residual_{field}" for field in residual_thresholds if str(field).strip()
        )
        gate_by_name = {str(row.get("name")): row.get("passed") is True for row in gate_rows}
        openfoam_gate_blockers = sorted(
            name for name in required_openfoam_gates if gate_by_name.get(name) is not True
        )
        if state.get("status") != "completed":
            openfoam_gate_blockers.insert(0, "run_status_completed")

        openfoam_monitors = ((state.get("metrics") or {}).get("monitors") or {})
        fluent_metrics = fluent_result.get("metrics") if isinstance(fluent_result.get("metrics"), dict) else {}
        metric_contract = {
            "outlet_mass_flow": ("mass_flow", True),
            "mass_imbalance": ("mass_imbalance", False),
            "pressure_ratio": ("pressure_ratio", False),
            "maximum_mach": ("mach", False),
            "outlet_temperature": ("temperature", False),
        }
        comparisons: list[dict[str, Any]] = []
        metric_blockers: list[str] = []
        for fluent_name, (openfoam_name, compare_absolute) in metric_contract.items():
            source_values = openfoam_monitors.get(openfoam_name) or []
            fluent_value = fluent_metrics.get(fluent_name)
            if not source_values:
                metric_blockers.append(f"openfoam_metric_missing:{openfoam_name}")
                continue
            try:
                openfoam_value = float(source_values[-1])
                fluent_number = float(fluent_value)
            except (TypeError, ValueError):
                metric_blockers.append(f"fluent_metric_missing_or_invalid:{fluent_name}")
                continue
            if compare_absolute:
                openfoam_value = abs(openfoam_value)
                fluent_number = abs(fluent_number)
            denominator = max(abs(openfoam_value), abs(fluent_number), 1.0e-30)
            relative_difference = abs(openfoam_value - fluent_number) / denominator
            comparisons.append(
                {
                    "metric": fluent_name,
                    "openfoam_monitor": openfoam_name,
                    "openfoam_value": openfoam_value,
                    "fluent_value": fluent_number,
                    "relative_difference": relative_difference,
                    "tolerance": tolerance,
                    "within_tolerance": relative_difference <= tolerance,
                }
            )

        tolerance_blockers = [
            f"outside_tolerance:{row['metric']}" for row in comparisons if not row["within_tolerance"]
        ]
        blockers = [
            *[f"fluent_evidence_missing:{name}" for name in evidence_blockers],
            *[f"openfoam_gate_failed:{name}" for name in openfoam_gate_blockers],
            *metric_blockers,
            *tolerance_blockers,
        ]
        study_id = _slug(f"fluent_compare_{int(time.time())}_{uuid.uuid4().hex[:8]}", "fluent_compare")
        comparison_passed = not blockers and len(comparisons) == len(metric_contract)
        result = {
            "ok": True,
            "schema": "aero_fluent_openfoam_nozzle_result_v1",
            "study_id": study_id,
            "created_at": _utc_now(),
            "openfoam_run_id": run_id,
            "openfoam_spec_id": state.get("spec_id"),
            "openfoam_classification": evaluation.get("classification"),
            "fluent_result_id": str(fluent_result.get("result_id") or "").strip(),
            "tolerance": tolerance,
            "evidence": required_evidence,
            "evidence_paths": evidence.get("paths") if isinstance(evidence.get("paths"), dict) else {},
            "comparisons": comparisons,
            "blockers": blockers,
            "comparison_passed": comparison_passed,
            "verification_ready": comparison_passed,
            "trust_boundary": "Cross-code agreement is verification evidence, not experimental validation or design certification.",
        }
        result["summary_markdown"] = (
            f"# Fluent/OpenFOAM nozzle comparison `{study_id}`\n\n"
            f"- OpenFOAM run: `{run_id}`\n"
            f"- Fluent result: `{result['fluent_result_id'] or 'unlabeled'}`\n"
            f"- Tolerance: `{tolerance:.2%}`\n"
            f"- Verification-ready: `{'yes' if comparison_passed else 'no'}`\n"
            f"- Blockers: `{', '.join(blockers) or 'none'}`\n\n"
            "Agreement between solvers does not replace analytical, published, or experimental validation."
        )
        _atomic_json(self.studies_dir / f"{study_id}.json", result)
        return result

    def get_study(self, study_id: str) -> dict[str, Any]:
        path = self.studies_dir / f"{_slug(study_id, '')}.json"
        if not path.exists():
            return {"ok": False, "error": "study_not_found", "study_id": study_id}
        return _read_json(path)

    def get_run(self, run_id: str) -> dict[str, Any]:
        state = self._load_state(run_id)
        return state if state.get("run_id") else {"ok": False, "error": "run_not_found", "run_id": run_id}

    def list_runs(self, limit: int = 100) -> dict[str, Any]:
        rows = [self._load_state(path.parent.name) for path in self.runs_dir.glob("*/state.json")]
        rows = [row for row in rows if row.get("run_id")]
        rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
        return {"ok": True, "runs": rows[: max(1, min(int(limit), 500))], "count": len(rows)}

    def telemetry(self, run_id: str, limit: int = 500) -> dict[str, Any]:
        path = self._run_dir(run_id) / "telemetry.jsonl"
        if not path.exists():
            state = self.get_run(run_id)
            return {"ok": bool(state.get("run_id")), "run_id": run_id, "telemetry": [], "status": state.get("status")}
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()[-max(1, min(int(limit), 5000)) :]
        rows = []
        for line in lines:
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        return {"ok": True, "run_id": run_id, "telemetry": rows, "count": len(rows)}

    def visualization_status(self, run_id: str) -> dict[str, Any]:
        state = self.get_run(run_id)
        if not state.get("run_id"):
            return {"ok": False, "error": "run_not_found", "run_id": run_id}
        visual_dir = self._run_dir(run_id) / "visualization"
        manifest = _read_json(visual_dir / "manifest.json", {})
        vtk_files = sorted((visual_dir / "vtk").glob("*.vtk")) if (visual_dir / "vtk").is_dir() else []
        vtk_path = vtk_files[-1] if vtk_files else None
        return {
            "ok": bool(vtk_path and vtk_path.is_file()),
            "run_id": run_id,
            "ready": bool(vtk_path and vtk_path.is_file()),
            "vtk": _artifact(vtk_path) if vtk_path else None,
            "vtk_url": f"/tools/cfd/openfoam/runs/{run_id}/visualization/vtk" if vtk_path else None,
            "fields": manifest.get("fields") or [],
            "generated_at": manifest.get("generated_at"),
            "source_case_manifest_sha256": manifest.get("source_case_manifest_sha256"),
        }

    def prepare_visualization(self, run_id: str) -> dict[str, Any]:
        state = self.get_run(run_id)
        if not state.get("run_id"):
            return {"ok": False, "error": "run_not_found", "run_id": run_id}
        if state.get("status") != "completed":
            return {"ok": False, "error": "run_not_completed", "status": state.get("status")}
        case_dir = self._run_dir(run_id) / "case_result"
        source_manifest = case_dir / "aero_result_manifest.json"
        if not case_dir.is_dir() or not source_manifest.is_file():
            return {"ok": False, "error": "solved_case_artifacts_unavailable"}
        runtime = state.get("runtime") if isinstance(state.get("runtime"), dict) else {}
        container = str(runtime.get("container") or "")
        source_cmd = str(runtime.get("source_cmd") or "")
        if not container or not source_cmd:
            return {"ok": False, "error": "openfoam_runtime_unavailable"}
        generated = _runtime_hooks()._docker_exec(
            container,
            (
                f"cd {str(case_dir)!r} && {source_cmd} >/tmp/aero_openfoam_source.log 2>&1; "
                "rm -rf VTK && foamToVTK -latestTime -ascii"
            ),
            timeout=300,
        )
        if not generated.get("ok"):
            return {
                "ok": False,
                "error": "foam_to_vtk_failed",
                "detail": str(generated.get("stderr") or generated.get("stdout") or "")[-4000:],
            }
        source_files = sorted((case_dir / "VTK").glob("*.vtk"))
        if not source_files:
            return {"ok": False, "error": "foam_to_vtk_produced_no_internal_mesh"}
        visual_dir = self._run_dir(run_id) / "visualization"
        target_dir = visual_dir / "vtk"
        if target_dir.exists():
            shutil.rmtree(target_dir)
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(case_dir / "VTK"), str(target_dir))
        vtk_files = sorted(target_dir.glob("*.vtk"))
        vtk_path = vtk_files[-1]
        descriptor = re.compile(r"^([A-Za-z][A-Za-z0-9_]*)\s+([1-9][0-9]*)\s+([1-9][0-9]*)\s+(?:float|double|int|long)\s*$")
        fields: list[dict[str, Any]] = []
        seen_fields: set[str] = set()
        for line in vtk_path.read_text(encoding="utf-8", errors="replace").splitlines():
            match = descriptor.match(line.strip())
            if match and match.group(1) != "cellID" and match.group(1) not in seen_fields:
                seen_fields.add(match.group(1))
                fields.append({"name": match.group(1), "components": int(match.group(2)), "tuples": int(match.group(3))})
        manifest = {
            "schema": "aero.openfoam.visualization.v1",
            "run_id": run_id,
            "generated_at": _utc_now(),
            "generator": "foamToVTK -latestTime -ascii",
            "source_case_manifest_sha256": _sha256(source_manifest),
            "vtk": _artifact(vtk_path),
            "fields": fields,
        }
        _atomic_json(visual_dir / "manifest.json", manifest)
        self._event(run_id, "visualization_generated", vtk_sha256=manifest["vtk"]["sha256"], fields=[row["name"] for row in fields])
        self._write_evidence_manifest(run_id)
        return self.visualization_status(run_id)

    def visualization_vtk_path(self, run_id: str) -> Path | None:
        visual_dir = self._run_dir(run_id) / "visualization" / "vtk"
        files = sorted(visual_dir.glob("*.vtk")) if visual_dir.is_dir() else []
        return files[-1] if files else None

    def reparse_run(self, run_id: str) -> dict[str, Any]:
        state = self.get_run(run_id)
        if not state.get("run_id"):
            return state
        run_dir = self._run_dir(run_id)
        log_path = run_dir / "solver.log"
        if not log_path.exists():
            return {"ok": False, "error": "solver_log_missing", "run_id": run_id}
        spec = _read_json(run_dir / "spec.json")
        telemetry_path = run_dir / "telemetry.jsonl"
        if telemetry_path.exists():
            archive = run_dir / f"telemetry.pre_reparse.{int(time.time())}.jsonl"
            shutil.copy2(telemetry_path, archive)
        telemetry_path.write_text("", encoding="utf-8")
        metrics = _metrics_for_spec(spec)
        current_stage = "blockMesh"
        for raw_line in log_path.read_text(encoding="utf-8", errors="replace").splitlines():
            stage_match = re.match(r"AERO_STAGE\s+(\S+)", raw_line)
            if stage_match:
                current_stage = stage_match.group(1)
            for telemetry in parse_openfoam_line(raw_line, current_stage):
                self._append_jsonl(telemetry_path, telemetry)
                _merge_telemetry(metrics, telemetry)
        state["metrics"] = metrics
        state["postprocessing_ingest"] = self._ingest_postprocessing(state)
        state["gate_evaluation"] = evaluate_gates(spec, metrics)
        if state.get("returncode") == 0 and state["gate_evaluation"]["smoke_passed"]:
            state["status"] = "completed"
            state["error"] = None
        elif state.get("status") not in {"cancelled", "interrupted"}:
            state["status"] = "failed"
            state["error"] = state.get("error") or f"solver_exit_{state.get('returncode')}"
        self._event(run_id, "reparsed", classification=state["gate_evaluation"]["classification"], telemetry_count=metrics["telemetry_count"])
        self._finalize_run(state, spec)
        return state

    def _teaching_summary(self, state: dict[str, Any], spec: dict[str, Any]) -> list[str]:
        evaluation = state.get("gate_evaluation") or {}
        lines = [
            f"The run finished as `{state.get('status')}` and is classified as `{evaluation.get('classification')}`.",
            "A solver reaching End proves execution completed; it does not by itself prove design validity.",
        ]
        if state.get("interventions"):
            lines.append(f"Aero made {len(state['interventions'])} bounded intervention(s); inspect the intervention ledger before comparing results.")
        blockers = evaluation.get("blocking_gates") or []
        if blockers:
            lines.append("Design use remains blocked by: " + ", ".join(str(row) for row in blockers) + ".")
        else:
            lines.append("All declared design gates passed for this specification.")
        lines.append("Next step: branch the run for mesh/time-step sensitivity rather than overwriting this evidence.")
        limitation = str((spec.get("validation") or {}).get("model_limitations") or "").strip()
        if limitation:
            lines.append("Declared model limitation: " + limitation)
        return lines

    def _finalize_run(self, state: dict[str, Any], spec: dict[str, Any]) -> None:
        run_dir = self._run_dir(str(state["run_id"]))
        state["gate_evaluation"] = evaluate_gates(spec, state.get("metrics") or _initial_metrics())
        report_path = run_dir / "report.md"
        evaluation = state["gate_evaluation"]
        report = [
            f"# OpenFOAM run {state['run_id']}",
            "",
            f"- Status: `{state.get('status')}`",
            f"- Classification: `{evaluation.get('classification')}`",
            f"- Solver: `{(spec.get('numerics') or {}).get('solver')}`",
            f"- Created: `{state.get('created_at')}`",
            f"- Started: `{state.get('started_at')}`",
            f"- Ended: `{state.get('ended_at')}`",
            "",
            "## Gate results",
            "",
            "| Gate | Required | Passed | Evidence |",
            "|---|---:|---:|---|",
        ]
        for gate in evaluation.get("gates") or []:
            evidence = json.dumps(gate.get("evidence"), sort_keys=True).replace("|", "\\|")
            report.append(f"| {gate.get('name')} | {gate.get('required')} | {gate.get('passed')} | {evidence} |")
        report.extend(["", "## Latest engineering monitors", ""])
        monitors = ((state.get("metrics") or {}).get("monitors") or {})
        if monitors:
            for name, values in sorted(monitors.items()):
                if isinstance(values, list) and values:
                    report.append(f"- `{name}`: `{values[-1]}` ({len(values)} retained samples)")
        else:
            report.append("- No engineering-monitor values were recovered.")
        report.extend(["", "## Interventions", ""])
        if state.get("interventions"):
            for row in state["interventions"]:
                report.append(f"- {row.get('at')}: {row.get('actor')} changed {row.get('entry')} to {row.get('value')} ({row.get('reason')}).")
        else:
            report.append("- No runtime interventions were made.")
        report.extend(["", "## Aero teaching summary", ""])
        report.extend(f"- {line}" for line in self._teaching_summary(state, spec))
        readiness = build_readiness_contract(spec, state.get("metrics") or {})
        report.extend([
            "",
            "## First-cut engineering readiness",
            "",
            f"- Assessment: `{readiness['assessment']}`",
            f"- Design ready: `{str(readiness['design_ready']).lower()}`",
            "",
            "| Readiness item | Status |",
            "|---|---|",
        ])
        report.extend(
            f"| {row.get('id')} | {row.get('status')} |"
            for row in readiness.get("items") or []
        )
        report.extend(["", "### Unresolved risks", ""])
        risks = readiness.get("unresolved_risks") or []
        report.extend(f"- {risk}" for risk in risks)
        if not risks:
            report.append("- None recorded by the deterministic readiness contract.")
        report.extend(["", "### Requirements and objectives", ""])
        requirements = readiness.get("requirements") or []
        report.extend(
            f"- `{row.get('name', 'objective')}`: {row.get('kind', 'unspecified')}"
            + (f"; limit `{row.get('maximum')}`" if row.get("maximum") is not None else "")
            + (f"; direction `{row.get('direction')}`" if row.get("direction") else "")
            for row in requirements if isinstance(row, dict)
        )
        if not requirements:
            report.append("- No quantitative requirement has been declared.")
        report.extend(["", "### Margins", ""])
        margins = readiness.get("margins") or {}
        report.append(f"- `{json.dumps(margins, sort_keys=True)}`" if margins else "- No signed engineering margin is established.")
        report.extend(["", "### Uncertainty budget", ""])
        uncertainty = readiness.get("uncertainty") or {}
        if uncertainty:
            report.extend(f"- `{key}`: {value}" for key, value in sorted(uncertainty.items()))
        else:
            report.append("- No uncertainty budget is established.")
        readiness_path = run_dir / "engineering-readiness.json"
        _atomic_json(readiness_path, readiness)
        report_path.write_text("\n".join(report) + "\n", encoding="utf-8")
        state["artifacts"] = {
            "spec": _artifact(run_dir / "spec.json"),
            "preflight": _artifact(run_dir / "preflight.json"),
            "solver_log": _artifact(run_dir / "solver.log"),
            "telemetry": _artifact(run_dir / "telemetry.jsonl"),
            "report": _artifact(report_path),
            "case_result_manifest": _artifact(run_dir / "case_result" / "aero_result_manifest.json"),
            "engineering_readiness": _artifact(readiness_path),
        }
        state["evidence_manifest"] = str(self._evidence_manifest_path(str(state["run_id"])))
        self._save_state(state)
        self._event(str(state["run_id"]), "finished", status=state.get("status"), classification=evaluation.get("classification"))
        if state.get("status") == "completed" and (state.get("artifact_collection") or {}).get("ok"):
            # A successful Blue run should flow directly into a viewable field
            # result.  Visualization is derived from the retained immutable
            # case and does not change the solver evidence or readiness gates.
            self.prepare_visualization(str(state["run_id"]))
        self._write_evidence_manifest(str(state["run_id"]))

    def report(self, run_id: str) -> dict[str, Any]:
        state = self.get_run(run_id)
        if not state.get("run_id"):
            return state
        report_path = self._run_dir(run_id) / "report.md"
        spec = _read_json(self._run_dir(run_id) / "spec.json")
        if not report_path.exists() and state.get("status") in TERMINAL_STATES:
            self._finalize_run(state, spec)
        return {
            "ok": report_path.exists(),
            "run_id": run_id,
            "status": state.get("status"),
            "gate_evaluation": state.get("gate_evaluation"),
            "teaching_summary": self._teaching_summary(state, spec),
            "report_path": str(report_path),
            "report_markdown": report_path.read_text(encoding="utf-8") if report_path.exists() else "",
            "evidence_manifest": self._ensure_evidence_manifest(run_id),
        }


_PIPELINE: OpenFOAMPipeline | None = None
_PIPELINE_LOCK = threading.Lock()


def get_pipeline() -> OpenFOAMPipeline:
    global _PIPELINE
    with _PIPELINE_LOCK:
        root = _default_root()
        if _PIPELINE is None or _PIPELINE.root != root:
            _PIPELINE = OpenFOAMPipeline(root)
        return _PIPELINE
