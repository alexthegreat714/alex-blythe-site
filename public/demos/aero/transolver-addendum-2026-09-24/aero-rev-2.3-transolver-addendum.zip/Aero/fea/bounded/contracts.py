"""Server-owned SI structural contracts; no executable text or paths."""
from __future__ import annotations
import hashlib
import json
import math
import re

MODELS = ('ANALYTICAL', 'BEAM', 'SHELL', '2D_PLANE_STRESS', '2D_PLANE_STRAIN', 'AXISYMMETRIC', '3D_SOLID')
TEMPLATES = ('BRACKET', 'TUBE', 'THERMAL_BAR')
MATERIAL = {'E': 70e9, 'nu': .3, 'rho': 2700., 'alpha': 23e-6, 'yield_pa': 200e6}

def strict(obj, allowed, required=()):
    if not isinstance(obj, dict) or set(obj) - set(allowed) or set(required) - set(obj):
        raise ValueError('Unrecognized or missing contract fields')
    return obj

def number(value, low, high):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError('Finite bounded numeric value required')
    return float(value)

def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def identifier(value):
    if not isinstance(value, str) or not re.fullmatch('[a-f0-9]{32}', value):
        raise ValueError('Invalid case ID')
    return value

def classify(goal):
    if not isinstance(goal, str) or not 1 <= len(goal) <= 2000:
        raise ValueError('Bounded engineering goal required')
    text = goal.lower()
    dimensional = any(s in text for s in ('tolerance stack', 'toleranc', 'clearance', 'seal compression', 'groove depth', 'interference fit'))
    structural = any(s in text for s in ('stress', 'bracket', 'yield', 'deflect', 'restraint', 'structural', 'survive'))
    thermal = any(s in text for s in ('thermal', 'temperature', 'heating', 'hot-gas', 'heat flux', 'cooling'))
    flow = any(s in text for s in ('cfd', 'flow', 'pressure-drop', 'pressure drop', 'hot-gas'))
    route = ('CFD_THERMAL_FEA' if structural and thermal and flow else 'THERMAL_FEA' if structural and thermal
             else 'FEA' if structural else 'CFD_THERMAL' if thermal and flow else 'THERMAL' if thermal
             else 'CFD' if flow else 'ANALYTICAL_ONLY' if 'analytical' in text else 'UNKNOWN')
    capabilities = ['TOLERANCE_ANALYSIS'] if dimensional else []
    if dimensional and any(s in text for s in ('change', 'update', 'modify', 'redesign')):
        capabilities += ['CAD_CHANGE_PROPOSAL', 'HUMAN_APPROVAL', 'CAD_AUTOMATION']
    if dimensional and route == 'UNKNOWN': route = 'TOLERANCE_ANALYSIS'
    return {'discipline': route, 'capabilities': capabilities,
            'private_capability_execution_authorized': False,
            'reason': 'Keyword intent triage only; confirm typed geometry and loads before fidelity selection.',
            'required_evidence': ['first_principles', 'numerical_evidence_if_solved', 'requirement_checks', 'validation_reference'],
            'coupling_authorized': False}

def select_fidelity(meta):
    flags = ('simple_closed_form', 'slender', 'thin', 'in_plane', 'invariant_long_axis', 'axisymmetric_geometry',
             'axisymmetric_loads', 'axisymmetric_supports', 'local_stress', 'through_thickness', 'bending',
             'contact', 'thermal_gradient_3d', 'asymmetric', 'input_uncertainty_dominates')
    strict(meta, (*flags, 'required_accuracy', 'qoi', 'override', 'override_reason'))
    for key in flags:
        if key in meta and type(meta[key]) is not bool:
            raise ValueError('Geometry/load facts must be booleans')
    accuracy = number(meta.get('required_accuracy', .05), .001, .5)
    qoi = meta.get('qoi', 'global')
    if qoi not in ('global', 'local'): raise ValueError('Invalid quantity of interest')
    unsupported = bool(meta.get('contact'))
    local = meta.get('local_stress') or qoi == 'local'
    need3d = meta.get('asymmetric') or meta.get('through_thickness') or meta.get('thermal_gradient_3d') or local
    if unsupported or need3d:
        recommended, reason = '3D_SOLID', 'Local/asymmetric/through-thickness effects invalidate dimensional reduction.'
    elif meta.get('simple_closed_form'):
        recommended, reason = 'ANALYTICAL', 'Closed form answers the global quantity under the stated assumptions.'
    elif all(meta.get(k) for k in ('axisymmetric_geometry', 'axisymmetric_loads', 'axisymmetric_supports')):
        recommended, reason = 'AXISYMMETRIC', 'Geometry, loads and supports are rotationally symmetric.'
    elif meta.get('slender'):
        recommended, reason = 'BEAM', 'Slender section and global response support beam theory.'
    elif meta.get('thin'):
        recommended, reason = ('2D_PLANE_STRESS', 'Thin in-plane response.') if meta.get('in_plane') else ('SHELL', 'Thin structure with bending.')
    elif meta.get('invariant_long_axis'):
        recommended, reason = '2D_PLANE_STRAIN', 'Invariant long direction supports plane-strain idealization.'
    else:
        recommended, reason = '3D_SOLID', 'Insufficient dimensional-reduction evidence; geometry review required.'
    chosen = meta.get('override', recommended)
    if chosen not in MODELS: raise ValueError('Unsupported model class')
    if chosen != recommended:
        why = meta.get('override_reason', '')
        if not isinstance(why, str) or not 20 <= len(why) <= 1000:
            raise ValueError('Fidelity override requires a grounded reviewable reason')
        if chosen != '3D_SOLID': raise ValueError('An override may escalate to solid, not bypass reduction assumptions')
    return {'recommended_model': chosen, 'baseline_recommendation': recommended,
            'alternatives': ['3D_SOLID'] if recommended != '3D_SOLID' else [], 'reason': reason,
            'override_reason': meta.get('override_reason'), 'facts': meta,
            'assumptions': ['Linear elastic, small displacement', 'Typed facts require engineering confirmation'],
            'required_accuracy': accuracy, 'cost_class': 'low' if chosen == 'ANALYTICAL' else 'bounded_solver',
            'escalation_conditions': ['Reference disagreement above tolerance', 'Local geometry/load effects', 'Unresolved thermal gradients'],
            'execution_status': 'UNSUPPORTED_CONTACT' if unsupported else 'TEMPLATE_VALIDATION_REQUIRED'}

def build_case(data):
    strict(data, ('template', 'model', 'analysis', 'dimensions', 'material', 'load', 'requirements', 'goal'), ('template',))
    template = data['template']
    if template not in TEMPLATES: raise ValueError('Unapproved geometry template')
    analysis = data.get('analysis', 'thermal_static' if template == 'THERMAL_BAR' else 'linear_static')
    if analysis not in ('linear_static', 'thermal_static'): raise ValueError('Unsupported analysis')
    if (analysis == 'thermal_static') != (template == 'THERMAL_BAR'): raise ValueError('Analysis/template mismatch')
    model = data.get('model', 'AXISYMMETRIC' if template == 'TUBE' else '3D_SOLID')
    if model not in (('ANALYTICAL', 'AXISYMMETRIC', '3D_SOLID') if template == 'TUBE' else ('ANALYTICAL', '3D_SOLID')):
        raise ValueError('Model not executable for approved template; never silently substituted')
    dim = data.get('dimensions', {})
    defaults = {'length': .1, 'width': .02, 'height': .01, 'hole_radius': .002} if template == 'BRACKET' else (
        {'length': .08, 'inner_radius': .01, 'thickness': .002, 'port_radius': 0.} if template == 'TUBE' else {'length': .1, 'width': .01, 'height': .01})
    strict(dim, defaults)
    dim = {k: number(dim.get(k, v), 0 if k in ('hole_radius', 'port_radius') else .001, .5) for k,v in defaults.items()}
    if template == 'BRACKET' and (dim['hole_radius'] > dim['width']*.2 or dim['length'] < dim['height']*5):
        raise ValueError('Bracket template requires slender stock and bounded hole')
    if template == 'TUBE':
        if dim['thickness'] > dim['inner_radius'] or dim['port_radius'] > dim['inner_radius']*.4:
            raise ValueError('Tube dimensions outside reviewed family')
        if dim['port_radius'] and model != '3D_SOLID': raise ValueError('Side port invalidates analytical/axisymmetric model')
    mat = data.get('material', {})
    strict(mat, MATERIAL)
    bounds = {'E': (1e9, 300e9), 'nu': (.01, .45), 'rho': (100, 20000), 'alpha': (0, 50e-6), 'yield_pa': (1e6, 2e9)}
    mat = {k: number(mat.get(k, v), *bounds[k]) for k,v in MATERIAL.items()}
    load = data.get('load', {})
    keys = {'force_n': 100.} if template == 'BRACKET' else {'pressure_pa': 1e6} if template == 'TUBE' else {'delta_t_k': 50., 'gradient_k': 0., 'restraint': 'free'}
    strict(load, keys)
    load = {k: load.get(k,v) for k,v in keys.items()}
    for k in load:
        if k != 'restraint': load[k] = number(load[k], -100 if k == 'gradient_k' else 0, 1e7 if k == 'pressure_pa' else 500 if k.endswith('_k') else 10000)
    if template == 'THERMAL_BAR' and load['restraint'] not in ('free', 'axial_fixed'): raise ValueError('Unsupported restraint')
    req = data.get('requirements', {})
    strict(req, ('max_stress_pa', 'max_displacement_m', 'factor_of_safety'))
    req = {'max_stress_pa': number(req.get('max_stress_pa', 100e6), 1e3, 2e9),
           'max_displacement_m': number(req.get('max_displacement_m', .002), 1e-9, .1),
           'factor_of_safety': number(req.get('factor_of_safety', 1.5), 1., 10.)}
    goal = data.get('goal', 'Preliminary structural screening')
    if not isinstance(goal, str) or not 1 <= len(goal) <= 2000: raise ValueError('Invalid goal')
    case = {'schema': 'aero.fea.case.v1', 'template': template, 'model': model, 'analysis': analysis,
            'dimensions': dim, 'material': mat, 'load': load, 'requirements': req, 'goal': goal,
            'units': 'm_N_Pa_K', 'geometry_source': 'PARAMETRIC_GENERATED', 'revision': 1,
            'mesh_levels': ['coarse', 'medium', 'fine'], 'mesh_tolerance': .05}
    case['fingerprint'] = fingerprint(case)
    return case

def analytical(case):
    d, m, load = case['dimensions'], case['material'], case['load']
    if case['template'] == 'BRACKET':
        inertia = d['width']*d['height']**3/12
        stress = load['force_n']*d['length']*d['height']/2/inertia
        displacement = load['force_n']*d['length']**3/(3*m['E']*inertia)
        note = 'Euler-Bernoulli gross section; hole and fixed-face local effects excluded.'
    elif case['template'] == 'TUBE':
        a, b, p = d['inner_radius'], d['inner_radius']+d['thickness'], load['pressure_pa']
        hoop = p*(a*a+b*b)/(b*b-a*a)
        stress = math.sqrt(hoop*hoop+p*p+hoop*p)
        displacement = a/m['E']*(hoop+m['nu']*p)
        note = 'Lame open-ended tube: sigma_z=0; bore von Mises and radial expansion. No port or end-cap load.'
    else:
        dt = load['delta_t_k'] + load['gradient_k']/2
        stress = m['E']*m['alpha']*abs(dt) if load['restraint'] == 'axial_fixed' else 0.
        displacement = m['alpha']*dt*d['length'] if load['restraint'] == 'free' else m['alpha']*abs(load['gradient_k'])*d['length']/8
        note = 'Uniaxial thermal strain, axial linear temperature profile; not triaxial constraint.'
    return {'provenance': 'ANALYTICAL', 'stress_pa': stress, 'displacement_m': displacement, 'assumptions': note}

def validate_coupling(package, geometry_hash):
    strict(package, ('geometry_hash', 'load_case_id', 'units', 'coordinate_frame', 'source_hash', 'field', 'samples', 'mapping'),
           ('geometry_hash', 'load_case_id', 'units', 'coordinate_frame', 'source_hash', 'field', 'samples', 'mapping'))
    for key in ('geometry_hash', 'source_hash'):
        if not isinstance(package[key], str) or not re.fullmatch('[0-9a-f]{64}', package[key]): raise ValueError('Invalid provenance hash')
    if package['geometry_hash'] != geometry_hash: raise ValueError('Geometry mismatch')
    identifier(package['load_case_id'])
    if package['coordinate_frame'] != 'CAD_GLOBAL_RIGHT_HANDED_M': raise ValueError('Coordinate frame mismatch')
    units = {'pressure': 'Pa', 'temperature': 'K', 'heat_flux': 'W/m2'}
    if package['field'] not in units or package['units'] != units[package['field']]: raise ValueError('Field/units mismatch')
    samples = package['samples']
    if not isinstance(samples, list) or not 1 <= len(samples) <= 10000: raise ValueError('Bounded field samples required')
    for row in samples:
        if not isinstance(row, list) or len(row) != 4: raise ValueError('Expected x,y,z,value')
        for x in row: number(x, -1e12, 1e12)
    mapping = strict(package['mapping'], ('coverage', 'method', 'validated'), ('coverage', 'method', 'validated'))
    if mapping != {'coverage': 1., 'method': 'identity_nodes', 'validated': True}: raise ValueError('Complete independently validated identity mapping required')
    return {'schema_valid': True, 'execution_enabled': False, 'disposition': 'MAPPING_REVIEW_REQUIRED',
            'reason': 'Schema is groundwork only. CFD field transfer is not executable.'}
