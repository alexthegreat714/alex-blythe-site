"""Private controller: fixed content-addressed image, disposable bounded worker."""
from __future__ import annotations
import json
import hashlib
from pathlib import Path
import re
import subprocess
import threading
import os
import time
import uuid
from .contracts import build_case, identifier, fingerprint, analytical
from .evidence import evaluate

class WorkerFailure(RuntimeError): pass

FINALIZED=('COMPLETE','COMPLETE_WITH_OPEN_GATES')

class WorkerLease:
    """Cross-process exclusion. A crashed owner's lease requires operator review."""
    def __init__(self,root):
        self.path=root/'.worker-lease'; self.mutex=threading.Lock()
    def acquire(self,blocking=False):
        if not self.mutex.acquire(blocking): return False
        try:
            self.path.mkdir()
        except FileExistsError:
            self.mutex.release(); return False
        try:
            write(self.path/'owner.json',{'pid':os.getpid(),'created_at':time.time(),'policy':'no_automatic_stale_lease_bypass'})
        except BaseException:
            self.path.rmdir(); self.mutex.release(); raise
        return True
    def release(self):
        try:
            (self.path/'owner.json').unlink(); self.path.rmdir()
        finally: self.mutex.release()

def completion_state(evidence):
    return 'COMPLETE' if all(evidence.get(k)=='PASS' for k in
                            ('numerical_acceptability','requirement_satisfaction','design_readiness')) else 'COMPLETE_WITH_OPEN_GATES'

def worker_argv(image, job_id, request_dir, out_dir):
    if not re.fullmatch('sha256:[a-f0-9]{64}',image): raise ValueError('Content-addressed reviewed image required')
    identifier(job_id)
    return ['docker','run','--rm','--name','aero-fea-'+job_id,'--network','none','--read-only','--cap-drop','ALL',
            '--security-opt','no-new-privileges','--user','10001:10001','--cpus','2','--memory','2g','--memory-swap','2g',
            '--pids-limit','64','--ulimit','nofile=256:256','--ulimit','fsize=67108864:67108864',
            '--tmpfs','/tmp:rw,noexec,nosuid,size=768m,mode=1777',
            '--mount',f'type=bind,source={request_dir},target=/input,readonly',
            '--mount',f'type=bind,source={out_dir},target=/output',image]

def execute_process(argv, timeout=360):
    try:
        proc=subprocess.run(argv,capture_output=True,text=True,timeout=timeout,check=False)
    except subprocess.TimeoutExpired:
        name=argv[argv.index('--name')+1]
        subprocess.run(['docker','rm','-f',name],capture_output=True,timeout=20)
        raise WorkerFailure('TIMED_OUT')
    if proc.returncode: raise WorkerFailure('SOLVER_FAILED')

def write(path, data):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,indent=2,allow_nan=False))
    tmp.replace(path)

class Controller:
    def __init__(self, root, image=None, runner=None):
        self.root=Path(root).resolve(); self.root.mkdir(parents=True,exist_ok=True)
        self.image=image
        self.runner=runner or execute_process
        self.lock=WorkerLease(self.root)

    def path(self, case_id):
        p=(self.root/identifier(case_id)).resolve()
        if p.parent!=self.root or p.is_symlink(): raise ValueError('Path containment failure')
        return p

    def build(self, data):
        case=build_case(data); cid=uuid.uuid4().hex
        folder=self.path(cid); folder.mkdir()
        write(folder/'case.json',case); write(folder/'status.json',{'state':'PROPOSED','case_id':cid})
        return {'case_id':cid,'case':case,'analytical':analytical(case), 'approval_required':case['model']!='ANALYTICAL'}

    def case(self,cid):
        case=json.loads((self.path(cid)/'case.json').read_text())
        if case.get('fingerprint')!=fingerprint({k:v for k,v in case.items() if k!='fingerprint'}):
            raise WorkerFailure('CASE_HASH_FAILED')
        return case
    def status(self,cid): return json.loads((self.path(cid)/'status.json').read_text())

    def verified_manifest(self,cid,action,level):
        out=self.path(cid)/(action+'-'+level)
        if out.is_symlink(): raise WorkerFailure('ARTIFACT_NAME_REJECTED')
        manifest=json.loads((out/'manifest.json').read_text())
        if (manifest.get('case_fingerprint')!=self.case(cid)['fingerprint'] or manifest.get('action')!=action
                or manifest.get('level')!=level or manifest.get('outcome','SUCCEEDED')!='SUCCEEDED'):
            raise WorkerFailure('ARTIFACT_PROVENANCE_FAILED')
        required={'geometry.json','geometry.step','geometry.stl'}
        if action in ('mesh','solve'): required.update(('mesh.json','mesh.msh','preflight.json','job.inp'))
        if action=='solve': required.update(('result.json','job.dat','job.frd','solver.log','surface.json','versions.json'))
        artifacts=manifest.get('artifacts',{})
        if not isinstance(artifacts,dict) or not required.issubset(artifacts):
            raise WorkerFailure('ARTIFACT_MANIFEST_INCOMPLETE')
        for name,digest in artifacts.items():
            if not isinstance(name,str) or not re.fullmatch('[a-z0-9_.]+',name) or '..' in name:
                raise WorkerFailure('ARTIFACT_NAME_REJECTED')
            file=out/name
            if not isinstance(digest,str) or not re.fullmatch('[a-f0-9]{64}',digest) or not file.is_file() or file.is_symlink() or hashlib.sha256(file.read_bytes()).hexdigest()!=digest:
                raise WorkerFailure('ARTIFACT_HASH_FAILED')
        return manifest

    def perform(self,cid,action,level='coarse'):
        if action not in ('geometry','mesh','solve') or level not in ('coarse','medium','fine'): raise ValueError('Invalid action')
        if not self.image: raise WorkerFailure('WORKER_UNAVAILABLE')
        base=self.path(cid); case=self.case(cid)
        runid=uuid.uuid4().hex; req=base/(runid+'-input'); out=base/(action+'-'+level)
        # A retry is a new case. Never mix old manifests with a new/failed solve.
        try: out.mkdir(exist_ok=False)
        except FileExistsError: raise ValueError('Existing attempt is immutable; create a new case')
        req.mkdir()
        write(req/'request.json',{'case':case,'action':action,'level':level})
        try:
            self.runner(worker_argv(self.image,runid,str(req),str(out)))
            self.verified_manifest(cid,action,level)
        finally:
            (req/'request.json').unlink(missing_ok=True); req.rmdir()
        return json.loads((out/('geometry.json' if action=='geometry' else 'preflight.json' if action=='mesh' else 'result.json')).read_text())

    def prepare(self,cid,action,level='coarse'):
        if not self.lock.acquire(False): raise WorkerFailure('WORKER_BUSY')
        try:
            if self.status(cid)['state']!='PROPOSED': raise ValueError('Case frozen; create a new candidate')
            return self.perform(cid,action,level)
        finally: self.lock.release()

    def preflight(self,cid):
        case=self.case(cid)
        if case['model']=='ANALYTICAL': return {'status':'PASS','solver_required':False}
        path=self.path(cid)/'mesh-coarse'/'preflight.json'
        if not path.exists(): return {'status':'NOT_ESTABLISHED','reasons':['Generate and validate a mesh first']}
        self.verified_manifest(cid,'mesh','coarse')
        record=json.loads(path.read_text())
        if record['case_fingerprint']!=case['fingerprint']: return {'status':'FAIL','reasons':['Stale mesh']}
        return record

    def run(self,cid,approval=None,background=True):
        case=self.case(cid)
        if self.status(cid)['state']!='PROPOSED': raise ValueError('Case already submitted; preserve it and create a new candidate')
        if case['model']=='ANALYTICAL':
            result={'schema':'aero.engineering.result.v1','discipline':'ANALYTICAL_ONLY','analytical':analytical(case),'design_readiness':'NOT_ESTABLISHED'}
            write(self.path(cid)/'result.json',result); write(self.path(cid)/'status.json',{'state':'COMPLETE_WITH_OPEN_GATES','case_id':cid})
            return {'job_id':cid,'state':'COMPLETE_WITH_OPEN_GATES'}
        if approval!=case['fingerprint']: raise ValueError('Human approval of exact case fingerprint required')
        if self.preflight(cid)['status']!='PASS': raise ValueError('Preflight not passed')
        if not self.lock.acquire(False): raise WorkerFailure('WORKER_BUSY')
        if self.status(cid)['state']!='PROPOSED':
            self.lock.release(); raise ValueError('Case already submitted; create a new immutable candidate')
        write(self.path(cid)/'status.json',{'state':'QUEUED','case_id':cid})
        def task():
            try:
                levels=[]
                for level in case['mesh_levels']:
                    write(self.path(cid)/'status.json',{'state':'RUNNING','case_id':cid,'level':level,'complete':len(levels),'total':3})
                    levels.append(self.perform(cid,'solve',level))
                result={'schema':'aero.engineering.result.v1','discipline':'FEA','case_fingerprint':case['fingerprint'],
                        'analytical':analytical(case),'levels':levels,'evidence':evaluate(case,levels),
                        'surface_artifact':'surface.json','source':'CALCULIX'}
                write(self.path(cid)/'result.json',result)
                write(self.path(cid)/'status.json',{'state':completion_state(result['evidence']),'case_id':cid,'complete':3,'total':3})
            except Exception as exc:
                code=str(exc) if isinstance(exc,WorkerFailure) else 'EVIDENCE_OR_WORKER_FAILURE'
                write(self.path(cid)/'status.json',{'state':'TIMED_OUT' if code=='TIMED_OUT' else 'FAILED','case_id':cid,'error':code})
            finally: self.lock.release()
        if background: threading.Thread(target=task,daemon=True).start()
        else: task()
        return {'job_id':cid,'state':self.status(cid)['state']}

    def results(self,cid):
        if self.status(cid)['state'] not in FINALIZED: return {'status':'NOT_ESTABLISHED'}
        case=self.case(cid)
        if case['model']=='ANALYTICAL':
            return {'schema':'aero.engineering.result.v1','discipline':'ANALYTICAL_ONLY',
                    'analytical':analytical(case),'design_readiness':'NOT_ESTABLISHED'}
        levels=[]
        for level in case['mesh_levels']:
            self.verified_manifest(cid,'solve',level)
            levels.append(json.loads((self.path(cid)/('solve-'+level)/'result.json').read_text()))
        # Reconstruct verdicts from verified outputs, not a mutable cached summary.
        return {'schema':'aero.engineering.result.v1','discipline':'FEA','case_fingerprint':case['fingerprint'],
                'analytical':analytical(case),'levels':levels,'evidence':evaluate(case,levels),
                'surface_artifact':'surface.json','source':'CALCULIX'}

    def surface(self,cid):
        if self.status(cid)['state'] not in FINALIZED: raise ValueError('Result not finalized')
        self.verified_manifest(cid,'solve','fine')
        return json.loads((self.path(cid)/'solve-fine'/'surface.json').read_text())
