"""Numerical quality and requirement satisfaction are different decisions."""
import math

def gate(value, criterion, label):
    if value is None or type(value) not in (float,int) or not math.isfinite(value):
        return {'status':'NOT_EVALUATED','quantity':label,'value':None}
    return {'status':'PASS' if criterion(value) else 'FAIL','quantity':label,'value':value}

def aggregate(rows):
    statuses=[r['status'] for r in rows.values()]
    return 'FAIL' if 'FAIL' in statuses else 'NOT_ESTABLISHED' if not statuses or any(s!='PASS' for s in statuses) else 'PASS'

def evaluate(case, levels):
    gates={}; fine=levels[-1] if levels else {}; meshes=[r.get('mesh',{}) for r in levels]
    gates['RUN_COMPLETED']={'status':'PASS' if len(levels)==3 and all(r.get('run_completed') is True for r in levels) else 'NOT_ESTABLISHED'}
    gates['MESH_QUALITY']={'status':'PASS' if len(meshes)==3 and all(m.get('min_scaled_jacobian',0)>.02 and m.get('min_determinant',0)>0 for m in meshes) else 'NOT_ESTABLISHED'}
    # A direct linear solve is not an iterative nonlinear residual history.
    gates['SOLVER_CONVERGENCE']={'status':gates['RUN_COMPLETED']['status'],'method':'linear_direct_factorization_and_complete_results'}
    balances=[gate(row.get('reaction_relative_error'),lambda x:0<=x<=.01,'equilibrium residual; tolerance 1%') for row in levels]
    gates['REACTION_BALANCE']={'status':aggregate({str(i):g for i,g in enumerate(balances)}) if len(balances)==3 else 'NOT_ESTABLISHED',
                              'levels':balances,'methods':[row.get('equilibrium') for row in levels]}
    gates['STRAIN_ENERGY_SANITY']=gate(fine.get('strain_energy_density_min'),lambda x:x>=-1e-6,'minimum integration-point energy density J/m3')
    convergence={}
    for key in ('max_displacement_m','path_stress_pa'):
        vals=[r.get(key) for r in levels]
        if len(vals)!=3 or any(v is None or not math.isfinite(v) for v in vals):
            convergence[key]={'status':'NOT_EVALUATED'}; continue
        floor=1e-10 if key.endswith('_m') else 1.
        change=abs(vals[-1]-vals[-2])/max(abs(vals[-1]),floor)
        ordered=len(meshes)==3 and all(meshes[i].get('elements',0)<meshes[i+1].get('elements',0) for i in range(2))
        convergence[key]={'status':'PASS' if ordered and change<=case['mesh_tolerance'] else 'FAIL','values':vals,'relative_change':change,'tolerance':case['mesh_tolerance']}
    gates['DISPLACEMENT_STABILITY']=convergence['max_displacement_m']
    gates['MESH_INDEPENDENCE']=convergence['path_stress_pa']
    peak=[r.get('max_stress_pa') for r in levels]
    # Never diagnose roundoff-sized free-expansion stresses as a singularity.
    singular=bool(len(peak)==3 and all(v is not None for v in peak) and peak[2]>max(1000.,case['material']['E']*1e-8)
                  and peak[2]>peak[1]*1.05 and peak[1]>peak[0]*1.05)
    stress=fine.get('max_stress_pa'); displacement=fine.get('max_displacement_m'); req=case['requirements']
    requirements={'MAX_STRESS':gate(stress,lambda x:x<=req['max_stress_pa'],'peak stress conservative screening'),
                  'MAX_DISPLACEMENT':gate(displacement,lambda x:x<=req['max_displacement_m'],'maximum displacement'),
                  'FACTOR_OF_SAFETY':gate(stress,lambda x:x*req['factor_of_safety']<=case['material']['yield_pa'],'yield-based safety factor')}
    if singular:
        requirements['MAX_STRESS']['status']='NOT_ESTABLISHED'
        requirements['FACTOR_OF_SAFETY']['status']='NOT_ESTABLISHED'
    num=aggregate(gates); raw=aggregate(requirements)
    # Preserve literal threshold comparisons, but do not promote untrusted
    # numerical outputs into an established engineering requirement verdict.
    if num!='PASS':
        for row in requirements.values():
            row['computed_status']=row['status']
            row['status']='NOT_ESTABLISHED'
            row['reason']='Numerical acceptability has not passed'
    eng=aggregate(requirements)
    return {'schema':'aero.fea.evidence.v1','numerical_gates':gates,'numerical_acceptability':num,
            'engineering_requirements':requirements,'requirement_satisfaction':eng,'computed_requirement_comparison':raw,'mesh_convergence':convergence,
            'local_stress_disposition':'LOCAL_SINGULARITY_SUSPECTED' if singular else 'LOCAL_STRESS_REVIEW_REQUIRED',
            'design_disposition':'NUMERICAL_REVIEW_REQUIRED' if num!='PASS' else 'REJECT_OR_REDESIGN' if eng=='FAIL' else 'PRELIMINARY_ONLY',
            'design_readiness':'NOT_ESTABLISHED','validation_reference':'NOT_ESTABLISHED',
            'limitations':['No release/design certification','Peak fixed-support/hole stress needs engineering interpretation',
                           'Axisymmetric equilibrium uses a midspan hoop section, not Cartesian radial RF',
                           'Global pressure force/moment balance does not prove pressure boundary completeness']}
