## Aero Product Rev 2.0 — local Aero / Aero Blue boundary

Date: 2026-09-14 UTC

Scope:
- Restored **Aero** as the user-facing name for the private local agent on
  profile `lab` / port 5213.
- Restored **Aero Blue** as the separate website product on profile `blue` /
  port 5313, including its authenticated website route and public Demo profile.
- Made the boundary explicit: only private Aero can use the local RAG corpus;
  Aero Blue is corpus-free and supports a caller-supplied small-model plug-in.
- Added the lazy, authenticated local retrieval adapter and safe surface
  metadata; no private index, path, credential, or source text is copied into
  the Blue image or website response.

Compatibility:
- Profile IDs (`lab`, `blue`, `public`), routes, storage paths, and evidence
  schemas remain unchanged. Existing `Aero Lab` and `/aero-blue` labels are
  compatibility/history identifiers, not additional products.
- See `docs/AERO_LOCAL_AGENT_BOUNDARY.md` and
  `docs/AERO_DEPLOYMENT_PROFILES.md` for the complete contract.

## Aero Product Rev 1.0

Date: 2026-09-11 UTC

Scope:
- Promoted the streamlined Linux/OpenFOAM profile to the user-facing **Aero** product.
- Retired **Aero Blue** as a visible name while retaining `blue`, `/aero-blue/`, storage, schema, and evidence identifiers as compatibility contracts.
- Named the recorded public walkthrough **Aero Demo**.
- Kept **Aero Lab** as the private superset with Windows/WVM, Fluent, GB10, and personal-service hooks.
- Added direct Aero to Aero Lab navigation so the private environment can use the same Rev 1.0 core workflow while retaining its additional tools.

Compatibility promise:
- Rev 1.x changes may add capabilities but will not silently rename or migrate existing profile IDs, routes, conversations, run artifacts, or evidence schemas.
- Breaking storage, route, or schema changes require a new major revision and an explicit migration receipt.

rev_0001

Date: 2025-11-02 UTC

Scope:
- Added Sky watchdog (health checks + daily summary)
- Added Garmin sleep downloader with persistent Chrome profile
- Added interactive wizard and click-to-capture selectors
- Added daily info agent and browser-use agent with endpoint probing
- Wrote README under Sky/agents and revisions summary under Sky/revisions/rev_0001

rev_0002

Date: 2025-11-02 UTC

Scope:
- Added Garmin daily scheduling via Windows Task Scheduler at 06:55 local time (Task: SkyGarminDownload0655)
- Watchdog now checks Garmin CSV presence for yesterday in downloads folder and reports status
- Snapshotted updated watchdog config and selectors under rev_0002
