"""Build and compare the NASA-hosted Driver-Seegmiller experimental case."""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports" / "driver_seegmiller_1985_20261122"
SOURCES = REPORT / "sources"
CASES = ROOT / "examples" / "openfoam" / "driver_seegmiller_1985_20261122"
H = 0.0127
UREF = 44.2
NU = UREF * H / 36000
THICKNESS = H * 0.1


def header(class_name: str, object_name: str) -> str:
    return (
        "FoamFile\n{\n    version 2.0;\n    format ascii;\n"
        f"    class {class_name};\n    object {object_name};\n}}\n"
    )


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def geometric_edges(length: float, count: int, ratio: float) -> np.ndarray:
    widths = np.geomspace(1, ratio, count)
    return np.r_[0, np.cumsum(widths / widths.sum() * length)]


def refined_edges(edges: np.ndarray, factor: int) -> np.ndarray:
    return np.r_[np.concatenate([np.linspace(a, b, factor, endpoint=False)
                                for a, b in zip(edges[:-1], edges[1:])]), edges[-1]]


def imported_mesh(level: int, destination: Path) -> dict:
    # Keep the published geometry. Use an orthogonal nested mesh after the
    # downloaded curvilinear family failed the standard mesh preflight.
    source = SOURCES / "backstep_bcs.jpg"
    factor = 2 ** (4 - level)
    upstream = np.r_[[-130, -120], -110 + geometric_edges(106, 40, 1/20), np.linspace(-4, 0, 17)[1:]]
    downstream = np.r_[np.linspace(0, 8, 49), 8 + geometric_edges(42, 32, 16)[1:]]
    half = geometric_edges(4, 20, 25)
    upper = 1 + np.r_[half, 8 - half[-2::-1]]
    lower = geometric_edges(1, 16, 30)
    upstream, downstream, upper, lower = [refined_edges(e, factor) for e in (upstream, downstream, upper, lower)]
    grids = [np.meshgrid(upstream, upper), np.meshgrid(downstream, upper),
             np.meshgrid(downstream, lower)]
    shapes = np.array([[x.shape[1], x.shape[0]] for x, y in grids])
    points = []
    point_ids = {}
    cells = []
    for x, y in grids:
        ny, nx = x.shape
        ids = np.zeros((ny, nx), dtype=int)
        for j in range(ny):
            for i in range(nx):
                key = (round(float(x[j, i]), 10), round(float(y[j, i]), 10))
                if key not in point_ids:
                    point_ids[key] = len(points)
                    points.append((float(x[j, i]), float(y[j, i])))
                ids[j, i] = point_ids[key]
        for j in range(ny - 1):
            for i in range(nx - 1):
                cells.append([int(ids[j, i]), int(ids[j, i + 1]),
                              int(ids[j + 1, i + 1]), int(ids[j + 1, i])])
    count = len(points)
    faces = {}
    for cell_id, corners in enumerate(cells):
        cell_faces = [list(reversed(corners)), [v + count for v in corners]]
        for a, b in zip(corners, corners[1:] + corners[:1]):
            cell_faces.append([a, b, b + count, a + count])
        for face in cell_faces:
            key = tuple(sorted(face))
            if key in faces:
                assert len(faces[key]) == 2, "Non-manifold imported mesh"
                faces[key].append(cell_id)
            else:
                faces[key] = [face, cell_id]
    internal = []
    boundary = defaultdict(list)
    for entry in faces.values():
        if len(entry) == 3:
            internal.append(entry)
            continue
        face, owner = entry
        if all(v < count for v in face) or all(v >= count for v in face):
            patch = "frontAndBack"
        else:
            coords = np.array([points[v % count] for v in face])
            x, y = coords.mean(axis=0)
            if abs(x + 130) < 1e-7:
                patch = "inlet"
            elif abs(x - 50) < 1e-7:
                patch = "outlet"
            elif x < -110:
                patch = "upstreamSlip"
            elif abs(y - 9) < 1e-7:
                patch = "upperWall"
            elif abs(x) < 1e-7 and 0 < y < 1:
                patch = "stepWall"
            elif abs(y) < 1e-7 or (x < 0 and abs(y - 1) < 1e-7):
                patch = "lowerWall"
            else:
                raise ValueError(f"Unclassified boundary face at {x}, {y}")
        boundary[patch].append([face, owner])
    internal.sort(key=lambda entry: (entry[1], entry[2]))
    ordered = list(internal)
    patch_lines = []
    for patch in ("inlet", "outlet", "lowerWall", "upperWall", "stepWall", "upstreamSlip", "frontAndBack"):
        kind = "empty" if patch == "frontAndBack" else "symmetry" if patch == "upstreamSlip" else "wall" if "Wall" in patch else "patch"
        patch_lines.append(f"{patch}\n{{ type {kind}; nFaces {len(boundary[patch])}; startFace {len(ordered)}; }}")
        ordered.extend(boundary[patch])
    mesh = destination / "constant" / "polyMesh"
    vertices = [(x * H, y * H, z) for z in (0, THICKNESS) for x, y in points]
    write(mesh / "points", header("vectorField", "points") + f"{len(vertices)}\n(\n" +
          "\n".join(f"({x:.15g} {y:.15g} {z:.15g})" for x, y, z in vertices) + "\n)\n")
    write(mesh / "faces", header("faceList", "faces") + f"{len(ordered)}\n(\n" +
          "\n".join(f"4({' '.join(map(str, row[0]))})" for row in ordered) + "\n)\n")
    write(mesh / "owner", header("labelList", "owner") + f"{len(ordered)}\n(\n" +
          "\n".join(str(row[1]) for row in ordered) + "\n)\n")
    write(mesh / "neighbour", header("labelList", "neighbour") + f"{len(internal)}\n(\n" +
          "\n".join(str(row[2]) for row in internal) + "\n)\n")
    write(mesh / "boundary", header("polyBoundaryMesh", "boundary") + "7\n(\n" + "\n".join(patch_lines) + "\n)\n")
    return {"cells": len(cells), "points": len(vertices), "internal_faces": len(internal),
            "source": source.name, "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "merging_precision_H": 1e-10, "block_shapes": shapes.tolist(),
            "family": "orthogonal nested grid on NASA geometry", "refinement_factor": factor}


def field(name: str, dimensions: str, internal: str, inlet: str, wall: str, outlet: str = "type zeroGradient;") -> str:
    kind = "volVectorField" if name == "U" else "volScalarField"
    parts = {"inlet": inlet, "outlet": outlet, "lowerWall": wall,
             "upperWall": wall, "stepWall": wall,
             "upstreamSlip": "type symmetry;", "frontAndBack": "type empty;"}
    return (header(kind, name) + f"dimensions {dimensions};\ninternalField uniform {internal};\n"
            + "boundaryField\n{\n" + "\n".join(f"{p}\n{{ {bc} }}" for p, bc in parts.items()) + "\n}\n")


def prepare(name: str, level: int, inlet_speed: float, iterations: int) -> dict:
    destination = CASES / name
    if destination.exists():
        raise FileExistsError(f"Preserving existing input case {destination}")
    mesh = imported_mesh(level, destination)
    intensity = 0.00061
    k = 1.5 * (inlet_speed * intensity) ** 2
    omega = k / (0.009 * NU)
    write(destination / "0/U", field("U", "[0 1 -1 0 0 0 0]", f"({inlet_speed} 0 0)",
          f"type fixedValue; value uniform ({inlet_speed} 0 0);", "type noSlip;"))
    write(destination / "0/p", field("p", "[0 2 -2 0 0 0 0]", "0", "type zeroGradient;", "type zeroGradient;", "type fixedValue; value uniform 0;"))
    write(destination / "0/k", field("k", "[0 2 -2 0 0 0 0]", str(k),
          f"type fixedValue; value uniform {k};", "type kqRWallFunction; value uniform 1e-12;"))
    write(destination / "0/omega", field("omega", "[0 0 -1 0 0 0 0]", str(omega),
          f"type fixedValue; value uniform {omega};", "type omegaWallFunction; value uniform 1;"))
    write(destination / "0/nut", field("nut", "[0 2 -1 0 0 0 0]", "0",
          "type calculated; value uniform 0;", "type nutUSpaldingWallFunction; value uniform 0;", "type calculated; value uniform 0;"))
    write(destination / "constant/physicalProperties", header("dictionary", "physicalProperties") + f"viscosityModel constant;\nnu {NU:.14g};\n")
    write(destination / "constant/momentumTransport", header("dictionary", "momentumTransport") + "simulationType RAS;\nRAS { model kOmegaSST; turbulence on; printCoeffs on; }\n")
    write(destination / "system/fvSchemes", header("dictionary", "fvSchemes") + """
ddtSchemes { default steadyState; }
gradSchemes { default cellLimited Gauss linear 1; }
divSchemes
{
    default none;
    div(phi,U) bounded Gauss linearUpwind grad(U);
    div(phi,k) bounded Gauss upwind;
    div(phi,omega) bounded Gauss upwind;
    div((nuEff*dev2(T(grad(U))))) Gauss linear;
}
laplacianSchemes { default Gauss linear limited 0.5; }
interpolationSchemes { default linear; }
snGradSchemes { default limited 0.5; }
wallDist { method meshWave; }
""")
    write(destination / "system/fvSolution", header("dictionary", "fvSolution") + """
solvers
{
    p { solver GAMG; smoother DICGaussSeidel; tolerance 1e-9; relTol 0.05; nPreSweeps 1; nPostSweeps 2; nCellsInCoarsestLevel 40; cacheAgglomeration true; agglomerator faceAreaPair; mergeLevels 1; }
    "(U|k|omega)" { solver smoothSolver; smoother symGaussSeidel; tolerance 1e-10; relTol 0.01; }
}
SIMPLE { nNonOrthogonalCorrectors 0; consistent yes; }
relaxationFactors { fields { p 0.3; } equations { U 0.65; k 0.5; omega 0.5; } }
""")
    sets = []
    for label, x, low, high, count in [("upstream", -4, 1.000001, 8.999999, 401),
                                      ("x1", 1, 0.000001, 8.999999, 451),
                                      ("x4", 4, 0.000001, 8.999999, 451),
                                      ("x6", 6, 0.000001, 8.999999, 451),
                                      ("x10", 10, 0.000001, 8.999999, 451)]:
        sets.append(f"{label} {{ type lineUniform; axis y; start ({x*H} {low*H} {THICKNESS/2}); end ({x*H} {high*H} {THICKNESS/2}); nPoints {count}; }}")
    functions = """
functions
{
    shear { type wallShearStress; libs ("libfieldFunctionObjects.so"); patches (lowerWall upperWall stepWall); writeControl timeStep; writeInterval 100; }
    yPlus { type yPlus; libs ("libfieldFunctionObjects.so"); writeControl timeStep; writeInterval 100; }
    wallSamples
    {
        type surfaces; libs ("libsampling.so"); writeControl timeStep; writeInterval 100;
        surfaceFormat raw; interpolationScheme cell; fields (p wallShearStress yPlus);
        surfaces (lower { type patch; patches (lowerWall); interpolate false; });
    }
    profiles
    {
        type sets; libs ("libsampling.so"); writeControl timeStep; writeInterval 100;
        setFormat raw; interpolationScheme cellPoint; fields (U p k omega);
        sets (SETS);
    }
    inletFlux { type surfaceFieldValue; libs ("libfieldFunctionObjects.so"); regionType patch; name inlet; operation sum; fields (phi); writeFields false; writeControl timeStep; writeInterval 20; }
    outletFlux { type surfaceFieldValue; libs ("libfieldFunctionObjects.so"); regionType patch; name outlet; operation sum; fields (phi); writeFields false; writeControl timeStep; writeInterval 20; }
}
""".replace("SETS", "\n".join(sets))
    write(destination / "system/controlDict", header("dictionary", "controlDict") + f"""
application simpleFoam;
startFrom startTime;
startTime 0;
stopAt endTime;
endTime {iterations};
deltaT 1;
writeControl timeStep;
writeInterval 500;
purgeWrite 2;
writeFormat ascii;
writePrecision 12;
writeCompression off;
timeFormat general;
runTimeModifiable true;
""" + functions)
    contract = {"case": name, "grid": mesh, "inlet_m_s": inlet_speed, "reference_speed_m_s": UREF,
                "step_height_m": H, "nu_m2_s": NU, "reference_Re_H": 36000,
                "freestream_turbulence_intensity": intensity, "freestream_nut_over_nu": 0.009,
                "model": "OpenFOAM 10 kOmegaSST with Spalding nut and omega wall treatment",
                "solver": "simpleFoam", "iterations": iterations,
                "source": "Driver and Seegmiller, AIAA Journal 23(2), 163-171 (1985), doi:10.2514/3.8890",
                "grid_and_boundary_source": "NASA TMR boundary geometry, independently generated orthogonal nested mesh",
                "comparison": "U/Uref and v/Uref at published stations; wall Cp shifted at x/H=40; Cf; reattachment x/H",
                "reviewed_at": datetime.now(timezone.utc).isoformat()}
    write(destination / "input_contract.json", json.dumps(contract, indent=2))
    return contract


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--level", type=int, default=4)
    parser.add_argument("--inlet", type=float, default=38.0)
    parser.add_argument("--iterations", type=int, default=3000)
    args = parser.parse_args()
    print(json.dumps(prepare(args.name, args.level, args.inlet, args.iterations), indent=2))
