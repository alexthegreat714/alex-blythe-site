"""Compare retained Aero/OpenFOAM fields with NASA's experimental tables.

Run after copying each pipeline run into REPORT/evidence/{coarse,medium,fine}.
No CFD or experimental quantity is fitted by this postprocessor.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

H = .0127
UREF = 44.2
NU = UREF * H / 36000
STATIONS = {-4: "upstream", 1: "x1", 4: "x4", 6: "x6", 10: "x10"}


def zones(path):
    result, label = {}, "data"
    for line in path.read_text().splitlines():
        if line.startswith("zone"):
            label = line.split('t="')[1].rstrip('"')
        try:
            row = [float(x) for x in line.split()]
        except ValueError:
            continue
        if row:
            result.setdefault(label, []).append(row)
    return {k: np.asarray(v) for k, v in result.items()}


def stats(delta):
    return {"n": len(delta), "bias": float(np.mean(delta)),
            "mae": float(np.mean(np.abs(delta))),
            "rmse": float(np.sqrt(np.mean(delta**2))),
            "max_abs": float(np.max(np.abs(delta)))}


def samples(case, time):
    wall = np.loadtxt(case / f"postProcessing/wallSamples/{time}/lower.xy")
    wall = wall[np.argsort(wall[:, 0])]
    x = wall[:, 0] / H
    cp = 2 * (wall[:, 3] - np.interp(40, x, wall[:, 3])) / UREF**2
    cf = -2 * wall[:, 4] / UREF**2  # OpenFOAM inward-normal wall stress convention
    downstream = np.flatnonzero(x > 0)
    start = downstream[np.argmin(cf[downstream])]
    crossings = np.flatnonzero((cf[start:-1] < 0) & (cf[start+1:] >= 0)) + start
    if not len(crossings):
        raise ValueError("No downstream main-bubble reattachment crossing")
    i = crossings[0]
    xr = float(x[i] - cf[i] * (x[i+1] - x[i]) / (cf[i+1] - cf[i]))
    profiles = {s: np.loadtxt(case / f"postProcessing/profiles/{time}/{name}.xy")
                for s, name in STATIONS.items()}
    center = float(np.interp(5 * H, profiles[-4][:, 0], profiles[-4][:, 1]))
    return {"time": int(time), "x": x, "cp": cp, "cf": cf, "xr": xr,
            "uref": center, "profiles": profiles, "wall_yplus": wall[:, -1]}


def csv_write(path, rows):
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for row in rows for k in row)))
        writer.writeheader()
        writer.writerows(rows)


def main(root):
    source = root / "sources"
    exp_p = zones(source / "profiles.exp.dat")
    exp_cp = zones(source / "cp.expnew.dat")["bottom wall"]
    exp_cf = zones(source / "cf.exp.dat")["data"]
    all_rows, summaries, snapshots = [], {}, {}
    residual_rows = []
    for name in ("coarse", "medium", "fine"):
        evidence = root / "evidence" / name
        if not evidence.exists():
            continue
        case = evidence / "case_result"
        state = json.loads((evidence / "state.json").read_text())
        if state["status"] != "completed":
            raise ValueError(f"Cannot score incomplete run {name}")
        times = sorted((p.name for p in (case / "postProcessing/profiles").iterdir()
                        if p.is_dir() and p.name.isdigit()), key=int)
        tail = [samples(case, t) for t in times[-3:]]
        data = tail[-1]
        snapshots[name] = data
        contract = json.loads((case / "input_contract.json").read_text())
        summary = {"run_id": state["run_id"], "status": state["status"],
                   "cells": contract["grid"]["cells"], "iterations": data["time"],
                   "inlet_speed_m_s": contract["inlet_m_s"],
                   "reference_speed_target_m_s": UREF,
                   "reference_speed_actual_m_s": data["uref"],
                   "reference_speed_delta_percent": (data["uref"] / UREF - 1) * 100,
                   "actual_Re_H": data["uref"] * H / NU,
                   "reattachment_x_H": data["xr"], "reattachment_delta_H": data["xr"] - 6.26,
                   "reattachment_delta_mm": (data["xr"] - 6.26) * H * 1000,
                   "reattachment_delta_percent": (data["xr"] / 6.26 - 1) * 100,
                   "reattachment_in_reported_experimental_interval": bool(abs(data["xr"] - 6.26) <= .1),
                   "tail_iterations": [s["time"] for s in tail],
                   "tail_reattachment_range_H": float(np.ptp([s["xr"] for s in tail])),
                   "lower_wall_yplus": {"min": float(min(data["wall_yplus"])),
                                        "mean": float(np.mean(data["wall_yplus"])),
                                        "max": float(max(data["wall_yplus"]))}}
        summary["tail_max_range_Cp"] = float(np.max(np.ptp(np.array([s["cp"] for s in tail]), axis=0)))
        summary["tail_max_range_Cf"] = float(np.max(np.ptp(np.array([s["cf"] for s in tail]), axis=0)))
        summary["tail_max_range_u_over_Uref"] = float(max(
            np.max(np.ptp(np.array([s["profiles"][station][:, 1]/UREF for s in tail]), axis=0))
            for station in STATIONS))
        upstream = data["profiles"][-4]
        lower_half = upstream[upstream[:, 0]/H <= 5 + 1e-6]
        relative_u = lower_half[:, 1] / data["uref"]
        theta = float(np.trapezoid(relative_u * (1-relative_u), lower_half[:, 0]))
        edge_index = int(np.flatnonzero(relative_u >= .99)[0])
        edge_y = float(np.interp(.99, relative_u[edge_index-1:edge_index+1], lower_half[edge_index-1:edge_index+1, 0]))
        summary["upstream_boundary_layer_diagnostic"] = {
            "delta99_over_H": edge_y/H-1, "theta_over_H": theta/H,
            "Re_theta": data["uref"]*theta/NU,
            "definition": "Lower-half profile, y/H=1..5, normalized by computed center speed; trapezoidal quadrature",
            "limitation": "Diagnostic, not an exact experimental Re_theta comparison; original full-paper uncertainty and integral definition were not audited"}
        mapping = case / "mapFields.log"
        summary["initialization_fields_mapped"] = re.findall(r"interpolating (\w+)", mapping.read_text()) if mapping.exists() else []
        summary["initialization_primary_U_p_mapped"] = all(f in summary["initialization_fields_mapped"] for f in ("U", "p"))
        summary["equivalent_iterations_on_same_grid"] = data["time"]
        initial_evidence = root / "evidence/fine_initial"
        if name == "fine" and initial_evidence.exists():
            parent = json.loads((case / "initialization.json").read_text())
            initial_state = json.loads((initial_evidence / "state.json").read_text())
            assert parent["source_run"] == initial_state["run_id"]
            summary["same_grid_parent_run_id"] = parent["source_run"]
            summary["same_grid_parent_source_iteration"] = float(parent["source_time"])
            summary["equivalent_iterations_on_same_grid"] += float(parent["source_time"])
        summary["velocity"] = {}
        deltas, v_deltas, downstream_deltas = [], [], []
        for station in STATIONS:
            experiment = exp_p[f"exp, x/H={station}"]
            profile = data["profiles"][station]
            assert min(experiment[:, 1]) >= min(profile[:, 0]/H)
            assert max(experiment[:, 1]) <= max(profile[:, 0]/H)
            u = np.interp(experiment[:, 1], profile[:, 0]/H, profile[:, 1]) / UREF
            v = np.interp(experiment[:, 1], profile[:, 0]/H, profile[:, 2]) / UREF
            ranges = [np.ptp(np.array([
                np.interp(experiment[:, 1], s["profiles"][station][:, 0]/H, s["profiles"][station][:, component])/UREF
                for s in tail]), axis=0) for component in (1, 2)]
            du, dv = u - experiment[:, 2], v - experiment[:, 3]
            summary["velocity"][str(station)] = {"u_over_Uref": stats(du), "v_over_Uref": stats(dv)}
            deltas.extend(du)
            v_deltas.extend(dv)
            if station > 0:
                downstream_deltas.extend(du)
            for e, cfd_u, cfd_v, u_range, v_range in zip(experiment, u, v, *ranges):
                for quantity, cfd, measured, iterative_range in (("u/Uref", cfd_u, e[2], u_range), ("v/Uref", cfd_v, e[3], v_range)):
                    all_rows.append({"mesh": name, "quantity": quantity, "x_H": station, "y_H": e[1],
                                     "experiment": measured, "cfd": cfd, "delta_cfd_minus_exp": cfd-measured,
                                     "last_three_snapshot_range": iterative_range,
                                     "experimental_error_if_given": ""})
        summary["u_over_Uref_all_stations"] = stats(np.array(deltas))
        summary["v_over_Uref_all_stations"] = stats(np.array(v_deltas))
        summary["u_over_Uref_downstream_only"] = stats(np.array(downstream_deltas))
        summary["u_dimensional_rmse_m_s"] = summary["u_over_Uref_all_stations"]["rmse"] * UREF
        for quantity, exp, column in (("Cp", exp_cp, "cp"), ("Cf", exp_cf, "cf")):
            predicted = np.interp(exp[:, 0], data["x"], data[column])
            delta = predicted - exp[:, 1]
            iterative_ranges = np.ptp(np.array([np.interp(exp[:, 0], s["x"], s[column]) for s in tail]), axis=0)
            summary[quantity] = stats(delta)
            summary[quantity]["max_tail_range_at_experimental_positions"] = float(max(iterative_ranges))
            if quantity == "Cp":
                offset = float(np.interp(37.5, data["x"], data["cp"]))
                summary[quantity]["alternative_zero_reference_x_H"] = 37.5
                summary[quantity]["alternative_zero_reference_constant_shift"] = -offset
                summary[quantity]["rmse_with_zero_at_37_5"] = stats(delta-offset)["rmse"]
            if quantity == "Cf":
                summary[quantity]["within_reported_error_count"] = int(np.sum(abs(delta) <= exp[:, 2]))
            for e, cfd, iterative_range in zip(exp, predicted, iterative_ranges):
                all_rows.append({"mesh": name, "quantity": quantity, "x_H": e[0], "y_H": "",
                                 "experiment": e[1], "cfd": cfd, "delta_cfd_minus_exp": cfd-e[1],
                                 "last_three_snapshot_range": iterative_range,
                                 "experimental_error_if_given": e[2] if quantity == "Cf" else ""})
        for field in ("inlet", "outlet"):
            flux = np.loadtxt(case / f"postProcessing/{field}Flux/0/surfaceFieldValue.dat")
            summary[field + "_volume_flux_m3_s"] = float(flux[-1, 1])
        summary["mass_imbalance_fraction"] = abs(summary["inlet_volume_flux_m3_s"] + summary["outlet_volume_flux_m3_s"]) / abs(summary["inlet_volume_flux_m3_s"])
        residuals, current_time = {}, 0
        for line in (evidence / "solver.log").read_text().splitlines():
            match = re.match(r"Time = ([\d.eE+-]+)", line)
            if match:
                current_time = float(match[1])
            match = re.search(r"Solving for (\w+), Initial residual = ([\d.eE+-]+), Final residual = ([\d.eE+-]+)", line)
            if match:
                field, initial, final = match.groups()
                residuals[field] = float(initial)
                residual_rows.append({"mesh": name, "iteration": current_time, "field": field,
                                      "initial_residual": float(initial), "final_linear_residual": float(final)})
        summary["last_initial_residuals"] = residuals
        summary["all_last_initial_residuals_below_1e_6"] = all(v <= 1e-6 for v in residuals.values())
        summary["mesh_quality"] = state["metrics"].get("mesh", {})
        summary["pipeline_design_use_allowed"] = state.get("engineering_readiness", {}).get("design_use_allowed", False)
        summaries[name] = summary
    if not summaries:
        raise ValueError("No completed comparison runs")
    comparison = {"difference_definition": "CFD minus experiment; fixed measured Uref=44.2m/s for all normalization",
                  "assessment": "Experimental comparison completed; general accuracy and design validation not established",
                  "mesh_independence_established": False,
                  "experiment": {"paper_doi": "10.2514/3.8890", "reattachment_x_H": 6.26,
                                 "reattachment_reported_plus_minus_H": .10,
                                 "Re_H": 36000, "H_m": H, "Uref_m_s": UREF}, "runs": summaries}
    if all(x in snapshots for x in ("coarse", "medium", "fine")):
        xrs = [snapshots[x]["xr"] for x in ("coarse", "medium", "fine")]
        changes = np.diff(xrs)
        mesh = {"reattachment_coarse_to_medium_H": float(changes[0]),
                "reattachment_medium_to_fine_H": float(changes[1]),
                "reattachment_medium_to_fine_percent_of_fine": float(changes[1]/xrs[-1]*100),
                "note": "Observed differences, not a certified uncertainty interval or automatic mesh-independence pass."}
        for quantity, exp, column in (("Cp", exp_cp, "cp"), ("Cf", exp_cf, "cf")):
            m, f = snapshots["medium"], snapshots["fine"]
            mesh[quantity + "_fine_minus_medium_at_experimental_stations"] = stats(
                np.interp(exp[:, 0], f["x"], f[column]) - np.interp(exp[:, 0], m["x"], m[column]))
        velocity_change = []
        for station in STATIONS:
            exp = exp_p[f"exp, x/H={station}"]
            m, f = snapshots["medium"]["profiles"][station], snapshots["fine"]["profiles"][station]
            velocity_change.extend((np.interp(exp[:, 1], f[:, 0]/H, f[:, 1]) -
                                    np.interp(exp[:, 1], m[:, 0]/H, m[:, 1])) / UREF)
        mesh["u_over_Uref_fine_minus_medium_at_experimental_points"] = stats(np.array(velocity_change))
        if changes[0] * changes[1] > 0 and abs(changes[0]) > abs(changes[1]):
            order = float(np.log(abs(changes[0]/changes[1]))/np.log(2))
            extrap = xrs[-1] + (xrs[-1]-xrs[-2])/(2**order-1)
            mesh.update({"apparent_order_reattachment": order, "richardson_extrapolated_reattachment_H": extrap,
                         "indicative_GCI_fine_percent": 1.25*abs(extrap-xrs[-1])/abs(xrs[-1])*100,
                         "GCI_limitation": "Single observable, three nested meshes; wall-function/model changes and asymptotic regime not independently established."})
        comparison["mesh_sensitivity"] = mesh
    (root / "comparison.json").write_text(json.dumps(comparison, indent=2))
    csv_write(root / "pointwise_deltas.csv", all_rows)
    csv_write(root / "residual_history.csv", residual_rows)
    csv_write(root / "mesh_summary.csv", [{k: v for k, v in s.items() if not isinstance(v, (dict, list))} | {"mesh": n} for n, s in summaries.items()])
    colors = {"coarse": "#e69f00", "medium": "#56b4e9", "fine": "#00735c"}
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), layout="constrained")
    axes[0].plot(exp_cp[:, 0], exp_cp[:, 1], "ko", label="Experiment", ms=4)
    axes[1].errorbar(exp_cf[:, 0], exp_cf[:, 1]*1000, yerr=exp_cf[:, 2]*1000, fmt="ko", label="Experiment", ms=4, capsize=2)
    for name, data in snapshots.items():
        visible = (data["x"] >= -5) & (data["x"] <= 38)
        axes[0].plot(data["x"][visible], data["cp"][visible], color=colors[name], label=name)
        axes[1].plot(data["x"][visible], data["cf"][visible]*1000, color=colors[name], label=name)
    for ax, ylabel in zip(axes, ("Cp (shift at x/H=40)", "1000 Cf")):
        ax.set(xlim=(-5, 38), xlabel="x/H", ylabel=ylabel)
        ax.grid(alpha=.2)
        ax.axhline(0, lw=.6, color="gray")
        ax.legend()
    fig.savefig(root / "wall_comparison.png", dpi=180)
    plt.close(fig)
    fig, axes = plt.subplots(1, 5, figsize=(14, 5), layout="constrained")
    for ax, station in zip(axes, STATIONS):
        exp = exp_p[f"exp, x/H={station}"]
        ax.plot(exp[:, 2], exp[:, 1], "ko", ms=3, label="Experiment")
        for name, data in snapshots.items():
            p = data["profiles"][station]
            ax.plot(p[:, 1]/UREF, p[:, 0]/H, color=colors[name], label=name)
        ax.set(title=f"x/H={station}", xlabel="u/Uref", ylabel="y/H", ylim=(0, 4), xlim=(-.3, 1.15))
        ax.grid(alpha=.2)
    axes[-1].legend(loc="upper left", fontsize=8)
    fig.savefig(root / "velocity_comparison.png", dpi=180)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(7, 4), layout="constrained")
    ax.errorbar([0], [6.26], yerr=[.1], fmt="ko", capsize=6)
    for i, name in enumerate(snapshots, 1):
        ax.plot([i], [snapshots[name]["xr"]], "o", color=colors[name])
    ax.set(xticks=range(len(snapshots)+1), xticklabels=["Experiment", *snapshots], ylabel="Reattachment x/H")
    ax.grid(axis="y", alpha=.2)
    fig.savefig(root / "reattachment.png", dpi=180)
    plt.close(fig)
    if (root / "evidence/fine_initial").exists() and "fine" in summaries:
        history = []
        for label, offset in (("fine_initial", 0), ("fine", summaries["fine"]["same_grid_parent_source_iteration"])):
            case = root / "evidence" / label / "case_result"
            for path in sorted((case / "postProcessing/profiles").iterdir(), key=lambda p: float(p.name)):
                try:
                    s = samples(case, path.name)
                except ValueError:
                    continue  # No defined main-bubble reattachment in early startup.
                history.append({"phase": label, "total_iteration": offset + int(path.name),
                                "reattachment_x_H": s["xr"], "reference_speed_m_s": s["uref"]})
        csv_write(root / "fine_convergence.csv", history)
        fig, ax = plt.subplots(figsize=(9, 4), layout="constrained")
        ax.plot([r["total_iteration"] for r in history], [r["reattachment_x_H"] for r in history], "o-", ms=3, color=colors["fine"])
        ax.axhspan(6.16, 6.36, color="gray", alpha=.2, label="Experiment 6.26 ± 0.10H")
        ax.axvline(summaries["fine"]["same_grid_parent_source_iteration"], color="black", ls="--", lw=1, label="Continuation from complete saved fields")
        ax.set(xlabel="Total SIMPLE iterations on fine grid", ylabel="Reattachment x/H", ylim=(0, 8))
        ax.grid(alpha=.2)
        ax.legend(fontsize=8, loc="lower right")
        fig.savefig(root / "fine_convergence.png", dpi=180)
        plt.close(fig)
    print(json.dumps(comparison, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("report_directory", type=Path)
    main(parser.parse_args().report_directory)
