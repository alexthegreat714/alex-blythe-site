"""Independently check reported arithmetic, retained samples and source hashes."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import brentq


def main(root):
    comparison = json.loads((root / "comparison.json").read_text())
    rows = list(csv.DictReader((root / "pointwise_deltas.csv").open()))
    checks = []
    for entry in json.loads((root / "sources/downloads.json").read_text()):
        actual = hashlib.sha256((root / "sources" / entry["name"]).read_bytes()).hexdigest()
        assert actual == entry["sha256"], entry["name"]
    checks.append("All downloaded source SHA256 digests match")
    for name, summary in comparison["runs"].items():
        selected = [r for r in rows if r["mesh"] == name]
        for quantity, key in (("u/Uref", "u_over_Uref_all_stations"), ("v/Uref", "v_over_Uref_all_stations"), ("Cp", "Cp"), ("Cf", "Cf")):
            subset = [r for r in selected if r["quantity"] == quantity]
            differences = []
            for row in subset:
                delta = float(row["cfd"]) - float(row["experiment"])
                assert math.isclose(delta, float(row["delta_cfd_minus_exp"]), abs_tol=1e-14)
                differences.append(delta)
            assert len(differences) == summary[key]["n"]
            rmse = math.sqrt(sum(x*x for x in differences) / len(differences))
            assert math.isclose(rmse, summary[key]["rmse"], rel_tol=1e-12)
        case = root / "evidence" / name / "case_result"
        final = summary["iterations"]
        wall = np.loadtxt(case / f"postProcessing/wallSamples/{final}/lower.xy")
        wall = wall[np.argsort(wall[:, 0])]
        # Independent root solution using raw stress, without coefficient scaling.
        x, stress = wall[:, 0]/.0127, wall[:, 4]
        start = np.flatnonzero(x > 0)[np.argmax(stress[x > 0])]
        i = next(i for i in range(start, len(x)-1) if stress[i] > 0 and stress[i+1] <= 0)
        root_x = brentq(lambda pos: np.interp(pos, x, stress), x[i], x[i+1], xtol=1e-12)
        assert math.isclose(root_x, summary["reattachment_x_H"], abs_tol=1e-10)
        assert math.isclose(summary["reattachment_delta_H"], root_x-6.26, abs_tol=1e-10)
        assert summary["u_over_Uref_all_stations"]["n"] == 129
        assert summary["Cp"]["n"] == 33 and summary["Cf"]["n"] == 20
        checks.append(f"{name}: all signed deltas and RMSEs recompute; 129 velocity locations, 33 Cp, 20 Cf; independent raw-stress root agrees")
    result = {"passed": True, "checks": checks}
    (root / "arithmetic_audit.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("report_directory", type=Path)
    main(parser.parse_args().report_directory)
