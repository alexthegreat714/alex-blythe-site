Aero experimental CFD comparison — public reproducibility bundle

Reference: Driver & Seegmiller, AIAA Journal 23(2), 163–171 (1985), doi:10.2514/3.8890.
NASA experimental data: https://tmbwg.github.io/turbmodels/backstep_val.html
The journal paper is peer-reviewed; this Aero execution report is not.

AI workflow attribution: OpenAI 6.1 High (model label supplied by Alex Blythe).
The AI assisted setup, orchestration, diagnostics and reporting. OpenFOAM, not
the language model, produced the numerical CFD predictions.

Executed with Aero's imported-case OpenFOAM pipeline, OpenFOAM Foundation 10,
build 10-c4cf895ad8fa, simpleFoam, kOmegaSST, serial CPU.
Three nested orthogonal meshes: 6,800 / 27,200 / 108,800 cells.
Fine includes an initial 2,000 iterations plus a 1,500-iteration continuation.
The exact continuation checkpoint is already mapped into fine/case_input/0.
Numerical settings and inputs are retained; no fitting of downstream data.

To replay the numerical solves, copy each evidence/NAME/case_input to a writable
working directory, source OpenFOAM 10, then run checkMesh and simpleFoam there.
Preserve constant/polyMesh. Do not replace it with blockMesh. Replay fine from
its retained initial fields; 1,500 replay iterations correspond to 3,500 total
on that grid. The recorded result of the initial fine run is also included.
The medium final sampled U/p/Cp/Cf data are retained; its latest volume directory
contains diagnostics only. This limitation is disclosed in the report.
For volume-field viewing, copy a retained solved time from case_result into a
writable copy of case_input; the bundle deduplicates mesh/system/initial files.

To recalculate the comparison from retained evidence:
  python reproduction/compare_driver_seegmiller.py .
  python reproduction/audit_driver_seegmiller.py .
Requires Python with numpy, scipy and matplotlib. The generator script is an
archive copy from Aero/tools; use the retained decks for exact replay.

NASA CFL3D SSTm data in diagnostics are another CFD reference, not experiment.
SSTm/CFL3D differs from our OpenFOAM wall treatment and steady incompressible
implementation; the 7/20 follow-up is supporting evidence, not a controlled
model-isolation experiment. Listed experimental error confidence is unspecified.

Public release excludes private toolkit modules, service configuration and
credentials. state.json files are explicit public projections of run metadata.
Hashes identify artifacts; they do not establish scientific correctness.
